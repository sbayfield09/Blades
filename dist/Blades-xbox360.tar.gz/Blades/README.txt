Blades0.52 — automatic update installation and restart

Install the COMPLETE0.52 USB ZIP once; keep update-installer.xex next to default.xex.
The0.50/0.51 updater only downloads and cannot install this new behavior for itself.
Keep existing Config files. This package contains no private settings or logs.

For subsequent updates: System > Update Blades > Update and Restart downloads,
verifies, prepares, installs and relaunches automatically. X/Back cancels while
preparing; once installation begins keep the drive connected. No manual ZIP
extraction or extra confirmation. Settings and unrelated files remain intact.
The installer runs outside the old executable after its services/files close.
It backs up installed files, replaces default.xex last and relaunches it.
A pending journal permits retryable rollback on a later startup. Keep the
.blades-update/backup folder if installation reports a recovery problem.
No DashLaunch, plugin, NAND, firmware or default-dashboard change is involved.

Test on Xbox: confirm normal0.52 startup; when a newer release is available,
select Update and Restart and verify automatic return to the Games root, the
new installed version, retained FTP/Jellyfin/scan paths and a current update
check. Host TLS/installer/rollback tests pass; actual XAM relaunch, storage
power-loss behavior and launch/exit static still need physical-console testing.
The new video is a desktop renderer capture; installer/restart scenes are
labelled simulations. The actual shared transaction code is tested separately.

Media animations, display handoff work and prior playback/FTP/profile features
are retained. Historical feature/testing notes below remain for reference.

Retained0.49 features:

Selected movies/episodes show server artwork, description and runtime on the
right. Portrait posters and landscape episode images keep their aspect ratio.
Long descriptions wrap with an ellipsis; absent metadata has explicit fallbacks.
Artwork loads after a short selection pause, on the network worker, with bounded
PNG size/dimensions and three cached thumbnails. No images are saved to disk.
Navigation and playback preempt an artwork request; B still cancels promptly.

FTP now batches disk I/O in256KiB blocks, drains ready upload data without
a redundant poll per read and uses63KiB XAM/socket buffers instead of16KiB.
TCP_NODELAY avoids delayed control replies during queues of small files.
Check bulk upload/download, many small files, resume/append and menu responsiveness
on HDD and USB. Desktop benchmarks do not establish Xbox/Aurora throughput.
Existing credentials, toggle and exported drive roots are unchanged.
Look for ftp-transfer lines in default.log: bytes, elapsed_ms, disk_calls and
accepted socket buffers are reported without filenames or credentials.

Retained0.48 seek fixes:

Every restarted stream now has its own progressive-cache request identity.
Jellyfin excludes the seek time from its cache filename and deletes old output
asynchronously, so reusing that filename could replay the old scene while Blades
reported the new time. A unique per-restart User-Agent isolates that cache,
including when returning to the same timestamp, while retaining the same
Jellyfin device, authentication and logical playback/history session.
Actual frame-coded content now verifies fractional, one-second and ten-second
forward/back seeks against official Jellyfin; tests no longer trust only the
reported clock. Network end seeks follow Jellyfin's half-second EOF margin.
Left/Right controls still skip10seconds; local seeking remains unchanged.

Retained0.47 timeout/audio/episode fixes:

Jellyfin media delivery now allows30seconds of inactivity instead of8seconds,
so a transient transcoder stall after seeking can recover. The same ten-second
stall reproduces the old timeout and succeeds in this build. Connect/send and
control API timeouts stay short; B still cancels promptly. A real30second media
stall still fails clearly. Remote opening/probing has a cancellable60second
budget; local opening/probing is unchanged.
Continue Watching and Next Up show Series Name S1E2 - Episode Name for episodes.
Existing series/season prefixes are normalized without duplication. Specials
can use S0E1; missing numbers fall back to series/title. Movies/missing series
keep their original titles. Raw episode metadata is retained.
Audio PCM preserves timestamp gaps as silence and trims overlaps, with resampler
latency accounted for. A flash/tone test reproduces0.52seconds of early audio
and now aligns within100ms both at start and after seeking. The log includes
audio_gap_frames/audio_overlap_frames. Actual Xbox lip sync still needs testing.

Shared media folders (retained from0.46)

New media folders are shared by Music, Pictures and Local Video. Open Media >
Video Marketplace > Add Folder, choose a folder, press X and choose scan depth.
There is no Music/Pictures/Video category step. Supported filename extensions
are classified automatically, including mixed folders/subfolders and uppercase
extensions. Unsupported files and executables are ignored in media scans.
Existing saved typed paths are unchanged, with no migration. Remove/re-add a
path if you want it to use the new shared behaviour. Game paths remain separate.
Music/Pictures playback is still unfinished; their lists filter the files.


Extract Blades-v0.50-USB.zip onto USB; launch Blades/default.xex. The complete
matching Assets folder/notices are included. Keep your existing Config files
when updating. No adapter, converter, DashLaunch or extra executable is needed.

Media > Media Center: Server Address, Username, Password, Connect/Disconnect,
Remove Connection. Use a LAN IPv4 address and optional port, e.g.10.0.0.20:8096.
Native HTTP only, as in XenonFin: no HTTPS/DNS/base path. Enter up to128 ASCII
characters with the Xbox keyboard. The account must permit server transcoding.
A saved bearer session reconnects next start; passwords are never saved.
Config/jellyfin-settings.json is private and excluded from all release ZIPs.

Media > Video > Jellyfin: browse video libraries, folders, series/seasons,
movies and episodes. Previous/Next Page are10-item pages. X refreshes, B returns.
Jellyfin negotiates and streams MPEG2/MP2 up to720p30 to the existing player.
A pause/resume, X fit/stretch, B/Back returns to the same list. Guide pauses.
Left/Right seeks10seconds backward/forward; server transcoding restarts at
that position, with a brief buffering delay. Paused seeks stay paused.
Continue Watching and Next Up are above the video libraries. Opening any
partly watched Jellyfin video resumes from fresh server user data. The current
folder refreshes on return. Server resume/watched thresholds still apply.
Media > Video > Local retains scanned videos. Video Marketplace manages paths.
There is no video autoplay on startup/sign-in. No whole-file download is needed.

The verified0.43 Simple360 H264 routines, workers and GPU display are retained.
All artwork/tints/highlights are retained. Music/Pictures playback and music
visualisations are still unfinished. See docs/JELLYFIN.md for detailed scope.

An isolated official Jellyfin10.10.7 server passed authentication/browsing and
HEVC/AAC -> MPEG2/MP2; real Resume/Next Up episode,4second resume, paused/rapid/
forward/back/end-bound seeking and absolute saved position. Protocol/network/UI/sanitizer/render/build checks pass.
Physical Xbox Jellyfin/network/keyboard playback still needs your test; no
new console throughput/1080p30 result is claimed. If a problem occurs, describe
the screen and send default.log; do not share your private Jellyfin config.

Fresh desktop walkthrough includes Local and actual isolated Jellyfin playback.
Xbox Guide/profiles/storage/FTP are simulated and labelled. The combined binary
is GPLv3 with complete corresponding source in Blades-v0.50-source.zip; original
MIT/FFmpeg/Simple360Player/XenonFin/artwork/font/SDK notices are preserved.

Retained 0.37 corrections:
- Marketplace tint is halfway between 0.35 and 0.36. Xbox Live keeps the
  0.35 hue with lower saturation. Media is about 7% darker than 0.36.
  Games and System retain their 0.36 colours. Cap/tray masks match the tints.
- Restore the pre-0.36 Gamerscore G box position (y148 instead of y142).
  Keep the original icon pixels, size and horizontal alignment.
- Fix a drawing-cache rounding mismatch that could retain a one-pixel lower
  shadow when scrolling down to Chat and IM. The cache and renderer now both
  round the cursor position. Test Down from Friends and Up from Open Tray.
- Retain the full bottom Live divider and bounded rounded group edges,
  stock 360-logo drop shadow, FTP spacing/cursor animation and card shadows.
- The matching premade artwork pack has 235 entries and is included here.

Profile fixes:
- Signed-out profile count reads public profile-package headers on available
  HDD/USB/memory storage, deduplicating copies. No account/GPD payload is read.
- The card uses the active user's actual local/normal gamer picture. Temporary
  read failures keep the last valid picture until the account changes.
- Up from the first menu item selects the card signed in or out. A requests
  native Guide sign-in or the user's native profile/gamer-card menu.
- X at a blade root requests the Guide's sign-out-enabled interface. The old
  custom confirmation/direct background sign-out has been removed.
- Card focus survives sign-in, and identity changes invalidate its draw cache.
- The card/menu highlight is brightest at the centre and fades toward both
  edges, using the clearer uploaded sign-in video reference near 22:00.
  The name band stays above the sheen and fades without a hard inner separator.
  Other button dividers remain; the selected lower groove is covered by its
  shadow, including in the FTP controls.
- The Gamerscore G icon and real totals remain. Xbox Live's information text
  has its own bounded/wrapped column clear of the button separator.

Achievements:
Games -> Achievements asks for Guide sign-in first when needed and resumes on
success. The unlock flags are now decoded as 0x10000/0x20000, fixing the case
where real earned totals were shown but the icon grid said details unavailable.
The existing icon spacing is retained; only the selected game highlight is
inset so it no longer touches the dividing line above. Right enters the earned grid; A opens the exact
achievement in the real Guide. A on the game strip opens that game's Guide
achievements. B returns through grid, game strip and Games; X refreshes.
Changing accounts clears prior-account achievement data. Reads run on a worker;
no achievements or gamerscore are modified.

FTP is now in System -> Computers. It runs across all blades/submenus once the
main menu loads, unless previously turned off. The screen shows on/off, current
username/password (initially blades / blades), status, IP and connected devices.
Change Username/Password opens the Xbox keyboard; confirm 1-63 printable
characters, or cancel unchanged. Login changes disconnect existing clients.
The enabled state and both login fields persist in Config/ftp-settings.txt;
v0.30 files keep their saved on/off choice. Failed reads/saves are reported.
Connect to the displayed IP, port 21, plain unencrypted FTP, passive mode.
The initial / directory lists available HDD, USB0, USB1, USB2 and memory drives.
No SFTP/TLS. Transfers run on workers with bounded buffers; multiple sessions
from the same IP count as one device. Resume offsets are limited to 2 GiB - 1.
X in File Manager refreshes its current folder after uploads/removals.

Audio startup now primes silent frames and ramps device gain. Shutdown fades
to zero, queues a silent tail and drains it before unregistering the driver.
The original navigation/startup PCM and sound event timings are unchanged.
This targets app-boundary clicks/static; listen on the console to confirm the
reported launch/exit noise is gone. Host envelopes cannot reproduce that noise.

Please verify on your 360: actual profile count/picture, signed-in card A,
Guide X sign-out and cancellation, real earned achievement icons/Guide details,
selected tab/divider alignment and centre-fading card highlight. Check the Xbox
Live text gutter with Messages/Friends/Chat highlighted. In System -> Computers,
change each FTP login field, cancel an edit, reconnect, restart while off/on,
and verify both credentials persist. Try an HDD/USB transfer followed by X in
File Manager. Listen at app launch and exit and check transfer-time animation
performance. Send default.log if an API/read or save fails; it records result
codes and availability, not profile credentials or FTP login text.

Library setup:
Open Games -> Played Games -> Scan Folders -> Add Folder. Select a storage
device, use A to enter folders, then X to use the current folder. Choose Games,
Apps or Homebrew, then select Unlimited (first option) or a depth from 0 to 32. Depth 0
checks the selected folder only; depth 1 includes its children. Default: 3.
Existing v0.20 paths are retained with depth 3 until you change them. Repeat for additional locations; up to 32 are saved in the local
Config/library-paths.txt file and rescanned when Blades starts. B goes up in
the picker. Select a saved path to change its depth, or press Y on the path
to remove that scan location. Storage folders and their files are not deleted.

Game Library, Apps and Homebrew are under Played Games; Arcade and Demos also
use their Games blade entries. Lists scroll. A manually launches the selected
title. X or Scan Now rescans; X changes to Stop Scan while scanning.
The current folder/file, counts and depth are shown in the right panel.
Completed results stay there until Scan Now is unhighlighted. No choose-folder,
scanning or titles-found status text is drawn at the bottom left. Empty scans explicitly
finish and re-enable controls even when no runnable titles are found. Stopping
waits for the current storage read to return. Adding/scanning never launches anything. B or
changing blades cancels an in-flight launch. Guide/modal guards still apply.

File Manager is directly below Homebrew under Played Games. It lists folders
and all regular file types, including hidden and extensionless files. Folders
sort first, then files alphabetically. A enters folders or manually launches
plain .xex executables, including zero/missing-Title-ID homebrew. Other files
show their path with an inactive A prompt; pressing A does nothing.
Compound file.dll.xex / file.exe.xex entries are visible but cannot launch.
B goes to the parent folder; X refreshes. Add Folder remains directories only.
No file is deleted, changed or previewed. Test a folder containing text, images,
archives, config files, plain XEXs and compound module names. Confirm only a
valid plain XEX launches and other files cannot be entered as folders.

Only plain names such as Utility.xex or default.XEX are eligible. Compound
file.dll.xex / file.exe.xex / file.any.xex names are excluded from launch/scanning before reading
file contents, but are visible in File Manager. Supported downloaded package formats remain supported.

Supported: extracted .xex games/apps/homebrew, Xbox Live Arcade, Games on
Demand, demos and XNA packages. Keep downloaded packages and accompanying
.data folders together. Saves, DLC, updates and profiles are excluded. XBE,
disc-installed containers, compressed archives and incomplete packages are
outside this release's launch support. Titles fall back to folder/file names
when executable metadata is unavailable. Displayed titles omit question marks and unsupported glyphs; file/launch paths
are unchanged. XEX apps with zero or missing Title IDs launch by path, using a
folder/filename label when title metadata is unavailable.

Try one extracted game, one downloaded title, an app and homebrew on your 360.
Check saved paths after restarting Blades. Test an unplugged drive, path
removal and rescanning; verify your files remain. Send default.log if browsing,
scanning or launching fails. The log includes library commands, scan counts,
metadata errors, content-mount results and SDK launch failures.

21 host suites and 290 desktop GPU comparisons pass, alongside profile
memory checks and native XEX validation. Library storage and real title handoff
still need physical-console testing. This release includes a fresh 84-second
720p30 desktop GPU walkthrough with simulated profiles, achievements, FTP,
storage and native Guide/keyboard requests. It demonstrates the actual shared
UI but cannot prove console authentication, networking, keyboard or audio-driver
behavior. Native-adapter/count/achievement/FTP/audio sanitizer fixtures pass.
Please verify the real Guide handoffs and return selection on a physical 360.

Controls: D-pad/left stick navigate, LB/RB change blades, A select, B back.
X rescans in libraries or selects the current folder in the folder picker.
At a blade root X opens Guide sign-in, or opens Guide sign-out when signed in. Back opens the confirmed exit menu.
Y removes a highlighted saved scan path on Scan Folders. Elsewhere it ejects
a loaded/reading disc from ordinary menus, including submenus. Release
it before another press. The physical eject button is monitored independently.

Select the disc row on Games, Media or Xbox Live:
  Open Tray -> Opening -> Close Tray -> Closing -> Reading -> Play <title>
A opens an empty closed tray, closes an open tray, or launches a ready game.
Insertion and boot with a game already inside never request automatic launch.
Busy states cannot be selected as games or submenus. Labels follow hardware
state, with no fixed artificial reading duration. An empty close returns to
Open Tray. Original modal/startup input guards still apply.

Xbox 360 games launch their disc XEX. Audio CDs and DVD videos are recognized
separately after stable media detection, with Play CD / Play DVD labels. A
requests the Xbox system music/DVD player via the retail dashboard. Data CDs
and DVDs display Open Data Disc; A opens the Xbox system dashboard to browse
supported media. No media type autoplays. Y and the physical eject button
continue to work. The system player handles its usual format/region/parental
restrictions. These new media handoffs need hardware testing.

Game titles come from nxeart or executable XDBF metadata, with Play Xbox 360
Game as fallback. DVD-Audio, Video CD, HD-DVD and original Xbox disc launching
are outside this release's media-player support.

Check on your 360:
- Start with no disc, and separately with a game already inside.
- Use A for open/close; verify the reported states and actual game title.
- Wait on Play for several seconds: the game must not start by itself.
- Press A on Play and confirm the game launches.
- Use Y with a loaded game, then while Reading; verify ejection.
- Open/close using the physical button, including during title detection.
- Replace a game and confirm the old title clears immediately.
- Try an empty close and an unreadable/unsupported disc; verify recovery.
- Insert an audio CD, a DVD movie and a data disc. Verify their labels and
  manual A handoffs, Y/physical eject and no autoplay.
- Check Guide, reconnect, normal navigation and confirmed exit.

default.log records API availability, tray state, media type, title ID, state
generation, command acceptance and manual-launch failures. GPU pixel checks
and five-second performance summaries remain enabled. Keep the complete log
if disc control, title detection or launching fails.

Desktop state-machine, metadata, sanitizer and renderer checks passed. The existing
DVD handling was confirmed working by the user; library handoff needs a new
physical-console check. The current
walkthrough is desktop GPU playback with explicitly simulated library storage;
it is not evidence of Xbox disc I/O or console FPS.

The existing opening, one-shot whoosh, animated background, Convection atlas
and menu artwork are retained. Metadata runs on a separate worker/core; tray
monitoring continues while files are read.

Artwork/indicator credit: zivvoz / DashX360, inspired by Microsoft Xbox 360.
Licences, attribution, build information and checksums are included. This
standalone app only changes the active sign-in session when requested; it does not edit
console configuration, account credentials, profile files, saved games,
NAND, or the configured default dashboard.
