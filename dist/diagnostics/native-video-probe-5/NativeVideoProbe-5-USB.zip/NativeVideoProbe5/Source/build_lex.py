#!/usr/bin/env python3
"""Wrap our original Lua XUIZ in a resource DLL, using xsdk's XEX writer.

17559's external PAM loader accepts .lex/.xex, then XdfLoadXex loads an
actual executable and reads its 'lua' resource. A loose .xzp is not this
container. No stock executable, resource or instruction is copied here.
"""
import argparse
import importlib.util
import struct
from pathlib import Path
from types import SimpleNamespace


def build(converter, package):
    spec = importlib.util.spec_from_file_location('xsdk_elf2xex', converter)
    writer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(writer)
    writer.IMAGE_BASE = 0x9B000000
    # The 90000000..9FFFFFFF XEX address range uses 4 KB pages.
    # Changing the address alone leaves the title writer's 64 KB page
    # descriptors and image-size calculation inconsistent with this range.
    writer.PAGE_BYTES = 0x1000
    writer.MODULE_TITLE = 9  # title DLL; same module type as retail .lex files
    writer.PE_EXECUTABLE_IMAGE |= 0x2000  # IMAGE_FILE_DLL
    writer.TLS_SLOTS = 0
    base = writer.IMAGE_BASE
    # DllMain: return TRUE for attach/detach. No imports, initialization,
    # thread, renderer, playback implementation, or console setting changes.
    code = bytes.fromhex('386000014e800020')  # li r3,1; blr
    sections = [
        dict(name='.text', address=base+0x10000, flags=6, size=len(code), data=code),
        dict(name='.rdata', address=base+0x20000, flags=2,
             size=len(package), data=package),
    ]
    image, runs = writer.build_image(sections)
    args = SimpleNamespace(stack_size=0x10000, version=0x500,
                           title_id=0x424C5052)
    writer.pe_headers(image, runs, base+0x10000, args.stack_size)
    resources = struct.pack('>I8sII', 20, b'lua', base+0x20000, len(package))
    data = bytearray(writer.build_xex(image, runs, base+0x10000, {}, resources, args))
    # Resource-only DLLs need no TLS allocation. Keep remaining header blocks
    # at their original offsets and recompute the writer's header digest.
    count = struct.unpack_from('>I', data, 20)[0]
    headers = list(struct.iter_unpack('>II', data[24:24+8*count]))
    headers = [(k, v) for k, v in headers if k != writer.HEADER_TLS_INFO]
    struct.pack_into('>I', data, 20, len(headers))
    data[24:24+8*count] = b''.join(struct.pack('>II', *h) for h in headers)+bytes(8)
    security = struct.unpack_from('>I', data, 16)[0]
    payload = struct.unpack_from('>I', data, 8)[0]
    struct.pack_into('>I', data, security+0x10c, 0x10000000)  # IMAGE_PAGE_SIZE_4KB
    data[security+0x164:security+0x178] = writer.sha1(
        data[security+0x17c:payload], data[:security+8])
    return bytes(data)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--converter', required=True, type=Path)
    p.add_argument('--package', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    package = a.package.read_bytes()
    if package[:8] != b'XUIZ\0\0\0\3':
        p.error('expected our XUIZ v3 Lua package')
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_bytes(build(a.converter, package))
    print('Original resource DLL:', a.output.name, a.output.stat().st_size,
          'bytes; base 9B000000; 4 KB pages; lua resource; no imports or TLS')


if __name__ == '__main__':
    main()
