#include "probe.h"
#include "xsdk/kernel.h"
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static bool no_module,no_load,no_unload,load_error,no_handle,bad_resource,section_error;
static unsigned loads,unloads,sections;
static const char *path="\\Device\\Mass0\\Probe\\Assets\\native-video.lex";
static unsigned char resource[22]="XUIZ\0\0\0\3";
void xsdk_log_write(const char *format,...) {(void)format;}
static NTSTATUS load(const char *p,uint32_t flags,uint32_t version,HANDLE *out) {
    assert(!strcmp(path,p)&&flags==9&&!version);loads++;
    *out=no_handle?0:456;return load_error?STATUS_OBJECT_NAME_NOT_FOUND:STATUS_SUCCESS;
}
static void unload(HANDLE h) {assert(h==456);unloads++;}
uint32_t XexGetModuleHandle(const char *name,HANDLE *module) {
    assert(!strcmp(name,"xboxkrnl.exe"));*module=no_module?0:123;return 0;
}
NTSTATUS XexGetProcedureAddress(HANDLE h,uint32_t ordinal,void **out) {
    assert(h==123&&(ordinal==0x199||ordinal==0x1a1));
    *out=ordinal==0x199?(no_load?NULL:(void*)load):(no_unload?NULL:(void*)unload);
    return STATUS_SUCCESS;
}
NTSTATUS XexGetModuleSection(HANDLE h,const char *name,const void **data,uint32_t *size) {
    assert(h==456&&!strcmp(name,"lua"));sections++;
    *data=resource;*size=bad_resource?4:sizeof resource;
    return section_error?STATUS_OBJECT_NAME_NOT_FOUND:STATUS_SUCCESS;
}
int main(void) {
    no_module=true;assert(!probe_check_package(path)&&!loads);no_module=false;
    no_load=true;assert(!probe_check_package(path)&&!loads);no_load=false;
    no_unload=true;assert(!probe_check_package(path)&&!loads);no_unload=false;
    load_error=true;assert(!probe_check_package(path)&&loads==1&&!unloads&&!sections);load_error=false;
    no_handle=true;assert(!probe_check_package(path)&&loads==2&&!unloads&&!sections);no_handle=false;
    section_error=true;assert(!probe_check_package(path)&&unloads==1);section_error=false;
    bad_resource=true;assert(!probe_check_package(path)&&unloads==2);bad_resource=false;
    resource[0]='B';assert(!probe_check_package(path)&&unloads==3);resource[0]='X';
    assert(probe_check_package(path)&&unloads==4&&sections==4);
    puts("PASS: actual DLL preflight adapter; exact path/ordinals/flags; export/load/resource failures; unload after every successful load");
}
