#include "probe.h"
#include "xsdk/kernel.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static bool no_module,no_export,null_export;
static unsigned resolved,calls;
static uint32_t returned;
static const char *expected;
static uint32_t launch(uint32_t user,const char *uri,uint32_t flags,void *context) {
    assert(user==255||user==2);assert(!strcmp(uri,expected));assert(flags==0x80000004&&!context);calls++;return returned;
}
uint32_t XexGetModuleHandle(const char *name,HANDLE *module) {
    assert(!strcmp(name,"xam.xex"));*module=123;return no_module?1:0;
}
NTSTATUS XexGetProcedureAddress(HANDLE module,uint32_t ordinal,void **address) {
    assert(module==123&&ordinal==0x4ac);resolved++;
    *address=null_export?NULL:(void *)launch;return no_export?STATUS_OBJECT_NAME_NOT_FOUND:STATUS_SUCCESS;
}
int main(void) {
    bool available=true;expected="videolibrary";
    assert(PROBE_NATIVE_FLAGS==0x80000004&&(PROBE_NATIVE_FLAGS&1)==0);
    no_module=true;assert(probe_native_launch(255,expected,&available)==0x80070032&&!available&&!resolved&&!calls);no_module=false;
    no_export=true;assert(probe_native_launch(255,expected,&available)==0x80070032&&!available&&!calls);no_export=false;
    null_export=true;assert(probe_native_launch(255,expected,&available)==0x80070032&&!available&&!calls);null_export=false;
    returned=0x80070005;assert(probe_native_launch(255,expected,&available)==returned&&available&&calls==1);
    expected="pam:\\Device\\Mass0\\A folder\\Assets\\native-video.lex:file://\\Device\\Mass0\\A folder\\selected.wmv";
    returned=0;assert(probe_native_launch(2,expected,&available)==0&&available&&calls==2);
    assert(probe_native_launch(4,expected,&available)==0x80070057&&!available&&calls==2);
    assert(probe_native_launch(255,"",&available)==0x80070057&&!available&&calls==2);
    assert(probe_native_launch(255,NULL,&available)==0x80070057&&!available&&calls==2);
    char long_uri[1020];memset(long_uri,'a',sizeof long_uri);long_uri[1019]=0;
    assert(probe_native_launch(255,long_uri,&available)==0x80070057&&!available&&calls==2);
    puts("PASS: real native URI adapter; corrected internal/activation flags, fallback disabled, ordinal/prototype, exact arguments, user/size bounds, export failures and HRESULT propagation");
}
