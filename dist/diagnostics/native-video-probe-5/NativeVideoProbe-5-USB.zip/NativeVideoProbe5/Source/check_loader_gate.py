#!/usr/bin/env python3
"""Bounded read-only check of the user-supplied 17559 external-module gate.

Executes only its suffix-selection instructions; strcmp is a host stub.
Does not execute a loader, native Lua, UI or playback. No reference bytes
are embedded in this script or included in the diagnostic package.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path


def check(image):
    base = 0x92000000
    def word(at):
        return struct.unpack_from('>I', image, at-base)[0]
    def string(at):
        return image[at-base:].split(b'\0', 1)[0].decode('ascii')
    assert string(0x9213f4c8) == '.xex'
    assert string(0x92102338) == '.lex'
    assert string(0x921022fc) == 'BuiltIn.'
    assert string(0x921022f4) == '.xzp'
    results = []
    for path, expected in [(r'\Device\Mass0\Probe\Assets\native-video.xzp', '80B04008'),
                           (r'\Device\Mass0\Probe\Assets\native-video.lex', 'accepted suffix'),
                           (r'\Device\Mass0\Probe\Assets\native-video.xex', 'accepted suffix'),
                           ('BuiltIn.Example.xzp', 'accepted suffix')]:
        encoded = path.encode()+b'\0'
        path_at, object_at = 0x10000000, 0x10001000
        def load(at):
            if at == object_at+24:
                return path_at
            return word(at)
        def cstring(at):
            if path_at <= at < path_at+len(encoded):
                return encoded[at-path_at:].split(b'\0', 1)[0].decode('ascii')
            return string(at)
        regs = [0]*32
        regs[10], regs[11] = 0x92140000, path_at+len(path)
        regs[28] = int(path.startswith(string(0x921022fc)) and path.endswith(string(0x921022f4)))
        regs[30], regs[31] = object_at, len(path)
        pc, cr, trace = 0x9291912c, {}, []
        for _ in range(64):
            if pc in (0x92919174, 0x92919230):
                outcome = 'accepted suffix' if pc == 0x92919174 else f'{regs[3]:08X}'
                assert outcome == expected, (path, outcome)
                results.append(dict(module=path, outcome=outcome, trace=[f'{at:08X}' for at in trace]))
                break
            trace.append(pc)
            instruction = word(pc)
            op, rd, ra = instruction>>26, (instruction>>21)&31, (instruction>>16)&31
            imm = instruction&65535
            signed = imm-(65536 if imm&32768 else 0)
            next_pc = pc+4
            if op in (14,15):
                regs[rd] = ((regs[ra] if ra else 0)+(signed<<(16 if op==15 else 0)))&0xffffffff
            elif op==32:
                regs[rd] = load((regs[ra]+signed)&0xffffffff)
            elif op==11:
                cr[((instruction>>23)&7)*4+2] = regs[ra] == (signed&0xffffffff)
            elif op==24:
                regs[ra] = regs[rd]|imm
            elif op==31:
                assert (instruction>>1)&1023 == 266  # add
                regs[rd] = (regs[ra]+regs[(instruction>>11)&31])&0xffffffff
            elif op==16:
                bo, bi = (instruction>>21)&31, (instruction>>16)&31
                assert bo in (4,12) and bi in cr
                if cr[bi] == (bo==12):
                    offset=instruction&0xfffc
                    next_pc=pc+offset-(65536 if offset&32768 else 0)
            elif op==18:
                offset=instruction&0x3fffffc
                target=pc+offset-(0x4000000 if offset&0x2000000 else 0)
                if instruction&1:
                    assert target==0x921997a0
                    a,b=cstring(regs[3]),cstring(regs[4])
                    regs[3]=0 if a==b else 1
                else:
                    next_pc=target
            else:
                raise AssertionError(hex(instruction))
            pc=next_pc
        else:
            raise AssertionError('gate did not terminate')
    return dict(scope='Bounded suffix gate only; host strcmp stub and precomputed BuiltIn predicate. Not a native loader/playback test.',
                image_sha256=hashlib.sha256(image).hexdigest(),results=results)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('decoded_dash',type=Path)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    report=check(a.decoded_dash.read_bytes())
    a.output.write_text(json.dumps(report,indent=2)+'\n')
    for result in report['results']:
        print(result['module'], result['outcome'])

if __name__=='__main__':
    main()
