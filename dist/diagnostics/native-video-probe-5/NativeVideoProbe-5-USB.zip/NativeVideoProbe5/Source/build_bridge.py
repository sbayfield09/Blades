#!/usr/bin/env python3
"""Compile original Lua bridges into 17559-style big-endian Lua 5.1 XUIZs.

Requires a Lua 5.1 luac. No retail code/resources are input or redistributed.
"""
import argparse
import struct
import subprocess
import tempfile
from pathlib import Path


class Lua51:
    def __init__(self, data):
        if data[:6] != b'\x1bLua\x51\x00' or len(data) < 12:
            raise ValueError('Lua 5.1 compiler required')
        self.data, self.at = data, 12
        self.endian = '<' if data[6] else '>'
        self.size_t = data[8]
        if data[7] != 4 or self.size_t not in (4, 8) or data[9:12] != b'\x04\x08\x00':
            raise ValueError('unsupported Lua 5.1 architecture')

    def take(self, n):
        if n < 0 or self.at + n > len(self.data):
            raise ValueError('truncated Lua chunk')
        b = self.data[self.at:self.at+n]
        self.at += n
        return b

    def uint(self, size=4):
        return int.from_bytes(self.take(size), 'little' if self.endian == '<' else 'big')

    def string(self):
        n = self.uint(self.size_t)
        b = self.take(n)
        if n and b[-1] != 0:
            raise ValueError('unterminated Lua string')
        return b

    def array(self, read):
        n = self.uint()
        if n > len(self.data):
            raise ValueError('unbounded Lua array')
        return [read() for _ in range(n)]

    def constant(self):
        t = self.uint(1)
        if t == 0:
            return t, None
        if t == 1:
            return t, self.take(1)
        if t == 3:
            return t, struct.unpack(self.endian+'d', self.take(8))[0]
        if t == 4:
            return t, self.string()
        raise ValueError('unknown Lua constant')

    def function(self):
        return (self.string(), self.uint(), self.uint(), self.take(4),
                self.array(self.uint), self.array(self.constant), self.array(self.function),
                self.array(self.uint), self.array(lambda: (self.string(), self.uint(), self.uint())),
                self.array(self.string))


def convert(data, endian='>', size_t=4):
    reader = Lua51(data)
    root = reader.function()
    if reader.at != len(data):
        raise ValueError('unreferenced Lua bytes')
    out = bytearray(b'\x1bLua\x51\x00' + bytes([endian == '<', 4, size_t, 4, 8, 0]))

    def uint(n, size=4):
        out.extend(n.to_bytes(size, 'little' if endian == '<' else 'big'))

    def string(b):
        uint(len(b), size_t)
        out.extend(b)

    def array(items, write):
        uint(len(items))
        for item in items:
            write(item)

    def constant(item):
        t, value = item
        uint(t, 1)
        if t == 1:
            out.extend(value)
        elif t == 3:
            out.extend(struct.pack(endian+'d', value))
        elif t == 4:
            string(value)

    def local(item):
        name, start, end = item
        string(name)
        uint(start)
        uint(end)

    def function(f):
        source, start, end, flags, code, constants, children, lines, locals_, up = f
        string(source)
        uint(start)
        uint(end)
        out.extend(flags)
        array(code, uint)
        array(constants, constant)
        array(children, function)
        array(lines, uint)
        array(locals_, local)
        array(up, string)

    function(root)
    return bytes(out)


def archive(entries):
    table, payload = bytearray(), bytearray()
    for name, data in entries:
        name = name.encode('ascii')
        if not 0 < len(name) <= 255:
            raise ValueError('invalid XUIZ name')
        table.extend(struct.pack('>IIB', len(data), len(payload), len(name)) + name)
        payload.extend(data)
    return struct.pack('>4s4IH', b'XUIZ', 3, 22+len(table)+len(payload), 0,
                       len(table), len(entries)) + table + payload


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--luac', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).parent
    with tempfile.TemporaryDirectory() as tmp:
        chunk = Path(tmp)/'main.lub'
        subprocess.run([str(args.luac.resolve()), '-s', '-o', str(chunk),
                        str(source/'native-video.lua')], check=True)
        original = chunk.read_bytes()
        native = convert(original)
        r = Lua51(original)
        if convert(native, r.endian, r.size_t) != original:
            raise ValueError('Lua architecture round trip failed')
        (args.output/'native-video.xzp').write_bytes(archive([
            ('main.lub', native), ('Manifest.xml', b'<pam><deps></deps></pam>')]))
        print(len(native), 'bytes; Lua 5.1 BE32 round trip verified')


if __name__ == '__main__':
    main()
