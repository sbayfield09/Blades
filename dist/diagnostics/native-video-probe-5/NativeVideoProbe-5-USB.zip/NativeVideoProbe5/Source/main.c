#include "probe.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/xam.h"
#include "xsdk/thread.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
int main(void) {
    xsdk_log_write("native-video-probe 5: 4KB-page LEX resource DLL; playback unverified");
    if(!XboxKrnlVersion||XboxKrnlVersion->major!=2||XboxKrnlVersion->minor!=0||XboxKrnlVersion->build!=17559) {
        xsdk_log_write("probe: STOP: this native URI route was inspected on retail 2.0.17559 only");return 1;
    }
    char folder[260],selected[260];
    if(!probe_paths(ExLoadedImageName,folder,selected)) {
        xsdk_log_write("probe: STOP: cannot resolve a physical installation path");return 1;
    }
    const char *name=strrchr(ExLoadedImageName,'\\');
    bool control=name&&!strcmp(name+1,"control.xex");
    bool raw_path=false;FILE *mode=fopen("game:/probe-mode.txt","rb");
    if(mode){char line[24]={0};if(fgets(line,sizeof line,mode)&&!strncmp(line,"path",4))raw_path=true;fclose(mode);}
    char uri[1020];
    if(control)snprintf(uri,sizeof uri,"videolibrary");
    else {
        struct stat st;
        if(stat(selected,&st)||!S_ISREG(st.st_mode)||!st.st_size) {
            xsdk_log_write("probe: STOP: selected.wmv missing/empty (errno=%d)",errno);return 1;
        }
        char asset[260];
        if(snprintf(asset,sizeof asset,"%s\\Assets\\native-video.lex",folder)>=(int)sizeof asset||stat(asset,&st)||!S_ISREG(st.st_mode)) {
            xsdk_log_write("probe: STOP: matching Assets/native-video package is missing");return 1;
        }
        if(!probe_check_package(asset)) {
            xsdk_log_write("probe: STOP: resource DLL preflight failed; no native handoff attempted");return 1;
        }
        if(!probe_uri(folder,selected,raw_path,uri))return 1;
    }
    unsigned user=255;
    for(unsigned i=0;i<4;i++)if(XamUserGetSigninState(i)){user=i;break;}
    xsdk_log_write("probe: mode=%s syntax=%s user=%u",control?"library-control":"selected-video",raw_path?"device-path":"file-uri",user);
    xsdk_log_write("probe: native XamLaunchURI begin flags=%08X uri=%s",PROBE_NATIVE_FLAGS,uri);
    bool available=false;uint32_t result=probe_native_launch(user,uri,&available);
    xsdk_log_write("probe: native XamLaunchURI returned=%08X available=%u",result,available);
    if(result&0x80000000u){xsdk_log_write("probe: STOP: native URI request returned an error; no manual launch fallback");return 1;}
    xsdk_log_write("probe: native request returned without an error; waiting up to 10s for title switch (not proof of playback)");
    for(unsigned i=0;i<100;i++)(void)xsdk_thread_sleep(100);
    xsdk_log_write("probe: STILL_RUNNING after 10s; native request did not terminate this title during observation; returning Home");
    return 0;
}
