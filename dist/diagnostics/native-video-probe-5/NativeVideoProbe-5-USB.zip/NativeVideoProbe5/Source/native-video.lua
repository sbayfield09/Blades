-- Original diagnostic only. The installed retail dash owns the player.
require("Xbox.Xui")
require("Xbox.App")

local scene, label, selected
local opened = false

local function checkpoint(message)
    -- A missing optional text visual must not prevent native playback.
    pcall(function() label:SetText(message) end)
end

local function play()
    if opened or not selected then return end
    opened = true
    checkpoint("Native bridge active: requesting Xbox video player...")
    local ok, err = pcall(function()
        Xbox.App.ExecuteEpixCommand("EcPlayVideo", {selected})
    end)
    if not ok then checkpoint("Native video request failed: " .. tostring(err)) end
end

function SetAppConfig(args)
end

function Main(args, resuming)
    selected = args
    scene = Xbox.XuiBase.CreateObject("XuiScene")
    pcall(function()
        label = Xbox.XuiBase.CreateObject("XuiText")
        label:SetWidth(1100)
        label:SetHeight(160)
        label:SetText("Native video bridge loaded; waiting for activation...")
        scene:AddChild(label)
    end)
    scene:Subscribe("TransitionEnd", play)
    return scene
end

-- 17559's PAM host calls this optional global with one boolean argument.
-- This also handles a programmatic scene without transition timelines.
function OnActivate(active)
    if active then play() end
end
