#include "probe.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include <string.h>

/* Resolve documented kernel ordinals, never a private address in dash.xex.
 * This loads only our import-free resource DLL, checks its resource, then
 * unloads it before asking XAM to switch titles. */
bool probe_check_package(const char *path) {
    HANDLE kernel=0,module=0;
    void *load_address=NULL,*unload_address=NULL;
    if(XexGetModuleHandle("xboxkrnl.exe",&kernel)||!kernel||
       XexGetProcedureAddress(kernel,0x199,&load_address)||!load_address||
       XexGetProcedureAddress(kernel,0x1A1,&unload_address)||!unload_address) {
        xsdk_log_write("probe: STOP: package load-check kernel exports unavailable");
        return false;
    }
    NTSTATUS (*load)(const char*,uint32_t,uint32_t,HANDLE*)=load_address;
    void (*unload)(HANDLE)=unload_address;
    NTSTATUS status=load(path,9,0,&module);
    xsdk_log_write("probe: package XexLoadImage status=%08X handle=%08X",(unsigned)status,(unsigned)module);
    if(status<0||!module)return false;
    const void *data=NULL;uint32_t size=0;
    status=XexGetModuleSection(module,"lua",&data,&size);
    bool valid=status>=0&&data&&size>=22&&!memcmp(data,"XUIZ\0\0\0\3",8);
    xsdk_log_write("probe: package lua resource status=%08X bytes=%u XUIZ=%u",(unsigned)status,size,valid);
    unload(module);
    xsdk_log_write("probe: package check unloaded DLL; Lua execution not tested by this check");
    return valid;
}
