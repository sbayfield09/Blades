#ifndef BLADES_NATIVE_VIDEO_PROBE_H
#define BLADES_NATIVE_VIDEO_PROBE_H
#include <stdbool.h>
#include <stdint.h>
#define PROBE_NATIVE_FLAGS UINT32_C(0x80000004)
bool probe_check_package(const char *path);
/* Separate diagnostic. No filename-in-reserved-bytes library workaround. */
bool probe_paths(const char *image,char folder[260],char selected[260]);
bool probe_launch_data(const char *folder,const char *selected,bool raw_path,uint8_t data[1020]);
bool probe_uri(const char *folder,const char *selected,bool raw_path,char uri[1020]);
/* Dynamic ordinal lookup only; no private native function addresses. */
uint32_t probe_native_launch(unsigned user,const char *uri,bool *available);
#endif
