#!/usr/bin/env python3
"""Check the actual diagnostic DLL's page geometry and embedded Lua resource.

Uses the sibling verify_xex.py in a distributed Source folder, or the project's
tools/verify_xex.py. Does not execute native code or establish console playback.
"""
import argparse
import hashlib
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from verify_xex import verify


def unpack(data):
    count = struct.unpack_from('>I', data, 20)[0]
    headers = dict(struct.iter_unpack('>II', data[24:24+8*count]))
    security, payload = struct.unpack_from('>I', data, 16)[0], struct.unpack_from('>I', data, 8)[0]
    offset = headers[0x3ff]
    length, encryption, compression = struct.unpack_from('>IHH', data, offset)
    assert encryption == 0 and compression == 1
    image = bytearray()
    at = payload
    for size, zeros in struct.iter_unpack('>II', data[offset+8:offset+length]):
        image.extend(data[at:at+size]); image.extend(bytes(zeros)); at += size
    image_size = struct.unpack_from('>I', data, security+4)[0]
    image.extend(bytes(image_size-len(image)))
    return headers, security, payload, image


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('dll', type=Path)
    p.add_argument('--previous-dll', type=Path)
    p.add_argument('--host-chunk', type=Path)
    p.add_argument('--extract-host', type=Path)
    a = p.parse_args()
    data = a.dll.read_bytes()
    verify(data, resource_dll=True)
    headers, security, payload, image = unpack(data)
    # Independent consumer: the high XEX address range selects 4 KB heap pages,
    # regardless of the self-reported page flag or the writer's constants.
    base = headers[0x10201]
    assert 0x90000000 <= base < 0xa0000000
    descriptors = struct.unpack_from('>I', data, security+0x180)[0]
    page_sizes = [struct.unpack_from('>I', data, security+0x184+i*24)[0] >> 4
                  for i in range(descriptors)]
    covered = sum(page_sizes)*4096
    assert covered == len(image)
    code_page = (headers[0x10100]-base)//4096
    assert struct.unpack_from('>I', data, security+0x184+code_page*24)[0]&15 == 1
    _, address, size = struct.unpack_from('>8sII', data, headers[0x2ff]+4)
    assert 0 <= address-base < address-base+size <= covered
    package = bytes(image[address-base:address-base+size])
    assert package[:8] == b'XUIZ\0\0\0\3'
    assert len(package) == struct.unpack_from('>I', package, 8)[0]
    table, count = struct.unpack_from('>IH', package, 16)
    at, entries = 22, {}
    for _ in range(count):
        size, offset, n = struct.unpack_from('>IIB', package, at)
        name = package[at+9:at+9+n].decode('ascii')
        start = 22+table+offset
        assert name not in entries and 0 < size <= len(package)-start
        entries[name] = package[start:start+size]
        at += 9+n
    assert at == 22+table and set(entries) == {'main.lub', 'Manifest.xml'}
    assert entries['Manifest.xml'] == b'<pam><deps></deps></pam>'
    print(f'PASS: {descriptors} 4 KB descriptors cover {covered} bytes; entry code page and complete Lua resource are covered')
    print('Lua package SHA256:', hashlib.sha256(package).hexdigest())
    if a.previous_dll:
        old = a.previous_dll.read_bytes()
        old_h, old_s, _, old_image = unpack(old)
        old_count = struct.unpack_from('>I', old, old_s+0x180)[0]
        assert old_count*4096 < old_h[0x10100]-old_h[0x10201]
        try:
            verify(old, resource_dll=True)
        except ValueError as error:
            assert 'page size disagrees with image address range' in str(error)
            print('PASS: previous diagnostic4 DLL rejected for wrong heap/page geometry')
        else:
            raise AssertionError('old malformed DLL accepted')
        _, old_address, old_size = struct.unpack_from('>8sII', old, old_h[0x2ff]+4)
        assert bytes(old_image[old_address-old_h[0x10201]:old_address-old_h[0x10201]+old_size]) == package
        print('PASS: embedded Lua package identical to diagnostic4; geometry correction isolated')
    for kind in ('flag', 'image'):
        bad = bytearray(data)
        if kind == 'flag':
            struct.pack_into('>I', bad, security+0x10c, 0)
        else:
            bad[payload+0x30] ^= 1
        try:
            verify(bad, resource_dll=True)
        except ValueError as error:
            assert ('page size disagrees' if kind == 'flag' else 'image digest mismatch') in str(error)
            print(f'PASS: {kind} mutation rejected: {error}')
        else:
            raise AssertionError('corrupt resource DLL accepted')
    if a.host_chunk:
        from build_bridge import convert, Lua51
        host = a.host_chunk.read_bytes()
        architecture = Lua51(host)
        extracted = convert(entries['main.lub'], architecture.endian, architecture.size_t)
        assert extracted == host
        if a.extract_host:
            a.extract_host.write_bytes(extracted)
        print('PASS: Lua extracted from final DLL round-trips to original host compiler output')


if __name__ == '__main__':
    main()
