#include "probe.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void) {
    char folder[260],selected[260];uint8_t data[1020];
    assert(probe_paths("\\Device\\Mass1\\NativeVideoProbe\\default.xex",folder,selected));
    assert(!strcmp(folder,"\\Device\\Mass1\\NativeVideoProbe"));
    assert(!strcmp(selected,"\\Device\\Mass1\\NativeVideoProbe\\selected.wmv"));
    assert(probe_launch_data(folder,selected,false,data)&&data[7]==12&&data[11]==255);
    assert(!strcmp((char *)data+12,"pam:\\Device\\Mass1\\NativeVideoProbe\\Assets\\native-video.lex:file://\\Device\\Mass1\\NativeVideoProbe\\selected.wmv"));
    assert(probe_launch_data(folder,selected,true,data)&&!strcmp((char *)data+12,"pam:\\Device\\Mass1\\NativeVideoProbe\\Assets\\native-video.lex:\\Device\\Mass1\\NativeVideoProbe\\selected.wmv"));
    for(unsigned i=12+strlen((char *)data+12)+1;i<sizeof data;i++)assert(!data[i]);
    assert(!probe_paths("game:\\default.xex",folder,selected));
    assert(!probe_paths("\\Device\\Mass0\\bad#name\\default.xex",folder,selected));
    assert(!probe_paths("\\Device\\Mass0\\..\\default.xex",folder,selected));
    assert(!probe_launch_data("\\Device\\Mass0\\a\n","\\Device\\Mass0\\selected.wmv",false,data));
    char long_name[280];memset(long_name,'a',sizeof long_name);memcpy(long_name,"\\Device\\",8);long_name[279]=0;
    assert(!probe_paths(long_name,folder,selected));
    /* A long but valid module+selection must still fit the real 1020-byte ABI. */
    long_name[245]=0;strcpy(long_name+245,"\\default.xex");
    assert(probe_paths(long_name,folder,selected));
    assert(probe_launch_data(folder,selected,false,data));
    char uri[1020];
    assert(probe_uri(folder,selected,false,uri)&&!strncmp(uri,"pam:",4)&&strstr(uri,":file://\\Device\\"));
    assert(probe_uri(folder,selected,true,uri)&&strstr(uri,".lex:\\Device\\")&&!strstr(uri,"file://"));
    assert(!probe_uri("game:\\",selected,false,uri));
    assert(!probe_uri(folder,"\\Device\\Mass0\\bad#file.wmv",false,uri));
    puts("PASS: physical paths survive title handoff; exact WMV selection; bounded PAM data; unsafe/unresolved paths rejected");
}
