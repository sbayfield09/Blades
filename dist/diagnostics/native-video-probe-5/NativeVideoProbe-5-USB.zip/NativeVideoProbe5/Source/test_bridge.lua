-- Real Lua 5.1 VM; Xbox services mocked. Native activation remains unverified.
local chunk = arg[1]
local selected = "file://\\Device\\Mass1\\A folder\\a 'quoted' video.wmv"
local function run(order, fail_visual, fail_command)
    local handler, count, text = nil, 0, ""
    local label = {}
    function label:SetWidth(n) assert(n == 1100) end
    function label:SetHeight(n) assert(n == 160) end
    function label:SetText(s) text = s end
    local scene = {}
    function scene:AddChild(child) assert(child == label) end
    function scene:Subscribe(event, callback)
        assert(event == "TransitionEnd"); handler = callback
    end
    Xbox = {
        XuiBase = {CreateObject = function(name)
            if name == "XuiScene" then return scene end
            assert(name == "XuiText")
            if fail_visual then error("optional text unavailable") end
            return label
        end},
        App = {ExecuteEpixCommand = function(name, params)
            assert(name == "EcPlayVideo" and #params == 1 and params[1] == selected)
            count = count + 1
            if fail_command then error("mock native command failure") end
        end}
    }
    package.loaded["Xbox.Xui"] = nil
    package.loaded["Xbox.App"] = nil
    package.preload["Xbox.Xui"] = function() return Xbox end
    package.preload["Xbox.App"] = function() return Xbox.App end
    assert(loadfile(chunk))()
    OnActivate(false); assert(count == 0)
    SetAppConfig(selected)
    assert(Main(selected, false) == scene and handler and count == 0)
    if not fail_visual then assert(text:find("bridge loaded", 1, true)) end
    if order == "activate" then OnActivate(true) else handler() end
    assert(count == 1)
    OnActivate(false); OnActivate(true); handler(); assert(count == 1)
    if fail_command and not fail_visual then
        assert(text:find("mock native command failure", 1, true))
    end
end
run("activate", false, false)
run("transition", false, false)
run("activate", true, false)
run("transition", false, true)
print("PASS: exact selection; activation/transition ordering; no restart; optional checkpoint failure; command errors visible (Xbox services mocked)")
