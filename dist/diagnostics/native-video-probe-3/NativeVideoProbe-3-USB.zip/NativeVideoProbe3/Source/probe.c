#include "probe.h"
#include <stdio.h>
#include <string.h>
static bool physical(const char *s) {
    if(!s||strncmp(s,"\\Device\\",8))return false;
    for(const unsigned char *p=(const unsigned char *)s;*p;p++)
        if(*p<32||*p>126||strchr(":#?*\"|<>",*p))return false;
    return !strstr(s,"\\..\\")&&!strstr(s,"\\.\\");
}
bool probe_paths(const char *image,char folder[260],char selected[260]) {
    if(!physical(image)||strlen(image)>=260)return false;
    const char *last=strrchr(image,'\\');
    if(!last||last==image||!last[1])return false;
    size_t n=(size_t)(last-image);
    memcpy(folder,image,n);folder[n]=0;
    return snprintf(selected,260,"%s\\selected.wmv",folder)<260;
}
bool probe_launch_data(const char *folder,const char *selected,bool raw_path,uint8_t data[1020]) {
    if(!physical(folder)||!physical(selected)||strlen(folder)>=260||strlen(selected)>=260)return false;
    memset(data,0,1020);data[7]=12;data[11]=255;
    /* The verified 17559 command-12 PAM route splits module:arguments once.
       Use physical paths because game: is remapped after the title exits.
       file:// is a candidate transport to test, not a proven playback ABI. */
    int n=snprintf((char *)data+12,1008,"pam:%s\\Assets\\native-video.xzp:%s%s",
        folder,raw_path?"":"file://",selected);
    return n>0&&n<1008;
}
bool probe_uri(const char *folder,const char *selected,bool raw_path,char uri[1020]) {
    if(!physical(folder)||!physical(selected)||strlen(folder)>=260||strlen(selected)>=260)return false;
    /* XAM's own URI routing table expands pam: to dash:pam:. Let XAM
       construct launch data and perform its normal launch/URI validation. */
    int n=snprintf(uri,1020,"pam:%s\\Assets\\native-video.xzp:%s%s",folder,raw_path?"":"file://",selected);
    return n>0&&n<1019; /* Native XamLaunchURI requires strlen+1 < 1020. */
}
