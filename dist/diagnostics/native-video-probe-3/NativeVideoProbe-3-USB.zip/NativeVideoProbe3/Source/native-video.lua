-- Original diagnostic bridge: request the retail player's own activation
-- command after a native scene enters the display. No custom playback/UI.
-- The command resolves its own module/resources in the retail dash context.
require("Xbox.Xui")
require("Xbox.App")

function SetAppConfig(args)
end

function Main(args, resuming)
    local scene = Xbox.XuiBase.CreateObject("XuiScene")
    local opened = false
    scene:Subscribe("TransitionEnd", function()
        if not opened then
            opened = true
            Xbox.App.ExecuteEpixCommand("EcPlayVideo", {args})
        end
    end)
    return scene
end
