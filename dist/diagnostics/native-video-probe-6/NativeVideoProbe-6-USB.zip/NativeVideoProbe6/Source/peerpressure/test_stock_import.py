#!/usr/bin/env python3
"""Private firmware fixture check; never distribute the input stock images."""
import argparse,ctypes,json,struct
from pathlib import Path
class Plan(ctypes.Structure):
    _fields_=[('offset',ctypes.c_uint32),('original',ctypes.c_uint32*4),('replacement',ctypes.c_uint32*4)]
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('core',type=Path);p.add_argument('reference',type=Path);a=p.parse_args()
    fn=ctypes.CDLL(str(a.core.resolve())).media_import_plan
    fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_uint32,ctypes.POINTER(Plan)]
    fn.restype=ctypes.c_bool
    r=a.reference;raw=(r/'dash-17559.xex').read_bytes();payload=struct.unpack_from('>I',raw,8)[0];header=raw[:payload]
    image=bytearray((r/'dash-17559.pe').read_bytes());base=0x92000000
    imports=json.loads((r/'dash-17559.imports.json').read_text());target=json.loads((r/'xam-17559-exports.json').read_text())['XdfLoadXex']['address']
    offset=imports['xam.xex:0656:1']-base
    stub=struct.pack('>4I',0x3d600000|(target>>16),0x616b0000|(target&65535),0x7d6903a6,0x4e800420)
    image[offset:offset+16]=stub
    def run(im):
        h=ctypes.create_string_buffer(header);i=ctypes.create_string_buffer(bytes(im));plan=Plan()
        return fn(h,len(header),i,len(im),base,target,0x9b102000,ctypes.byref(plan)),plan
    ok,plan=run(image);assert ok and plan.offset==offset
    assert struct.pack('>4I',*plan.original)==stub
    redirected=image.copy()
    redirected[offset:offset+16]=struct.pack('>4I',*plan.replacement)
    assert redirected[:offset]==image[:offset] and redirected[offset+16:]==image[offset+16:]
    assert struct.unpack_from('>4I',redirected,offset)==(0x3d609b10,0x616b2000,0x7d6903a6,0x4e800420)
    redirected[offset:offset+16]=struct.pack('>4I',*plan.original)
    assert redirected==image
    second=next(v-base for k,v in imports.items() if k.startswith('xam.xex:') and k.endswith(':1') and v-base!=offset)
    image[second:second+16]=stub;assert not run(image)[0]
    image[second:second+16]=bytes(16);image[offset+8]^=1;assert not run(image)[0]
    print(f'PASS: supplied17559 dashboard import table selects the XDF thunk at RVA{offset:08X}; only its16 bytes change and restore exactly; duplicate or modified thunks refused; no fixed function address needed at runtime')
if __name__=='__main__':main()
