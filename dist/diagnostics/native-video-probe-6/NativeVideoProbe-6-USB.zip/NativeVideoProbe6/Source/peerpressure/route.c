#include "route.h"
static uint32_t be(const uint8_t *p) {
    return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];
}
static bool bytes(const uint8_t *p,const char *s,size_t n) {
    for(size_t i=0;i<n;i++)if(p[i]!=(uint8_t)s[i])return false;
    return true;
}
static bool xam_name(const uint8_t *names,size_t length,unsigned index) {
    size_t at=0;
    for(unsigned i=0;i<=index;i++) {
        if(at>=length)return false;
        size_t start=at;
        while(at<length&&names[at])at++;
        if(at==length)return false;
        if(i==index)return at-start==7&&bytes(names+start,"xam.xex",7);
        at=(at+4)&~(size_t)3;
    }
    return false;
}
static bool resolved_target(const uint8_t *p,uint32_t target) {
    uint32_t a=be(p),b=be(p+4),low=b&65535,address;
    if((a&0xffff0000)!=0x3d600000||be(p+8)!=0x7d6903a6||be(p+12)!=0x4e800420)return false;
    if((b&0xffff0000)==0x396b0000)address=(a<<16)+(uint32_t)(int32_t)(int16_t)low;
    else if((b&0xffff0000)==0x616b0000)address=(a<<16)|low;
    else return false;
    return address==target;
}
bool media_import_plan(const uint8_t *header,size_t header_size,const uint8_t *image,
                       size_t image_size,uint32_t image_base,uint32_t original_target,
                       uint32_t replacement_target,MediaImportPlan *plan) {
    if(!header||!image||!plan||header_size<24||header_size>1048576||image_size>33554432||
       !bytes(header,"XEX2",4)||!original_target||!replacement_target)return false;
    uint32_t count=be(header+20),imports=0;
    if(count>(header_size-24)/8)return false;
    for(uint32_t i=0;i<count;i++) {
        const uint8_t *h=header+24+8*i;
        if(be(h)==0x103ff) {if(imports)return false;imports=be(h+4);}
    }
    if(!imports||imports>header_size-12)return false;
    const uint8_t *table=header+imports;
    uint32_t length=be(table),names_size=be(table+4),libraries=be(table+8);
    if(length<12||length>header_size-imports||names_size>length-12||libraries>128)return false;
    size_t at=12+names_size;unsigned matches=0;
    /* library count describes the name table, not the number of records.
       Retail17559 dash splits xam.xex into two records before the kernel. */
    unsigned records=0;
    while(at<length) {
        if(++records>4096)return false;
        if(at>length||length-at<40)return false;
        const uint8_t *record=table+at;
        uint32_t size=be(record);unsigned name=(unsigned)record[36]<<8|record[37];
        unsigned slots=(unsigned)record[38]<<8|record[39];
        if(size<40||size>length-at||size!=40+4u*slots||name>=libraries)return false;
        if(xam_name(table+12,names_size,name))for(unsigned s=0;s<slots;s++) {
            uint32_t address=be(record+40+4*s);
            if(address<image_base||image_size<16||address-image_base>image_size-16||(address&3))continue;
            uint32_t offset=address-image_base;
            if(!resolved_target(image+offset,original_target))continue;
            if(matches&&plan->offset==offset)continue;
            if(++matches>1)return false;
            plan->offset=offset;
            for(unsigned j=0;j<4;j++)plan->original[j]=be(image+offset+4*j);
        }
        at+=size;
    }
    if(at!=length||matches!=1)return false;
    plan->replacement[0]=0x3d600000|(replacement_target>>16);
    plan->replacement[1]=0x616b0000|(replacement_target&65535);
    plan->replacement[2]=0x7d6903a6;plan->replacement[3]=0x4e800420;
    return true;
}
bool media_bridge_path(const char *path) {
    static const char suffix[]="\\Assets\\native-video.lex";
    if(!path)return false;
    size_t n=0;while(n<260&&path[n]) {
        unsigned char c=(unsigned char)path[n];
        if(c<32||c>126||c==':'||c=='#'||c=='?'||c=='*'||c=='"'||c=='|'||c=='<'||c=='>')return false;
        n++;
    }
    if(n==260||n<8+sizeof suffix-1||!bytes((const uint8_t*)path,"\\Device\\",8))return false;
    for(size_t i=0;i<n;i++)if(path[i]=='\\'&&i+2<n&&path[i+1]=='.'&&
        (path[i+2]=='\\'||(path[i+2]=='.'&&i+3<n&&path[i+3]=='\\')))return false;
    return bytes((const uint8_t*)path+n-(sizeof suffix-1),suffix,sizeof suffix-1);
}

uint32_t media_route_load(const MediaLoader *loader,const char *path,void *overlapped,
                         uint32_t option,uint32_t type,void *context,uint32_t *out) {
    if(!media_bridge_path(path)||option||(type!=8&&type!=9)||context||!out)
        return loader->fallback(path,overlapped,option,type,context,out);
    *out=0;uint32_t module=0,status=loader->load(path,&module);
    loader->log("Blades bridge local load",status);
    if(status&0x80000000u)return status|0x10000000u;
    if(!module)return 0x8007000b;
    if(!loader->valid(module)) {
        loader->unload(module);loader->log("Bridge resource rejected",0x8007000b);
        return 0x8007000b;
    }
    *out=module;
    /* A synchronous success is the same contract as XDF's existing fast path.
       The caller checks E_PENDING explicitly before touching overlapped state. */
    loader->log("Bridge returned to native PAM host",0);
    return 0;
}
