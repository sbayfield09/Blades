# Peer Pressure native-media helper design

Peer Pressure is the deployment target; DashLaunch is excluded. The official
Softmod Features wiki supports per-title DLL sideloading and explicitly requires
a title DLL whose hooks remain inside the loaded title's own XEX. System DLLs
and kernel/XAM hooks are outside that supported contract.

Source: https://github.com/grimdoomer/Xbox360PeerPressure/wiki/Softmod-Features#dll-sideloading
The matching DLL is loaded after the target image is mapped and before its entry
point/CRT. It unloads when the title exits. Thus a helper can be sideloaded into
the stock dashboard itself, rather than trying to keep a Blades-side system
module alive across the title switch.

Implemented diagnostic scope: intercept the stock dashboard's own import of XdfLoadXex, solely
for an explicitly named Blades bridge. All other requests call the dynamically
resolved original XAM export. The handler loads our original bridge locally
through the kernel API already proven on the user's console. This avoids asking
the component catalog to resolve a filename absent from its installed manifest.
Neither XAM nor kernel code is modified. The title-scoped import is restored at
helper detach if it still contains our own redirect.

Guards: retail17559 and matching dashboard execution ID/version, bounded XEX
header/import parsing, one unambiguous matching resolved import thunk, expected
instruction shape and export address, and exact bridge filename/path constraints.
Refuse an unknown or previously modified import rather than overwrite it.
No background threads, system DLL, CRT initialization or persistent patch file.

This is a diagnostic implementation, not a working-player claim. Native behavior
requires hardware validation. INI syntax follows the official v1.0.477 Peer
Pressure example; existing sideload configuration must be preserved. The first
hardware check must establish helper attachment/forwarding independently of
Lua startup/video playback, with local logs. Stock binaries are not distributed.
