#include "route.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static unsigned loads,unloads,fallbacks;
static uint32_t returned,handle;
static bool valid;
static const char *selected="\\Device\\Mass0\\Blades\\Assets\\native-video.lex";
static uint32_t load(const char *path,uint32_t *out) {assert(!strcmp(path,selected));loads++;*out=handle;return returned;}
static bool check(uint32_t h) {assert(h==handle);return valid;}
static void unload(uint32_t h) {assert(h==handle);unloads++;}
static uint32_t fallback(const char *p,void *o,uint32_t a,uint32_t t,void *c,uint32_t *out) {
    (void)p;(void)o;(void)a;(void)t;(void)c;(void)out;fallbacks++;return 0x8b050008;
}
static void log_status(const char *m,uint32_t s) {(void)m;(void)s;}
int main(void) {
    assert(media_bridge_path(selected));
    const char *bad[]={0,"game:\\Assets\\native-video.lex","\\Device\\Mass0\\other.lex",
        "\\Device\\Mass0\\..\\Assets\\native-video.lex","\\Device\\Mass0\\.\\Assets\\native-video.lex",
        "\\Device\\Mass0\\A?\\Assets\\native-video.lex","\\Device\\Mass0\\Assets\\native-video.lex.extra"};
    for(unsigned i=0;i<sizeof bad/sizeof *bad;i++)assert(!media_bridge_path(bad[i]));
    char long_path[261];memset(long_path,'x',260);long_path[260]=0;assert(!media_bridge_path(long_path));
    MediaLoader ops={load,check,unload,fallback,log_status};uint32_t out=55;
    assert(media_route_load(&ops,"stock.lex",0,0,8,0,&out)==0x8b050008&&fallbacks==1&&!loads&&out==55);
    assert(media_route_load(&ops,selected,0,1,8,0,&out)==0x8b050008&&fallbacks==2&&!loads);
    assert(media_route_load(&ops,selected,0,0,7,0,&out)==0x8b050008&&fallbacks==3&&!loads);
    assert(media_route_load(&ops,selected,0,0,8,(void*)1,&out)==0x8b050008&&fallbacks==4&&!loads);
    assert(media_route_load(&ops,selected,0,0,8,0,0)==0x8b050008&&fallbacks==5&&!loads);
    returned=0xc000007b;assert(media_route_load(&ops,selected,0,0,8,0,&out)==0xd000007b&&out==0&&loads==1);
    returned=0;handle=0;assert(media_route_load(&ops,selected,0,0,8,0,&out)==0x8007000b&&loads==2);
    handle=123;valid=false;assert(media_route_load(&ops,selected,0,0,8,0,&out)==0x8007000b&&out==0&&unloads==1);
    valid=true;unsigned char overlap[28];memset(overlap,0xa5,sizeof overlap);
    assert(media_route_load(&ops,selected,overlap,0,9,0,&out)==0&&out==123&&unloads==1);
    for(unsigned i=0;i<sizeof overlap;i++)assert(overlap[i]==0xa5);
    puts("PASS: scoped local-load dispatch; unrelated/unsupported calls forwarded; native errors preserved; invalid modules released; synchronous success leaves overlapped untouched");
}
