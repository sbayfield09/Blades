/* Original Peer Pressure title DLL. No CRT, heap, threads or OS-code hooks.
 * It redirects one import in the stock dashboard's own image, before entry. */
#include "route.h"
#include "xsdk/kernel.h"
#include <stdint.h>

typedef uint32_t (*XdfLoad)(const char*,void*,uint32_t,uint32_t,void*,HANDLE*);
typedef NTSTATUS (*KernelLoad)(const char*,uint32_t,uint32_t,HANDLE*);
typedef void (*KernelUnload)(HANDLE);
typedef void *(*HeaderField)(const void*,uint32_t);
static XdfLoad original_load;
static KernelLoad local_load;
static KernelUnload local_unload;
static HeaderField header_field;
static MediaImportPlan saved_plan;
static uint8_t *dashboard_image;
static bool attached;
static const char log_path[]="\\Device\\Harddisk0\\Partition1\\PeerPressure\\SideLoading\\BladesNativeMedia.log";

static void log_status(const char *message,uint32_t status,bool reset) {
    char text[160];size_t n=0;
    while(message[n]&&n<140){text[n]=message[n];n++;}
    text[n++]=' ';
    const char hex[]="0123456789ABCDEF";
    for(unsigned i=0;i<8;i++)text[n++]=hex[(status>>(28-4*i))&15];
    text[n++]='\r';text[n++]='\n';
    ANSI_STRING name={(uint16_t)(sizeof log_path-1),sizeof log_path,log_path};
    OBJECT_ATTRIBUTES attr={0,&name,0x40};IO_STATUS_BLOCK io={0};HANDLE file=0;
    NTSTATUS s=NtCreateFile(&file,(reset?GENERIC_WRITE:4u)|SYNCHRONIZE,&attr,&io,0,FILE_ATTRIBUTE_NORMAL,
                           FILE_SHARE_READ|FILE_SHARE_WRITE,reset?FILE_OVERWRITE_IF:FILE_OPEN_IF,
                           FILE_SYNCHRONOUS_IO_NONALERT|FILE_NON_DIRECTORY_FILE);
    if(NT_SUCCESS(s)&&file) {
        const uint64_t end=UINT64_MAX;
        (void)NtWriteFile(file,0,0,0,&io,text,(uint32_t)n,&end);
        (void)NtFlushBuffersFile(file,&io);(void)NtClose(file);
    }
}
static void flush_code(void *address) {
    uintptr_t line=(uintptr_t)address&~(uintptr_t)127;
    uintptr_t last=((uintptr_t)address+15)&~(uintptr_t)127;
    __asm__ volatile("dcbst 0,%0\n dcbst 0,%1\n sync\n icbi 0,%0\n icbi 0,%1\n sync\n isync"::"r"(line),"r"(last):"memory");
}
static void *xex_header(HANDLE module) {
    return module?*(void**)((uintptr_t)module+0x58):0;
}
static uint32_t load_local(const char *path,HANDLE *out) {return (uint32_t)local_load(path,9,0,out);}
static bool valid_bridge(HANDLE module) {
    const uint8_t *execution=header_field(xex_header(module),0x40006);
    const void *resource=0;uint32_t bytes=0;
    return execution&&*(const uint32_t*)(execution+12)==0x424c5052u&&
           NT_SUCCESS(XexGetModuleSection(module,"lua",&resource,&bytes))&&resource&&bytes>=22&&
           *(const uint32_t*)resource==0x5855495a&&*((const uint32_t*)resource+1)==3;
}
static void release_local(HANDLE module) {local_unload(module);}
static uint32_t fallback_load(const char *path,void *overlapped,uint32_t option,
                              uint32_t type,void *context,HANDLE *out) {
    return original_load(path,overlapped,option,type,context,out);
}
static void route_log(const char *message,uint32_t status) {log_status(message,status,false);}
static const MediaLoader loader={load_local,valid_bridge,release_local,fallback_load,route_log};
static uint32_t route_load(const char *path,void *overlapped,uint32_t option,
                           uint32_t type,void *context,HANDLE *out) {
    return media_route_load(&loader,path,overlapped,option,type,context,out);
}
static bool words_match(const uint32_t *words) {
    if(!dashboard_image)return false;
    const volatile uint32_t *at=(const volatile uint32_t*)(dashboard_image+saved_plan.offset);
    for(unsigned i=0;i<4;i++)if(at[i]!=words[i])return false;
    return true;
}
static bool attach(void) {
    if(!XboxKrnlVersion||XboxKrnlVersion->major!=2||XboxKrnlVersion->minor!=0||XboxKrnlVersion->build!=17559) {
        log_status("Unsupported kernel; no redirect",0x80070032,true);return false;
    }
    HANDLE kernel=0,xam=0,dash=0;void *address=0;
    if(XexGetModuleHandle("xboxkrnl.exe",&kernel)||XexGetModuleHandle("xam.xex",&xam)||
       XexGetModuleHandle("dash.xex",&dash)||!kernel||!xam||!dash)return false;
    if(!NT_SUCCESS(XexGetProcedureAddress(kernel,0x12b,&address))||!address)return false;
    header_field=(HeaderField)address;
    if(!NT_SUCCESS(XexGetProcedureAddress(kernel,0x199,&address))||!address)return false;
    local_load=(KernelLoad)address;
    if(!NT_SUCCESS(XexGetProcedureAddress(kernel,0x1a1,&address))||!address)return false;
    local_unload=(KernelUnload)address;
    if(!NT_SUCCESS(XexGetProcedureAddress(xam,0x656,&address))||!address)return false;
    original_load=(XdfLoad)address;
    const uint8_t *header=xex_header(dash);
    const uint8_t *execution=header_field(header,0x40006);
    if(!execution||*(const uint32_t*)(execution+12)!=0xfffe07d1u||
       *(const uint32_t*)(execution+4)!=0x20449700u) {
        log_status("Unsupported dashboard; no redirect",0x80070032,true);return false;
    }
    dashboard_image=*(uint8_t**)((uintptr_t)dash+0x1c);
    uint32_t image_bytes=*(uint32_t*)((uintptr_t)dash+0x38);
    uint32_t header_bytes=*(const uint32_t*)(header+8);
    if(!media_import_plan(header,header_bytes,dashboard_image,image_bytes,(uint32_t)(uintptr_t)dashboard_image,
                          (uint32_t)(uintptr_t)original_load,(uint32_t)(uintptr_t)route_load,&saved_plan)) {
        log_status("No unique compatible dashboard import; no redirect",0x80070032,true);return false;
    }
    if(!words_match(saved_plan.original))return false;
    volatile uint32_t *at=(volatile uint32_t*)(dashboard_image+saved_plan.offset);
    for(unsigned i=0;i<4;i++)at[i]=saved_plan.replacement[i];
    flush_code((void*)at);attached=true;
    log_status("Peer Pressure title helper attached; dashboard import only",0,true);
    return true;
}
int helper_entry(HANDLE module,uint32_t reason,void *reserved) {
    (void)module;(void)reserved;
    if(reason==1) {
        if(!attach())log_status("Helper inactive; normal dashboard routing retained",0x80070032,false);
    } else if(reason==0&&attached) {
        HANDLE dash=0;
        if(!XexGetModuleHandle("dash.xex",&dash)&&dash&&words_match(saved_plan.replacement)) {
            volatile uint32_t *at=(volatile uint32_t*)(dashboard_image+saved_plan.offset);
            for(unsigned i=0;i<4;i++)at[i]=saved_plan.original[i];
            flush_code((void*)at);
        }
        attached=false;
    }
    return 1;
}
