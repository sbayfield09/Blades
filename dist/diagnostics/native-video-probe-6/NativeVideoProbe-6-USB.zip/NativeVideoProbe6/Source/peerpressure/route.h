#ifndef BLADES_PEERPRESSURE_ROUTE_H
#define BLADES_PEERPRESSURE_ROUTE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
typedef struct { uint32_t offset, original[4], replacement[4]; } MediaImportPlan;
/* Read-only planning. Image/header data are PPC big-endian bytes. */
bool media_import_plan(const uint8_t *header,size_t header_size,const uint8_t *image,
                       size_t image_size,uint32_t image_base,uint32_t original_target,
                       uint32_t replacement_target,MediaImportPlan *plan);
bool media_bridge_path(const char *path);
typedef struct {
    uint32_t (*load)(const char*,uint32_t*);
    bool (*valid)(uint32_t);
    void (*unload)(uint32_t);
    uint32_t (*fallback)(const char*,void*,uint32_t,uint32_t,void*,uint32_t*);
    void (*log)(const char*,uint32_t);
} MediaLoader;
uint32_t media_route_load(const MediaLoader *loader,const char *path,void *overlapped,
                         uint32_t option,uint32_t type,void *context,uint32_t *out);
#endif
