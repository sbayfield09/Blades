#include "route.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static void put(unsigned char *p,uint32_t n){p[0]=n>>24;p[1]=n>>16;p[2]=n>>8;p[3]=n;}
static void fixture(unsigned char *h,unsigned char *im) {
    memset(h,0,1024);memset(im,0,256);memcpy(h,"XEX2",4);
    put(h+20,1);put(h+24,0x103ff);put(h+28,512);
    put(h+512,64);put(h+516,8);put(h+520,1);memcpy(h+524,"xam.xex",8);
    unsigned char *r=h+532;put(r,44);r[38]=0;r[39]=1;put(r+40,0x92000020);
    put(im+32,0x3d60817f);put(im+36,0x616b6980);put(im+40,0x7d6903a6);put(im+44,0x4e800420);
}
int main(void) {
    unsigned char h[1024],im[256];MediaImportPlan plan;fixture(h,im);
    assert(media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    assert(plan.offset==32&&plan.original[0]==0x3d60817f&&plan.replacement[0]==0x3d609b10&&plan.replacement[1]==0x616b2000);
    put(im+32,0x3d608180);put(im+36,0x396be980); /* signed addi:81800000-5760 =817FE980 */
    assert(media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817fe980,0x9b102000,&plan));
    fixture(h,im);put(im+40,0x60000000);assert(!media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    fixture(h,im);put(h+516,UINT32_MAX);assert(!media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    fixture(h,im);put(h+532,UINT32_MAX);assert(!media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    fixture(h,im);put(h+532+40,0x920000fc);assert(!media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    fixture(h,im);put(h+532+40,0x92000022);assert(!media_import_plan(h,sizeof h,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    fixture(h,im);for(unsigned n=0;n<24;n++)assert(!media_import_plan(h,n,im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan));
    uint32_t random=12345;
    for(unsigned test=0;test<10000;test++) {
        fixture(h,im);
        for(unsigned j=0;j<8;j++){random=random*1664525u+1013904223u;unsigned at=random%sizeof h;h[at]^=(unsigned char)(random>>24);}
        random=random*1664525u+1013904223u;
        (void)media_import_plan(h,random%(sizeof h+1),im,sizeof im,0x92000000,0x817f6980,0x9b102000,&plan);
    }
    puts("PASS: import parsing/address decoding; malformed bounds/records/modified thunks refused; 10000 mutated header fixtures under ASan/UBSan (leak checking disabled: no heap allocation)");
}
