#include "probe.h"
#include "xsdk/kernel.h"
#include "xsdk/thread.h"
#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
int probe_main(void);
static XBOX_KRNL_VERSION version={2,0,17559,0};
const XBOX_KRNL_VERSION *const XboxKrnlVersion=&version;
static char image[260]="\\Device\\Mass0\\NativeVideoProbe\\default.xex";
const char *const ExLoadedImageName=image;
static unsigned stats,launches,logs,sleeps;
static bool missing_video,empty_video,missing_asset,missing_helper;
static uint32_t native_result;
static bool package_valid=true;
static unsigned package_checks;
bool probe_check_package(const char *path) {
    assert(strstr(path,"native-video.lex"));package_checks++;return package_valid;
}
static unsigned signed_in=255;
void xsdk_log_write(const char *format,...) {(void)format;logs++;}
int stat(const char *path,struct stat *st) {
    stats++;memset(st,0,sizeof *st);
    bool video=strstr(path,"selected.wmv")!=NULL;
    bool helper=strstr(path,"PeerPressure\\SideLoading")!=NULL;
    assert(video||helper||strstr(path,"Assets\\native-video.lex"));
    if(helper&&missing_helper){errno=ENOENT;return -1;}
    if((video&&missing_video)||(!video&&!helper&&missing_asset)){errno=ENOENT;return -1;}
    st->st_mode=S_IFREG|0444;st->st_size=video&&empty_video?0:256;return 0;
}
uint32_t XamUserGetSigninState(uint32_t user) {return user==signed_in?1:0;}
NTSTATUS xsdk_thread_sleep(uint32_t ms) {assert(ms==100);sleeps++;return STATUS_SUCCESS;}
uint32_t probe_native_launch(unsigned user,const char *uri,bool *available) {
    launches++;assert(user==signed_in);*available=true;
    if(strstr(image,"control.xex"))assert(!strcmp(uri,"videolibrary"));
    else {
        char expected[1020];
        assert(probe_uri("\\Device\\Mass0\\NativeVideoProbe","\\Device\\Mass0\\NativeVideoProbe\\selected.wmv",false,expected));
        assert(!strcmp(uri,expected));
    }
    return native_result;
}
int main(void) {
    version.build=17489;assert(probe_main()==1&&!stats&&!launches);version.build=17559;
    strcpy(image,"game:\\default.xex");assert(probe_main()==1&&!stats&&!launches);
    strcpy(image,"\\Device\\Mass0\\NativeVideoProbe\\default.xex");
    missing_helper=true;assert(probe_main()==1&&!launches);missing_helper=false;
    missing_video=true;assert(probe_main()==1&&!launches);missing_video=false;
    empty_video=true;assert(probe_main()==1&&!launches);empty_video=false;
    missing_asset=true;assert(probe_main()==1&&!launches);missing_asset=false;
    package_valid=false;assert(probe_main()==1&&!launches);package_valid=true;
    native_result=0x80070005;assert(probe_main()==1&&launches==1&&!sleeps);
    native_result=0;assert(probe_main()==0&&launches==2&&sleeps==100);
    /* The control must be independent of media and bridge availability. */
    strcpy(image,"\\Device\\Mass0\\NativeVideoProbe\\control.xex");unsigned before=stats,checks_before=package_checks;
    missing_video=missing_asset=true;signed_in=2;
    assert(probe_main()==0&&launches==3&&stats==before&&sleeps==200&&logs>6&&package_checks==checks_before);
    puts("PASS: native URI main; signed-out/signed-in users; native errors stop; bounded wait on success; independent library control; preflight guards");
}
