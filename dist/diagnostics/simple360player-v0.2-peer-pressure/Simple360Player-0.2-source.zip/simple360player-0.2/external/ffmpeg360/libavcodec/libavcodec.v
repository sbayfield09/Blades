LIBAVCODEC_$MAJOR {
        global: *;
};
