#include "probe.h"
#include "xsdk/kernel.h"
#include <string.h>
uint32_t probe_native_launch(unsigned user,const char *uri,bool *available) {
    *available=false;
    if((user>=4&&user!=255)||!uri||!uri[0]||strlen(uri)+1>=1020)return 0x80070057;
    HANDLE module=0;void *address=NULL;
    if(XexGetModuleHandle("xam.xex",&module)||!NT_SUCCESS(XexGetProcedureAddress(module,0x4ac,&address))||!address)return 0x80070032;
    uint32_t (*launch)(uint32_t,const char *,uint32_t,void *)=address;
    *available=true;
    return launch(user,uri,0,NULL);
}
