#!/usr/bin/env python3
"""Loopback fixture for production Jellyfin workers/HTTP/player, no user account."""
import http.server,json,os,pathlib,subprocess,sys,tempfile,threading,time,urllib.parse
UID='11111111111111111111111111111111';VIEW='22222222222222222222222222222222'
SOURCE='33333333333333333333333333333333';SESSION='44444444444444444444444444444444'
PASSWORD='test-only-private-password';TOKEN='test-only-session-token'
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def response(self,code,body):
  data=json.dumps(body).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def authorized(self):return 'Token="'+TOKEN+'"' in self.headers.get('Authorization','')
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))) or b'{}')
  self.server.events.append(('POST',self.path,body))
  if self.path=='/Users/AuthenticateByName':
   if body.get('Username')!='blades-test' or body.get('Pw')!=PASSWORD:self.response(401,{});return
   self.response(200,{'AccessToken':TOKEN,'User':{'Id':UID,'Name':'blades-test'}});return
  if not self.authorized():self.response(401,{});return
  if self.path.endswith('/PlaybackInfo'):
   assert not body['EnableDirectPlay'] and body['DeviceProfile']['TranscodingProfiles'][0]['VideoCodec']=='mpeg2video'
   self.response(200,{'PlaySessionId':SESSION,'MediaSources':[{'Id':SOURCE,'Protocol':'File','SupportsTranscoding':True,'TranscodingSubProtocol':'http','TranscodingContainer':'ts','RunTimeTicks':30000000,'MediaStreams':[{'Type':'Video','Index':0,'Codec':'hevc'},{'Type':'Audio','Index':1,'Codec':'aac'}]}]});return
  assert self.path in ('/Sessions/Playing','/Sessions/Playing/Progress','/Sessions/Playing/Stopped')
  self.response(204,{})
 def do_DELETE(self):
  assert self.authorized();self.server.events.append(('DELETE',self.path,{}));self.response(204,{})
 def do_GET(self):
  self.server.events.append(('GET',self.path,{}));path=urllib.parse.urlsplit(self.path)
  if path.path=='/System/Info/Public':self.response(200,{'ServerName':'Blades Test','Version':'10.10.7'});return
  if not self.authorized():self.response(401,{});return
  if path.path=='/Users/'+UID:
   self.server.user_calls+=1
   if self.server.mode=='retry' and self.server.user_calls==1:self.response(503,{});return
   self.response(200,{'Id':UID,'Name':'blades-test'});return
  if path.path=='/Users/'+UID+'/Views':
   self.server.view_calls+=1
   if self.server.mode=='expired':self.response(401,{});return
   if self.server.mode=='cancel' and self.server.view_calls==2:
    time.sleep(2)
    try:self.response(200,{'Items':[]})
    except (BrokenPipeError,ConnectionResetError):pass
    return
   self.response(200,{'Items':[{'Id':VIEW,'Name':'Movies','Type':'CollectionFolder','IsFolder':True,'CollectionType':'movies'},{'Id':'55555555555555555555555555555555','Name':'Music','Type':'CollectionFolder','IsFolder':True,'CollectionType':'music'}]});return
  if path.path=='/Items':
   q=urllib.parse.parse_qs(path.query);start=int(q.get('StartIndex',['0'])[0]);assert 'IncludeItemTypes' in q
   self.response(200,{'Items':[{'Id':f'{i+100:032x}','Name':f'Test Video {i}','Type':'Movie','MediaType':'Video','RunTimeTicks':30000000} for i in range(start,min(12,start+10))],'TotalRecordCount':12,'StartIndex':start});return
  if path.path.endswith('/stream.ts'):
   assert 'Static=false' in path.query and 'VideoCodec=mpeg2video' in path.query and 'SubtitleStreamIndex=-1' in path.query
   data=self.server.clip
   self.send_response(200);self.send_header('Content-Type','video/MP2T')
   if self.server.mode=='truncated':self.send_header('Content-Length',str(len(data)+10000));self.end_headers();self.wfile.write(data[:len(data)//2]);self.wfile.flush();self.close_connection=True;return
   self.send_header('Transfer-Encoding','chunked');self.end_headers()
   # Fragment both framing and media payload, including multi-byte split chunks.
   for at in range(0,len(data),1739):
    chunk=data[at:at+1739];wire=f'{len(chunk):x}\r\n'.encode()+chunk+b'\r\n'
    self.wfile.write(wire[:3]);self.wfile.write(wire[3:])
   self.wfile.write(b'0\r\n\r\n');return
  self.response(404,{})
def main():
 binary=pathlib.Path(sys.argv[1]).resolve()
 with tempfile.TemporaryDirectory(prefix='blades-jellyfin-test-') as directory:
  root=pathlib.Path(directory);clip=root/'clip.ts'
  subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=30','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','3','-c:v','mpeg2video','-b:v','2M','-threads','2','-c:a','mp2','-ac','2','-f','mpegts',str(clip)],check=True)
  for mode in ('normal','cancel','expired','truncated','retry'):
   server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True;server.clip=clip.read_bytes();server.events=[];server.mode=mode;server.view_calls=0
   server.user_calls=0;thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   try:
    result=subprocess.run([str(binary),f'127.0.0.1:{server.server_port}',str(root/(mode+'.json')),mode],env={**os.environ,'BLADES_JELLYFIN_TEST_PASSWORD':PASSWORD},text=True,capture_output=True,timeout=50)
    if result.returncode:raise AssertionError(mode+': '+result.stdout+result.stderr)
    if mode in ('normal','truncated'):
     assert any(m=='DELETE' and p.startswith('/Videos/ActiveEncodings?') for m,p,b in server.events)
    if mode=='normal':
     assert any(p=='/Sessions/Playing' for m,p,b in server.events) and any(p=='/Sessions/Playing/Stopped' for m,p,b in server.events)
     assert sum(p=='/Users/AuthenticateByName' for m,p,b in server.events)==2 # saved-token reconnect does not send password
    print(mode+': '+result.stdout.strip(),flush=True)
   finally:server.shutdown();server.server_close();thread.join()
if __name__=='__main__':main()
