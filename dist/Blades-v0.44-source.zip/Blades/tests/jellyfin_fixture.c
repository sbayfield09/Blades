#define _DEFAULT_SOURCE
#include "blades.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static const JellySnapshot *idle(JellyService *s,unsigned before){
 double end=now()+25;const JellySnapshot *v=NULL;
 do{v=jellyfin_poll(s);if(v&&v->revision>before&&!v->busy)return v;usleep(1000);}while(now()<end);
 fprintf(stderr,"Jellyfin timeout: %s\n",v?v->status:"no snapshot");assert(0);return NULL;
}
static const JellySnapshot *command(JellyService *s,JellyCommand c){const JellySnapshot *v=jellyfin_poll(s);unsigned before=v?v->revision:0;assert(jellyfin_request(s,&c));return idle(s,before);}
static void edit(JellyService *s,unsigned field,const char *text){JellyCommand c={.type=JELLY_EDIT,.field=field};assert(strlen(text)<sizeof c.text);snprintf(c.text,sizeof c.text,"%s",text);command(s,c);xf_wipe(&c,sizeof c);}
static void saved_without_password(const char *path,const char *password){FILE *f=fopen(path,"rb");assert(f);char data[8192]={0};size_t n=fread(data,1,sizeof data-1,f);fclose(f);assert(n&&!strstr(data,"\"Pw\"")&&!strstr(data,"\"Password\"")&&!strstr(data,password));xf_wipe(data,sizeof data);}
int main(int argc,char **argv){
 assert(argc==4);const char *password=getenv("BLADES_JELLYFIN_TEST_PASSWORD");assert(password&&*password);
 JellyService *s=jellyfin_open(argv[2],NULL);assert(s);const JellySnapshot *v=idle(s,0);
 edit(s,1,argv[1]);edit(s,2,"blades-test");edit(s,3,"wrong-password");v=command(s,(JellyCommand){.type=JELLY_CONNECT});assert(v->state!=JELLY_CONNECTED);
 edit(s,3,password);v=command(s,(JellyCommand){.type=JELLY_CONNECT});if(v->state!=JELLY_CONNECTED)fprintf(stderr,"connect: %s\n",v->status);assert(v->state==JELLY_CONNECTED);
 saved_without_password(argv[2],password);
 v=command(s,(JellyCommand){.type=JELLY_ROOT});
 if(!strcmp(argv[3],"expired")){assert(v->state==JELLY_OFF);jellyfin_close(s);puts("PASS: expired session clears stored credentials");return 0;}
 assert(v->page.count&&v->loaded);for(unsigned i=0;i<v->page.count;i++)assert(strcmp(v->page.items[i].collection,"music"));
 if(!strcmp(argv[3],"cancel")){
  unsigned revision=v->revision;assert(jellyfin_request(s,&(JellyCommand){.type=JELLY_REFRESH}));usleep(30000);double at=now();jellyfin_cancel(s);v=idle(s,revision);assert(now()-at<1&&v->page.count&&v->loaded);
  for(unsigned i=0;i<20;i++){revision=v->revision;assert(jellyfin_request(s,&(JellyCommand){.type=JELLY_REFRESH}));jellyfin_cancel(s);v=idle(s,revision);assert(v->loaded&&v->page.count);}
  jellyfin_close(s);puts("PASS: active/queued cancellation remains responsive, preserves page and permits subsequent requests");return 0;
 }
 v=command(s,(JellyCommand){.type=JELLY_OPEN,.row=0});assert(v->depth==1&&v->page.count);
 if(v->page.total>v->page.count){v=command(s,(JellyCommand){.type=JELLY_NEXT});assert(v->start);v=command(s,(JellyCommand){.type=JELLY_PREVIOUS});assert(!v->start);}
 unsigned row=0;while(row<v->page.count&&!jellyfin_playable(v->page.items+row))row++;assert(row<v->page.count);
 v=command(s,(JellyCommand){.type=JELLY_PLAY,.row=row});VideoHttpInput input;assert(jellyfin_take_playback(s,&input));assert(!jellyfin_take_playback(s,&input));
 assert(strstr(input.request,"VideoCodec=mpeg2video")&&strstr(input.request,"AudioCodec=mp2")&&strstr(input.request,"Authorization: MediaBrowser"));
 VideoPlayer *player=video_create(&(VideoConfig){.channels=2,.audio_available=true,.gpu_yuv=true});assert(player&&video_play_http(player,&input));xf_wipe(&input,sizeof input);
 double begin=now();unsigned pictures=0,heard=0;VideoSnapshot state={0};bool paused=false,resumed=false;
 while(now()-begin<18){
  float pcm[512];video_audio_render(player,pcm,256);for(unsigned i=0;i<512;i++)heard+=fabsf(pcm[i])>.0001f;
  VideoPicture p;if(video_take_picture(player,&p)){assert(p.width<=1280&&p.height<=720&&p.format!=VIDEO_RGBA);pictures++;video_release_picture(player,p.slot,p.revision);}
  video_poll(player,&state);jellyfin_progress(s,&state);
  if(state.state==VIDEO_FAILED){fprintf(stderr,"stream: %s\n",state.error);break;}
  if(pictures>8&&!paused){video_pause(player,true);paused=true;}
  if(paused&&!resumed&&state.state==VIDEO_PAUSED){video_seek(player,10);usleep(60000);VideoSnapshot pstate;video_poll(player,&pstate);assert(pstate.position==state.position);video_pause(player,false);resumed=true;}
  if(state.state==VIDEO_ENDED)break;
  usleep(1000);
 }
 if(!strcmp(argv[3],"truncated"))assert(state.state==VIDEO_FAILED);
 else assert(state.state==VIDEO_ENDED&&state.network&&pictures>15&&heard>100&&paused&&resumed);
 video_close(player);v=jellyfin_poll(s);unsigned revision=v?v->revision:0;jellyfin_finish(s,state.position);v=idle(s,revision);
 saved_without_password(argv[2],password);jellyfin_close(s);
 s=jellyfin_open(argv[2],NULL);assert(s);v=idle(s,0);
 if(!strcmp(argv[3],"retry")){assert(v->state==JELLY_ERROR);v=command(s,(JellyCommand){.type=JELLY_CONNECT});}
 assert(v->state==JELLY_CONNECTED);v=command(s,(JellyCommand){.type=JELLY_DISCONNECT});assert(v->state==JELLY_OFF);jellyfin_close(s);
 s=jellyfin_open(argv[2],NULL);assert(s);v=idle(s,0);assert(v->state==JELLY_OFF);v=command(s,(JellyCommand){.type=JELLY_REMOVE});assert(!v->server[0]&&!v->username[0]);jellyfin_close(s);
 printf("PASS: Jellyfin authentication, video-only libraries, folders/pages, authenticated MPEG2/MP2 playback (%u pictures), pause/end, reporting/cleanup, saved-session reconnect/disconnect/remove\n",pictures);
}
