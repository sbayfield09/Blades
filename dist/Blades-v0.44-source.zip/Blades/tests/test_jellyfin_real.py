#!/usr/bin/env python3
"""Production Blades client against disposable official Jellyfin10.10.7.
Only a generated account and synthetic HEVC source are used, never user data.
"""
import json,os,pathlib,secrets,socket,subprocess,sys,tempfile,time,urllib.error,urllib.parse,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
 server=pathlib.Path(os.environ.get('JELLYFIN_TEST_SERVER','/workspace/jellyfin-test-server/jellyfin'))
 binary=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else ROOT/'build/linux/blades-jellyfin-fixture').resolve()
 assert server.is_file() and binary.is_file()
 with tempfile.TemporaryDirectory(prefix='blades-real-jellyfin-') as directory:
  root=pathlib.Path(directory)
  for name in ('data','config','cache','logs','movies','music'):(root/name).mkdir()
  with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  base=f'http://127.0.0.1:{port}'
  (root/'config/network.xml').write_text(f'<NetworkConfiguration><InternalHttpPort>{port}</InternalHttpPort><PublicHttpPort>{port}</PublicHttpPort><EnableRemoteAccess>false</EnableRemoteAccess><EnableIPv6>false</EnableIPv6><LocalNetworkAddresses><string>127.0.0.1</string></LocalNetworkAddresses><EnableUPnP>false</EnableUPnP></NetworkConfiguration>')
  movie=root/'movies/Blades HEVC Test (2024)';movie.mkdir()
  subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=30','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','8' if '--record' in sys.argv else '3','-c:v','libx265','-threads','1','-preset','ultrafast','-x265-params','pools=none:frame-threads=1:log-level=error','-c:a','aac','-ac','2',str(movie/'Blades HEVC Test (2024).mp4')],check=True,stderr=subprocess.DEVNULL)
  password=secrets.token_urlsafe(24);token='';opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  def api(path,method='GET',body=None):
   headers={'Content-Type':'application/json','Authorization':'MediaBrowser Client="BladesTests", Device="Desktop", DeviceId="blades-test-setup", Version="0.44"'+(', Token="'+token+'"' if token else '')}
   data=None if body is None else json.dumps(body).encode()
   with opener.open(urllib.request.Request(base+path,data=data,headers=headers,method=method),timeout=15) as response:
    data=response.read();return json.loads(data) if data else None
  env={**os.environ,'NO_PROXY':'127.0.0.1,localhost','no_proxy':'127.0.0.1,localhost','DOTNET_CLI_TELEMETRY_OPTOUT':'1'}
  with (root/'server.log').open('wb') as log:
   process=subprocess.Popen([str(server),'--datadir',str(root/'data'),'--configdir',str(root/'config'),'--cachedir',str(root/'cache'),'--logdir',str(root/'logs'),'--nowebclient','--ffmpeg','/usr/bin/ffmpeg','--nonetchange'],env=env,stdout=log,stderr=subprocess.STDOUT)
   try:
    ready=False
    for _ in range(160):
     if process.poll() is not None:raise RuntimeError('Jellyfin exited during startup')
     try:info=api('/System/Info/Public');ready=True;break
     except (urllib.error.URLError,TimeoutError):time.sleep(.25)
    assert ready
    api('/Startup/Configuration','POST',{'UICulture':'en-US','MetadataCountryCode':'GB','PreferredMetadataLanguage':'en'})
    api('/Startup/User');api('/Startup/User','POST',{'Name':'blades-test','Password':password})
    api('/Startup/RemoteAccess','POST',{'EnableRemoteAccess':False,'EnableAutomaticPortMapping':False});api('/Startup/Complete','POST',{})
    auth=api('/Users/AuthenticateByName','POST',{'Username':'blades-test','Pw':password});token=auth['AccessToken'];user=auth['User']['Id']
    for name,kind,folder in [('Test Movies','movies','movies'),('Test Music','music','music')]:
     api('/Library/VirtualFolders?name='+urllib.parse.quote(name)+'&collectionType='+kind+'&refreshLibrary=true','POST',{'LibraryOptions':{'PathInfos':[{'Path':str(root/folder)}],'EnableRealtimeMonitor':False,'TypeOptions':[{'Type':t,'MetadataFetchers':[],'ImageFetchers':[]} for t in ('Movie','Audio','MusicArtist','MusicAlbum')]}})
    items=[]
    for _ in range(160):
     items=api('/Users/'+user+'/Items?Recursive=true&IncludeItemTypes=Movie&Fields=MediaSources')['Items']
     if items:break
     time.sleep(.25)
    assert items
    result=subprocess.run([str(binary),f'127.0.0.1:{port}',str(root/'blades-settings.json'),'real'],env={**env,'BLADES_JELLYFIN_TEST_PASSWORD':password},capture_output=True,text=True,timeout=65)
    if result.returncode:raise RuntimeError('Blades failed against real Jellyfin: '+result.stdout+result.stderr)
    item=api('/Users/'+user+'/Items/'+items[0]['Id']);assert item['UserData']['PlayCount']>=1
    assert not api('/Sessions?DeviceId=unused') # unrelated device has no playback session
    print('PASS: official Jellyfin '+info['Version']+'; HEVC/AAC source -> negotiated MPEG2/MP2 MPEG-TS -> Blades AVIO/decoder, real sound/picture data, pause/end, watch-history report, saved-token reconnect and disconnect')
    print(result.stdout.strip())
    if '--record' in sys.argv:
     config=root/'capture-settings.json';config.write_text(json.dumps({'Server':f'127.0.0.1:{port}','Username':'blades-test','UserId':user,'AccessToken':token,'DeviceId':secrets.token_hex(16)}));config.chmod(0o600)
     subprocess.run([sys.executable,str(ROOT/'tools/record-walkthrough.py'),'--version','0.44'],env={**env,'BLADES_JELLYFIN_CONFIG':str(config)},check=True)

   except Exception:
    # Sanitized server messages can aid diagnosis; never print requests/tokens.
    if process.poll() is not None:print('Test server exit code:',process.returncode,file=sys.stderr)
    raise
   finally:
    process.terminate()
    try:process.wait(timeout=8)
    except subprocess.TimeoutExpired:process.kill();process.wait()
if __name__=='__main__':main()
