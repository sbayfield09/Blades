#include "blades.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static void press(Dashboard *d,unsigned a){dashboard_update(d,a,.016f);}
int main(void){
 Dashboard d;dashboard_init(&d);d.blade=d.previous_blade=BLADE_MEDIA;d.selected[BLADE_MEDIA]=2;
 JellySnapshot j={.state=JELLY_CONNECTED,.revision=1,.loaded=true,.page={.count=1,.total=1}};strcpy(j.page.items[0].name,"Movies");j.page.items[0].folder=true;
 dashboard_set_jellyfin(&d,&j);press(&d,SELECT);assert(d.depth==1&&d.library_page==LIB_UI_VIDEO_SOURCES&&dashboard_library_count(&d)==2);
 assert(!strcmp(dashboard_library_label(&d,0),"Jellyfin")&&!strcmp(dashboard_library_label(&d,1),"Local"));
 press(&d,DOWN);press(&d,SELECT);assert(d.library_page==LIB_UI_LIST&&d.library_filter==LIB_VIDEO);press(&d,BACK);assert(d.library_page==LIB_UI_VIDEO_SOURCES&&d.library_row==1);
 press(&d,UP);press(&d,SELECT);assert(d.jelly_page==JELLY_UI_BROWSE&&d.jelly_command.type==JELLY_ROOT&&d.jelly_wait);
 j.revision++;dashboard_set_jellyfin(&d,&j);press(&d,SELECT);assert(d.jelly_command.type==JELLY_OPEN&&d.jelly_command.row==0);
 j.depth=1;j.revision++;j.page.items[0].folder=false;strcpy(j.page.items[0].type,"Episode");dashboard_set_jellyfin(&d,&j);press(&d,SELECT);assert(d.jelly_command.type==JELLY_PLAY);
 j.revision++;dashboard_set_jellyfin(&d,&j);press(&d,BACK);assert(d.jelly_command.type==JELLY_BACK&&d.jelly_page==JELLY_UI_BROWSE);
 j.depth=0;j.revision++;dashboard_set_jellyfin(&d,&j);press(&d,BACK);assert(d.library_page==LIB_UI_VIDEO_SOURCES&&!d.jelly_page);press(&d,BACK);assert(!d.depth&&!d.library_page);
 d.selected[BLADE_MEDIA]=4;press(&d,SELECT);assert(d.jelly_page==JELLY_UI_SETTINGS&&d.depth);
 for(unsigned field=1;field<=3;field++){press(&d,SELECT);assert(d.jelly_edit==field);press(&d,DOWN);}
 press(&d,SELECT);assert(d.jelly_command.type==JELLY_DISCONNECT);j.revision++;j.state=JELLY_OFF;dashboard_set_jellyfin(&d,&j);press(&d,SELECT);assert(d.jelly_command.type==JELLY_CONNECT);
 j.revision++;dashboard_set_jellyfin(&d,&j);press(&d,DOWN);press(&d,SELECT);assert(d.jelly_command.type==JELLY_REMOVE);press(&d,BACK);assert(!d.depth&&!d.jelly_page);
 d.selected[BLADE_MEDIA]=2;press(&d,SELECT);press(&d,SELECT);j.revision++;j.busy=true;dashboard_set_jellyfin(&d,&j);press(&d,BACK);assert(!d.jelly_page&&d.library_page==LIB_UI_VIDEO_SOURCES);
 press(&d,RIGHT);assert(d.blade==BLADE_SYSTEM&&!d.jelly_page&&!d.library_page);
 puts("PASS: Media Center connection controls, Jellyfin/Local folders, page/back/cancel/play routing and blade changes");
}
