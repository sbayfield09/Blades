# Milestone 54: what porters hit first, files and the system

Agreed on 2026-10-20, with drive names in src/path.c, flushing and closing on Xbox Home, and letterboxing in this
milestone.

## Why

docs/PARITY.md ranks these after the log over the network (milestone 53): calls a ported game makes in its first
minutes, each a kernel or XAM export Xenia implements, so their behaviour is documented.
- **It doesn't link:** `pwrite`, `ftruncate`, `fsync`, `fdatasync`, `statvfs` and `fstatvfs` are missing from xsdk
  (src/file.c has `pread` alone), so code using any of them stops at the link.
- **Only `game:` has a name.** A path to the hard disk, a USB drive or the DVD is a device path written out
  (`\Device\Harddisk0\Partition1\...`); `hdd:`, `usb:` and `dvd:` don't resolve (src/path.c).
- **`localtime` is UTC,** whatever time zone the console is set to, and nothing tells a title the console's language.
- **Xbox Home ends a title without `exit`:** no `atexit` handler runs, stdio's buffers are lost, and files are left as
  the kernel finds them.
- **A 4:3 output stretches 1280x720** across the whole picture (src/display.c, `plan_scaler`).

## What it takes

Each step probes on the console first where Xenia can't answer.

1. **The file calls,** in src/file.c and src/path.c:
   - `pwrite`, as `pread` is, through `NtWriteFile` at an offset;
   - `ftruncate`, as `truncate` is, through `NtSetInformationFile`'s end-of-file class;
   - `fsync` and `fdatasync` through `NtFlushBuffersFile` (0xDB), which Xenia takes and does nothing with
     (xenia:src/xenia/kernel/xboxkrnl/xboxkrnl_io.cc:591-600);
   - `statvfs` and `fstatvfs` through `NtQueryVolumeInformationFile` (0xEF), its size class (xboxkrnl_io_info.cc:280-345).
2. **Drive names:** `hdd:`, `usb:` (and `usb1:`, `usb2:` where there are more), `mu:` for a memory unit and `dvd:`,
   resolved by src/path.c to the device paths a console probe confirms. Xenia mounts `\Device\Harddisk0\Partition1`
   and `\Device\Cdrom0` (xenia:src/xenia/emulator.cc:298-353); xsdk's log already falls back to `\Device\Mass0`
   (src/log.c). The probe lists the root of each candidate path, with and without a USB stick and a disc.
3. **The console's settings:**
   - the time zone from XAM's `GetTimeZoneInformation` (0x43F), Win32's bias, names and daylight-saving dates, set at
     start-up as newlib's time zone, so `localtime` and `mktime` give the console's local time (Decided 4);
   - the language through `XGetLanguage` (XAM 0x3CD) and the country through `XamGetLocaleEx` (XAM 0x5D7), as
     `xsdk_system_language` and `xsdk_system_country`.
4. **Xbox Home:** `xsdk_on_terminate` registers a title's routine with `ExRegisterTitleTerminateNotification` (0x15),
   which Xenia never calls (its call is commented out, xenia:src/xenia/kernel/kernel_state.cc:489-504). On the console
   the routine runs on a system thread with every title thread frozen, the title's handles closed and `game:` gone,
   and it was given 2 s; a registration left in place froze the console as the next title started
   (results/2026-10-20-milestone-54/, the terminate probe), so xsdk's routine always takes the registration out before
   it returns. stdio's unflushed bytes have no handle left and are lost; the docs say so.
5. **Letterboxing on 4:3:** where `VdQueryVideoMode` says the output isn't widescreen, 1280x720 shows at the output's
   width with bars above and below, in place of stretching: `xsdk_present`'s front buffers are 1280x960, the frame
   resolved on rows 128 to 847 between black bars, and the scaler fills the output with them, the title still drawing
   1280x720 (Decided 5).

Left out: asynchronous and unbuffered reads, `mmap`, the device selector (milestone 51 left it to XAM's own UI),
720p on interlaced outputs (TODO.md), and running `atexit` handlers on Xbox Home, unless step 4's probe shows the
notification has the time and the threads' locks to run them safely.

## Verification

On the console, each check its own line in xsdk_test, each broken on purpose once:
- **Files:** `pwrite` at an offset reads back with `pread`, the file's size unchanged; `ftruncate` and `truncate`
  shorten and lengthen a file, the bytes added zero; a write past the end leaves the gap zero; `fsync` returns 0 on a
  file and fails on a socket with `EINVAL`; `statvfs` of `game:` gives a block size and free blocks that go down by a
  written file's size.
- **Drives:** `hdd:\` lists its root and holds the `.xex` xsdk_test runs from; `usb:`, `dvd:` and `mu:` list their
  roots as their devices do where something is in, and fail with `ENOENT` where not.
- **Settings:** `localtime` minus `gmtime` equals the console's bias, with its daylight or standard bias as XAM says;
  the language and country are logged and match what the dashboard shows.
- **Xbox Home:** terminate_check's routine writes a marker through a device path as the console agent sends the
  console to the dashboard; the next run reads the marker, and the console carries on.
- **Letterboxing:** forced on the widescreen output, the display shows a 1280x960 front buffer with the scaler planned
  for it, the frame between black bars, and the scaler goes back as the present closes; with the console set to 4:3,
  you see 1280x720 unstretched once.

vulkan4xenon_test twice and vkbench, unchanged.

## Done when

Each item above works on the console and its check passes, its break failing; docs/GUIDE.md and docs/PARITY.md say
what's there.

## Decided

1. **Drive names in src/path.c:** xsdk maps `hdd:` and the rest itself, with nothing left behind in the kernel, rather
   than `ObCreateSymbolicLink`'s names the whole console sees.
2. **Xbox Home:** flushing and closing was agreed first; the probe showed the title's handles already closed when the
   routine runs, so on the user's choice xsdk gives the safe hook alone: `xsdk_on_terminate`, its routine on a system
   thread, the registration always taken out, and the docs saying what's lost.
3. **Letterboxing** is in this milestone; you set the console to 4:3 once and look.
4. **The time zone from `GetTimeZoneInformation`:** `ExGetXConfigSetting`'s time zone settings read 0 on the first
   run, so xsdk reads XAM's `GetTimeZoneInformation` instead, in Win32's layout. With US Eastern set it gave EST and
   EDT and their dates (results/2026-10-20-milestone-54/step3_xsdk_test_eastern.log).
5. **Letterboxing by 1280x960 front buffers:** the overscan registers radeonhd letterboxes with read 0 after a present,
   and the kernel's scaler builder, asked how it places the picture, ended the title (docs/HARDWARE.md, "Letterboxing,
   milestone 54 step 5"), so xsdk draws the bars into taller front buffers and leaves the scaler filling the output.
