# Later

Items left over from SCOPE.md's milestones, or put off by them. None is scoped or started; each needs agreeing before
work begins.

## Runtime and display

- **A stack overflow hangs the console,** with a fault handler or without, until it's restarted (docs/HARDWARE.md, "How
  the kernel hands a title its faults, milestone 40's probe"). The kernel puts the exception record and context on the
  faulting thread's own stack, so an overflowed one leaves it nowhere to. What could stop it, such as room kept at
  each stack's end, isn't known.
- **Traps never reach the fault handler on the user's console,** which runs a debug monitor; the title carries on past
  them (the same section). What a console without one does, and so whether `-fsanitize-trap` could report, isn't
  known.
- **Symbol names in `std::stacktrace`.** A trace gives addresses only, as a XEX carries no symbols. `elf2xex` would
  write a symbol map beside the `.xex`, and the runtime would name frames from it (SCOPE.md section 2.5).
- **A native TLS model.** `thread_local` uses GCC's emulated TLS over `KeTlsGetValue`. A GCC change that loads
  `tls_ptr` from `0(r13)` first would reach static TLS directly, if emulated TLS proves too slow (SCOPE.md section
  2.5).
- **720p on interlaced outputs (1080i, 480i).** `XSDK_DISPLAY_720P` keeps the kernel's 640x480 there, as scaling on an
  interlaced output isn't tried. Likely pieces: libxenon writes `AVIVO_D1MODE_DATA_FORMAT` 1 for interlaced modes
  (libxenon:drivers/xenos/xenos.c:391), and xenon-emu names a second vertical start phase, 0x65DC,
  `D1SCL_VERT_FILTER_INIT_BOT` (XenosRegisters.h:935).
- **Mutexes holding their critical section.** A `pthread_mutex_t` is newlib's 32-bit word, which xsdk makes a pointer
  to a critical section `malloc`ed on first lock (src/pthread.c, `mutex_section`). Keeping the critical section in the
  mutex, with a newlib patch making `pthread_mutex_t` that big and every C++ library rebuilt again, would end two costs:
  - a mutex locked after its memory is freed takes newlib's free-list link there for its critical section and corrupts
    the heap, where a desktop's mutex would only touch dead memory (Dusklight's, in docs/HARDWARE.md, "Dusklight runs
    the title scene");
  - `std::mutex` has no destructor when its type has a static initializer (libstdc++ bits/std_mutex.h), so each one
    ever locked leaks its 28-byte critical section when it goes.
- **A folder removed while it's open.** `open` shares reading and writing but not deleting (src/file.c), and removing
  or renaming opens sharing nothing (src/path.c), so the kernel refuses to delete a file or folder another handle holds
  open, 0xC0000043. libstdc++'s `remove_all` deletes an emptied folder within another while its own handle on it is
  still open (gcc:libstdc++-v3/src/c++17/fs_dir.cc:492-506), so it fails on any folder within a folder; a flat one
  goes. POSIX allows both. The likely fix is opening with `FILE_SHARE_DELETE` and the other shares, as a POSIX title
  expects, with `unlinkat` sharing all three.
- **Small GPU allocations other than shaders.** `xsdk_gpu_alloc` rounds each one up to a 64 KiB large page (src/gpu.c,
  `allocate`). Shaders' microcode shares pages since milestone 25; the rest, three small ones in Dusklight's title
  scene (results/2026-10-12-gpu-allocations/), still take a page each.
- **The Guide, beyond milestone 37** (docs/scope/37-guide.md):
  - **Pausing while it's open.** `XN_SYS_UI` says when the Guide opens and closes (tests/guide_check.c reads it); a title
    that should pause, as consoles' games do, would want it from xsdk.
  - **A title ending by itself with the Guide open hangs** as it ends: XAM's Guide thread waits for a fence only the
    title's next swap would write (docs/HARDWARE.md, "The Guide, milestone 37"). Leaving through Xbox Home is fine. A
    fix would have `xsdk_present_close` keep swapping its last frame until XAM's system command buffer is empty and
    done, which XAM may not allow before the Guide closes; unexplored.
  - **On the kernel's display mode and interlaced outputs,** where xsdk doesn't scale the display, XAM's surface isn't
    shown, so the Guide still isn't; the log says so once.
- **A sharper scaler filter at 1080p.** 1280x720 is scaled with the built-in 2-tap filter, the only setting that came
  out whole. Every variant on the kernel's coefficient table scrambled the image, and 2 taps on the table wasn't tried.
  More taps would mean loading our own coefficients through 0x6578 and 0x657C, in the layout AMD's
  `program_multi_taps_filter` uses (docs/HARDWARE.md, "What AMD's code says about the scaler" and "The built-in 2-tap
  filter scales 1280x720 to 1920x1080 whole").
- **A second colour of text in a frame scatters it (milestone 64).** Starship's first-run screen drew a bar as two
  `xsdk_text_draw` calls side by side, the first in 0xFFEEEEEA and the second in 0xFF2A2A2C. The first drew whole; the
  second's glyphs came out speckled, in its place and as stray marks far below it, with `#` as with U+2588, frame
  after frame of a still screen. Text in one colour, of any size and in any number of calls, drew whole. Seen on the
  console only, not yet in a check of xsdk's own: test_text.c draws one colour a frame, and a check drawing two would
  show it. Starship draws its bar as one string meanwhile.

## Toolchain

- **`__builtin___clear_cache` and libgcc's `__clear_cache` do nothing for this target,** so code a title writes into
  `.jit` must call `xsdk_code_flush` (docs/scope/55-windows-threads-and-memory.md, decision 4). The fix is a
  gcc-xsdk.patch change and a rebuild of the toolchain and everything on it.
- **A bare scalar uniform on xost's OpenGL path is read as its whole register,** as scalar inputs were until milestone
  46 step 6 (docs/HARDWARE.md, "Samples in a loop's pass, milestone 46 step 6"). It's right where the runtime fills
  the register's four components alike; whether every runtime does, and so whether any program reads one wrongly,
  isn't checked.
- **Vulkan command recording 10-12% slower since the calling-convention switch** (milestone 22, docs/HARDWARE.md,
  "The switch to the console's calling convention"). vkbench on the console (vulkan4xenon
  results/2026-10-12-mcall-xsdk/, against 2026-10-11-milestone-8-reverted, scaled for the clock fix): the layer's
  draw and state scenes record 10.5-12% slower, record plus submit 0.5-1.7% slower; the 8000-object simulation runs
  14% faster and xsdk's own recording 2-3% faster. The recording functions are the same instructions under both
  compilers; every non-leaf frame now reserves the 64-byte parameter area (vkCmdDraw's grew from 32 to 96 bytes), a
  candidate cause not yet checked. The user put it off until the Dusklight session has it rendering.
- **C code can't name `char16_t`.** newlib has no `<uchar.h>`, so C code sharing UTF-16 text with MSVC code spells it
  `__CHAR16_TYPE__` (local/abi's probe does); C++ has the keyword.
- **xost's assembler and disassembler off Python.** Its compiler is C, xsdk's `src/xsc_*.c`, which titles call on the
  console (`include/xsdk/xsc.h`) and the PC's tools through `build/host/libxsc.so`; its assembler (`xasm`), and its
  disassembler and simulator (`xdis`), which the tests and the shader generators use, are still Python
  (xenos-toolchain/README.md, "What's here").

## GPU features SCOPE.md left out of milestones 11 to 18

- **Several targets at once, multisampled.** vulkan4xenon milestone 25 drew up to four colour targets at once at one
  sample, each blended and masked on its own (`xsdk_gpu_set_targets`, `xsdk_gpu_set_blends`), and xost exports
  fragment outputs at locations 1 to 3 to oC1 to oC3, ps_export_mode counting them (docs/HARDWARE.md, "Float, 10-bit
  and 64-bit targets and four at once"). Since milestone 44 step 3 xsdk draws them at 2 and 4 samples too
  (`xsdk_gpu_set_targets_samples`); left: the layer's (vulkan4xenon milestone 17).
- **More target formats.** vulkan4xenon milestone 25 added 2_10_10_10, its 7e3 float, 16_16_16_16 and the 16- and
  32-bit floats at one sample, each resolved into a texture of the format it converts to (`xsdk_gpu_set_targets`,
  `xsdk_gpu_resolve_target`). Left: 16_16, 32_32_FLOAT, 8_8_8_8_GAMMA and the two AS_ formats
  (xenia:src/xenia/gpu/xenos.h:299-313). At 2 and 4 samples 2_10_10_10, 7e3 and 16_16_16_16 draw since milestone 44
  step 3, and the 16- and 32-bit floats are refused, as their resolves don't average on the console
  (results/2026-10-20-milestone-44-step-3). 7e3 and 16_16_16_16 blend; the 16- and 32-bit floats don't
  (docs/HARDWARE.md).
- **Cube and 3D textures, the rest.** vulkan4xenon milestone 23 brought tiled cubes with their mips and tiled 3D
  textures of one level (include/xsdk/texture.h), right on the console (docs/HARDWARE.md). Left: linear cubes and
  3D textures; a 3D texture's mips, which Xenia sizes by the base's depth at every level
  (xenia:src/xenia/gpu/texture_util.cc:347-350) and packs along z once they're small (texture_util.cc:190-198); and
  resolving into a face or slice (vulkan4xenon milestone 25).
- **Occlusion queries' sample counts,** put off after vulkan4xenon milestone 28. Every `ZPASS_DONE` sent, by milestone
  19's six runs and milestone 28's fourteen tries, hung the GPU at its first event without writing the counts: with
  `RB_SAMPLE_COUNT_CTL`'s RESET, the `RST_PIX_CNT` event, a cache flush or a resolve after it, the sample counters
  disabled, and the set-up's registers put back as the dashboard leaves them, all at once or a group at a time
  (docs/HARDWARE.md, "Occlusion queries, vulkan4xenon milestone 28"). Yamato's counter registers hold the same values
  across draws. Nothing public is left to try. What's taken instead is D3D's visibility query,
  `xsdk_gpu_begin_visibility` and `xsdk_gpu_end_visibility` (include/xsdk/gpu.h): it answers whether a draw got past
  rasterizing and the coarse hierarchical test, a quad hidden behind another too, not whether a sample passed the
  depth test, so vulkan4xenon's occlusion queries are conservative, without `occlusionQueryPrecise`; an id begun again
  around draws that rasterize nothing comes back clear on the console.
- **Filtering 10-10-10-2 and 16-bit float textures.** The console filtered them wrong halfway between two texels,
  nearest sampling right (docs/HARDWARE.md, "Texture and vertex formats, vulkan4xenon milestone 20"); vulkan4xenon
  samples them nearest. To try: `k_2_10_10_10_AS_16_16_16_16` and the `_EXPAND` formats
  (xenia:src/xenia/gpu/xenos.h:503-505, 530).

## GPU gaps the milestones left

- **Destination alpha,** vulkan4xenon milestone 18's step 4, put off (vulkan4xenon:docs/ROADMAP.md). Aurora's backend
  refuses a pipeline with `GXSetDstAlpha` on and skips its draws, logging `vulkan4xenon can't draw destination alpha`
  (aurora-melee:lib/vulkan4xenon/pipeline.cpp, `unsupported`). Dawn's backend writes the constant as alpha through a
  blend constant; where the colour blend reads source alpha, it needs dual-source blending, which Xenos lacks, or an
  alpha-only pass before the colour (aurora-melee:lib/gx/pipeline.cpp, `create_pipeline`). The constant blend colour
  (`xsdk_gpu_set_blend_constants`) and Vulkan's blend constants in the layer came with vulkan4xenon milestone 19's
  step 3, so it needs that pass in the backend. Melee sets it through its
  HSD state (melee-pc:src/sysdolphin/baselib/state.c:376); no Melee session or Dusklight title scene has logged the
  refusal yet.
- **Primitive restart.** `VGT_MULTI_PRIM_IB_RESET_INDX` (registers.h:343-360) and `PA_SU_SC_MODE_CNTL`'s
  `multi_prim_ib_ena` (registers.h:480).
- **Draws of more than 65535 indices.** The draw initiator's count is 16 bits (registers.h:327), so a layer would split
  them.
- **The YCbCr borders.** vulkan4xenon milestone 23 brought `ClampMode` 3 to 7 and the black and white borders, the
  black's alpha 0 on the console (docs/HARDWARE.md, "Cube and 3D textures and the rest of addressing, vulkan4xenon
  milestone 23"). The two blacks for YCbCr data, whose colours Xenia guesses (xenos.h:156-161), aren't offered.
- **Image views of some of a texture's levels.** vulkan4xenon refuses a view that doesn't cover every level
  (vulkan4xenon:src/image.c). The sampler's lowest level and count of levels (include/xsdk/texture.h), which took
  Vulkan's `minLod` and `maxLod` in vulkan4xenon milestone 18's step 2, could take a view's range too.
- **More texture formats.** `texture.h` has 24: milestone 16's 13, the byte-order R8G8B8A8 and B8G8R8A8, milestone
  28's R32F, D24S8 for depth resolves, and vulkan4xenon milestone 20's DXN, DXT5A, 16-bit fixed point and 10-11-11,
  with signed and gamma reads (`xsdk_texture_signs`). Left: 32-bit floats in two and
  four channels (`k_32_32_FLOAT`, `k_32_32_32_32_FLOAT`); DXN and DXT5A read signed, which Xenia doesn't read
  (vulkan/vulkan_texture_cache.cc:333-337, 384-388), and so the layer's BC4 and BC5 `SNORM`; and the formats no
  Vulkan format or port has asked for, such as CTX1 and DXT3A (`TextureFormat`, xenos.h:450-532).
- **Resolving part of a target, past vulkan4xenon milestone 27.** `xsdk_gpu_resolve_texture_rect` resolves a
  rectangle on the 8-pixel grid into the same texels. Left: a rectangle into another place in the texture, which
  Direct3D 9 does by moving the destination's address (xenia:src/xenia/gpu/xenos.h:944-955); part of the depth; and
  hierarchical depth after a part's depth clear, which stays off till the whole is cleared; and a rectangle of a target
  but 0, or of any but 8_8_8_8. vulkan4xenon refuses render areas off the grid, which a resolve can't keep to, unless it
  drew the rest of the target back in first, and smaller ones but for one 8-bit colour attachment.
- **Mipped linear textures.** `xsdk_texture_create` returns `STATUS_NOT_IMPLEMENTED` for them. Xenia keeps their rows
  256-byte aligned (texture_util.cc:209-449). Vulkan rarely needs them.

## Costs measured but not chased

- **A pushed draw's extra 0.47 us at submit (vulkan4xenon).** Through the layer a pushed cube and a uniform one write
  the same 17.3 dwords and 18 kicks a frame, yet the pushed one's submit costs 0.97 us and the uniform one's 0.50
  (vulkan4xenon:docs/ROADMAP.md, milestone 8). That's 0.47 ms a frame for every 1,000 pushed draws, 2.8% of a 60 fps
  frame. It isn't the command stream: milestone 8 cut those dwords by three quarters and the submit didn't move.
  - **Where it goes, measured on 2026-10-15** (a vkbench build timing each part of the replay with the time base,
    after xsdk's milestone 39, local only): writing the push blocks into constants through xsdk, 347 clocks a cube
    for the vertex shader's 4 registers and 461 for the pixel shader's 5, as its tint sits 64 bytes in. Reading the
    push array just after the copy into it costs nothing measurable.
  - **Tried and not taken:** writing only the registers each stage's pushes since the last draw reached, from the
    recording. Finding them cost about 110 clocks a stage and reading the recording about 115 more, more than the
    register group saved: `draws_1000` drew and submitted in 905 us, from 852. vulkan4xenon stays as it was.
  - **Left because** encounter's Aurora, which Dusklight draws through, passes per-draw data in dynamic uniform buffers
    and pushes 16 bytes a draw (vulkan4xenon:docs/ROADMAP.md, section 5), so its push blocks have no registers to
    skip; what's left is xsdk's constant setter itself, about 340 clocks a group of 4.
- **Constants written between draws hold the GPU.** After milestone 39 a draw costs the GPU 0.118 us alone, its two
  constant groups 0.112 alone, and the two together 0.285: each constant write waits for the draw before it to finish
  (docs/HARDWARE.md, "The GPU's cost of a draw, milestone 39"). With vkbench's cubes, which cover the screen between
  them, each draw waits out the last one's pixels, and the cube scenes' time to their fence didn't move.
  - **What might let the next draw's constants in while one is drawing,** untried: alternating constant ranges
    between draws through `SQ_VS_CONST` and `SQ_PS_CONST`'s bases, or constants loaded from memory in some other
    pattern (loaded as they are now, they cost 0.07 us more).
  - **`xsdk_gpu_set_vertices`' fetch constant flush,** kept untried where the texture's went.
  - **When to take it up:** next for the GPU, if the user agrees; the probe (`tests/probe_gpu_draw_cost.c`) takes
    the variants.
- **Starship's scene loads stall its audio (milestone 61).** While the game loads a scene's resources, one update
  takes 130 to 440 ms, where the audio queue holds about 77 ms, so the queue runs dry one to four times a load and the
  sound gaps (docs/HARDWARE.md, "Starship's audio follows its updates, milestone 61"). The audio is made a frame an
  update in lockstep with the game, as libultraship's message queues take no lock
  (lus:src/public/libultra/os_mesg.cpp:15-25), so the audio thread can't run on through a stall.
  - **Left because** the user chose, on 2026-10-25, faster loading later over letting the audio thread run on its own
    clock, as the N64's did, which would take locking those queues and running the game and audio threads truly
    together for the first time (docs/scope/61-fast3d.md, Decisions, 11).
  - **Since then,** the archive is read into memory, and the stalls from the disk are gone; what's left is about 0.1
    to 0.16 ms for each resource the game makes, whatever its size: 534 ms of audio at boot for 3,366, and 78 ms for
    the 778 of the first radio message in a level (docs/HARDWARE.md, "Starship's assets from memory, milestone 61").
    Next: time the parts of one entry's load at boot, which makes the most, to find where that goes. Some scene
    changes hold one update 252 to 257 ms that isn't loading, while the screen is black and the music stopped; not
    yet known.

## Tried and reverted

Changes that worked but weren't faster on the console. Each stays in history, to bring back if a run shows the cost
it removes.

- **A ring the GPU loads push constants from** (vulkan4xenon `2e94c05` and xost `af5bb8b`, reverted by vulkan4xenon
  `0579b93` and xost `77c7605`). Each draw copied its push blocks into 4 MB of write-combined memory and had the GPU
  load them with `xsdk_gpu_load_*_constants`, as uniform blocks are; xost put push blocks on whole groups of 4 for it.
  - **What it saved:** a pushed cube went from 65.3 dwords to 17.3, and a frame from 64 kicks to 18.
  - **What it didn't:** `draws_1000` took 1,217 us against 1,215, its submit 974 us both times, and `states_1000` 2,021
    against 1,975; the revert ran milestone 7's figures again to within 5 us (vulkan4xenon:docs/ROADMAP.md,
    milestone 8).
  - **When to bring it back:** if push-heavy frames fill the command stream, which `xsdk_gpu_stats` shows as waits, or
    the GPU becomes the bottleneck reading constants. At 65 dwords a cube a frame of about 16,000 pushed draws laps
    the 4 MB stream; at 17, about 60,000.

## Questions the console hasn't answered

- **A 5 s wait on a thread's handle that timed out within milliseconds.** In xsdk_test's audio checks at `aac0931`,
  `NtWaitForSingleObjectEx` on a feeder's or busy thread's handle, `USER_MODE`, relative 5 s, returned `STATUS_TIMEOUT`
  after 0.5 to 12.6 ms by the time base, once on a thread that had ended 76 ms before (docs/HARDWARE.md, "Audio's
  feeding, milestone 58"). Milestone 55's checks wait on threads the same way and pass. Why isn't known.
- **The console's state after a long session.** On 2026-10-21, after some hours of titles and launches, three of
  milestone 55's mutant checks failed in a build that had passed them; and after about an hour of launch round trips,
  the console agent's launch returned 1 and no title started. Each passed again after a reboot
  (results/2026-10-21-milestone-56-acceptance/README.md). What builds up isn't known.
- **The depth-bias slope.** `XsdkRaster` takes it, but milestone 14 tested only the constant term.
- **Point mip filtering exactly halfway between two levels:** the nearer level, or the one below. Milestone 15
  avoided it.
- **Linear filtering's precision.** Milestone 15 bounded it by its tolerance of 3 per channel; milestone 57 found it
  off by up to 8 of 255 exactly at texel centres, pulled toward the texel above or to the left (docs/HARDWARE.md,
  "Milestone 57 on the console"). The filter's weights, and why it leans that way, aren't known.
- **Execs on the predicate in vertex shaders.** An if/else on a push constant, its arms in a `setp`'s `(p0)` and
  `(!p0)` execs, hung the GPU in a vertex shader and drew right in a pixel shader (docs/HARDWARE.md, "Branches,
  vulkan4xenon milestone 21"), so xost keeps a vertex shader's as selects. Why is unknown: a probe of a vertex
  shader's lone predicated exec, then of the PredicateClean bit on the `setp`'s exec, would narrow it.
- **An if/else on data in execs on the predicate.** xost makes one selects, both arms running, as an exec on the
  predicate runs for a whole group of 64 vertices or pixels when any of them needs it (xenia:src/xenia/gpu/ucode.h:114-124);
  only an if/else every vertex or pixel agrees on goes in such execs (xenos-toolchain/docs/xsc.md, "Control flow").
  Where they agree over whole groups, as a mesh's parts often do, the execs would skip the arm not taken; whether that
  pays against an exec's own cost is for the console to measure.
- **Which partial constant write hangs the GPU:** the floats, or the lone boolean or loop word. It matters only for
  writing just the changed constants, to save ring space (docs/HARDWARE.md, "Shader constants: partial writes hang the
  GPU, libxenon's whole blocks don't").
- **Texture fetches in vertex shaders** (vulkan4xenon milestone 22's step 3): whether an exec's vertex cache bits
  should mark them, as xost gives them none, and whether a fetch reading what another fetch wrote in its exec needs
  its serialize bit, which xost now sets (xenos-toolchain/docs/xsc.md, "Vertex textures").
- **A pixel shader's fetches skip the pixels that only fill out a quad.** xost sets every pixel shader texture fetch's
  FetchValidOnly bit (src/xsc_lower_sample.c, `fetch_valid_only`), so a pixel outside the triangle in a quad along its
  edge doesn't fetch. A sample at coordinates another sample gives, at the GPU's LOD, may then take its gradients from
  such a pixel's stale register and the wrong level along triangle edges. What the bit does to them on the console,
  and what clearing it costs, a probe would show.
- **Whether a derivative is a quad's or a row's.** `getGradients` and the GPU's LOD may difference a 2x2 quad's top
  row and left column or each pixel's own row and column; milestone 46 step 6's grid takes derivatives of values
  linear across a quad, alike either way (docs/HARDWARE.md, "Samples in a loop's pass, milestone 46 step 6").
