#ifndef BLADES_VIDEO_H
#define BLADES_VIDEO_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
enum { VIDEO_FRAME_SLOTS=3,VIDEO_MAX_WIDTH=1280,VIDEO_MAX_HEIGHT=720,VIDEO_AUDIO_RATE=48000,VIDEO_AUDIO_CHANNELS=6 };
typedef enum { VIDEO_IDLE,VIDEO_OPENING,VIDEO_PLAYING,VIDEO_PAUSED,VIDEO_STOPPING,VIDEO_ENDED,VIDEO_FAILED } VideoState;
typedef struct {
    VideoState state;unsigned revision,width,height,channels,decoded,dropped;
    double position,duration,aspect;
    bool has_audio;char error[192];
} VideoSnapshot;
typedef struct {const unsigned char *rgba;unsigned width,height,slot,revision;double pts,aspect;} VideoPicture;
typedef struct {unsigned channels,audio_latency_frames;bool audio_available;void (*log)(const char *);} VideoConfig;
typedef struct VideoPlayer VideoPlayer;
VideoPlayer *video_create(const VideoConfig *);
bool video_play(VideoPlayer *,const char *path);
void video_stop(VideoPlayer *);
void video_pause(VideoPlayer *,bool paused);
void video_seek(VideoPlayer *,double relative_seconds);
void video_poll(VideoPlayer *,VideoSnapshot *);
bool video_take_picture(VideoPlayer *,VideoPicture *);
void video_release_picture(VideoPlayer *,unsigned slot,unsigned revision);
/* Writes n interleaved frames, config.channels channels. Nonblocking w.r.t. I/O
   and decode; silence on pause/underflow. The service remains alive until close. */
bool video_audio_render(VideoPlayer *,float *out,unsigned frames);
unsigned video_audio_channels(const VideoPlayer *);
void video_close(VideoPlayer *);
bool video_state_active(VideoState);
#endif
