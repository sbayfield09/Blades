// The texture layout and fetch constant below come from libxenon:drivers/xenos/xe.c, rewritten for the SDK.
// libxenon carries this notice:
//
// Copyright (c) 2009, free60.org
// USB Stack Copyright (c) 2000,2001,2002,2003,2005, Broadcom Corporation
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY free60.org ''AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL free60.org BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE

#include "xsdk/texture.h"

#include <altivec.h>
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "gpu_private.h"
#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"

enum {
	// Linear rows start every 256 bytes (xenia:src/xenia/gpu/xenos.h:1179-1181).
	LINEAR_ROW_ALIGNMENT_BYTES = 256,
	// Tiled textures are whole 32 by 32 tiles of blocks, and libxenon pads linear ones to 32 rows too (xe.c:2082-2083).
	TILE_BLOCKS = 32,
	PAGE_BYTES = 0x1000,
	WORD_BYTES = 4,
	// The fetch constant's fields (xenia:src/xenia/gpu/xenos.h:1184-1285), set as libxenon sets them (xe.c:1187-1207).
	FETCH_TYPE_TEXTURE = 2,
	CLAMP_X_SHIFT = 10,
	CLAMP_Y_SHIFT = 13,
	CLAMP_Z_SHIFT = 16,
	PITCH_SHIFT = 22,
	PITCH_UNIT_LOG2 = 5,
	TILED_SHIFT = 31,
	ENDIAN_SHIFT = 6,
	HEIGHT_SHIFT = 13,
	// A cube's stack depth is its faces less one; a 3D texture's sizes are narrower (xenos.h:1232-1250).
	STACK_DEPTH_SHIFT = 26,
	HEIGHT_3D_SHIFT = 11,
	DEPTH_3D_SHIFT = 22,
	SWIZZLE_SHIFT = 1,
	SWIZZLE_BITS = 3,
	SWIZZLE_MASK = 0xFFF,
	// TextureSign, two bits a component from x (xenia:src/xenia/gpu/xenos.h:121-129, 1202-1205).
	SIGN_SHIFT = 2,
	SIGN_BITS = 2,
	SIGN_MASK = 0xFF,
	TEXTURE_SIGN_SIGNED = 1,
	TEXTURE_SIGN_GAMMA = 3,
	MAG_FILTER_SHIFT = 19,
	MIN_FILTER_SHIFT = 21,
	MIP_FILTER_SHIFT = 23,
	ANISO_FILTER_SHIFT = 25,
	VOL_MAG_FILTER_SHIFT = 0,
	VOL_MIN_FILTER_SHIFT = 1,
	MIP_MIN_LEVEL_SHIFT = 2,
	MIP_MAX_LEVEL_SHIFT = 6,
	MIP_LEVEL_MASK = 0xF,
	LOD_BIAS_SHIFT = 12,
	// A signed 10-bit field with 5 fractional bits.
	LOD_BIAS_STEPS = 32,
	LOD_BIAS_MASK = 0x3FF,
	BORDER_COLOR_SHIFT = 0,
	DIMENSION_SHIFT = 9,
	// Levels at 16 texels and under share a tail (xenia:src/xenia/gpu/texture_util.h:76-83).
	PACKED_MIPS = 1 << 11,
	FETCH_ADDRESS_ALIGNMENT = 0x1000,
	// A 3D texture's tiles are 4 slices deep (xenia:src/xenia/gpu/xenos.h:1155-1158, texture_util.cc:346-353).
	TILE_SLICES = 4,
	// Past the console's memory several times over, and short of where the sizes would overflow.
	MAX_TEXTURE_PAGES = 0x80000000u / PAGE_BYTES,
	// In the tiled layout, a row's blocks sit together for 16 bytes, or 8 blocks of a byte: x's low 3 bits and the
	// offset's low 4 stay where they are (xsdk_tiled_2d).
	TILED_RUN_BYTES = 16,
	TILED_RUN_BLOCKS_MAX = 8,
	// A tile's row of blocks is 4 groups of 8, one to each pipe, which offset bits 6 and 7 hold; a group's 16-byte runs
	// go in pairs 32 bytes apart, the pairs 256 bytes apart (xsdk_tiled_2d).
	PIPES = 4,
	PIPE_SHIFT = 6,
	GROUP_BLOCKS = 8,
	QUAD_BYTES = 16,
	RUN_PAIR_BYTES = 32,
	RUN_PAIRS_BYTES = 256,
	// 16-byte runs loaded before they're stored; 4 fit in v0-v13, which a call needn't save.
	CHUNK_QUADS = 4,
	// The CPU's cache line (libxenon:drivers/ppc/cache.S:1); uploads ask for their bytes 8 lines ahead, as memcpy does.
	LINE_BYTES = 128,
	PREFETCH_BYTES = 8 * LINE_BYTES,
};

typedef vector unsigned char Quad;

// Endian swaps (xenia:src/xenia/gpu/xenos.h:193-198); libxenon marks 16-bit formats 8-in-16 (xe.h:184).
enum {
	ENDIAN_NONE = 0,
	ENDIAN_8IN16 = 1,
	ENDIAN_8IN32 = 2,
};

// Swizzle sources: the components x to w, then 0 and 1 (xenia:src/xenia/gpu/xenos.h:1015-1030).
enum {
	X,
	Y,
	Z,
	W,
	ZERO,
	ONE,
};

// Where each of red, green, blue and alpha comes from.
#define SWIZZLE(red, green, blue, alpha) ((red) | (green) << 3 | (blue) << 6 | (alpha) << 9)

typedef struct {
	uint32_t format;
	// Texels across and down a block, as a power of two.
	uint32_t block_log2;
	uint32_t block_bytes_log2;
	uint32_t endian;
	uint32_t swizzle;
} FormatInfo;

// TextureFormat values and block sizes (xenia:src/xenia/gpu/xenos.h:450-508, texture_info_formats.cc:25-55). Each
// format's x is its lowest bits or first byte, as Xenia maps them to Vulkan (vulkan/vulkan_texture_cache.cc:94-265).
static const FormatInfo formats[XSDK_FORMATS] = {
	[XSDK_FORMAT_A8R8G8B8] = { 6, 0, 2, ENDIAN_8IN32, SWIZZLE(Z, Y, X, W) },
	[XSDK_FORMAT_R5G6B5] = { 4, 0, 1, ENDIAN_8IN16, SWIZZLE(Z, Y, X, ONE) },
	[XSDK_FORMAT_A1R5G5B5] = { 3, 0, 1, ENDIAN_8IN16, SWIZZLE(Z, Y, X, W) },
	[XSDK_FORMAT_A4R4G4B4] = { 15, 0, 1, ENDIAN_8IN16, SWIZZLE(Z, Y, X, W) },
	[XSDK_FORMAT_A2B10G10R10] = { 7, 0, 2, ENDIAN_8IN32, SWIZZLE(X, Y, Z, W) },
	[XSDK_FORMAT_R8] = { 2, 0, 0, ENDIAN_NONE, SWIZZLE(X, ZERO, ZERO, ONE) },
	[XSDK_FORMAT_R8G8] = { 10, 0, 1, ENDIAN_NONE, SWIZZLE(X, Y, ZERO, ONE) },
	[XSDK_FORMAT_R16F] = { 30, 0, 1, ENDIAN_8IN16, SWIZZLE(X, ZERO, ZERO, ONE) },
	[XSDK_FORMAT_R16G16F] = { 31, 0, 2, ENDIAN_8IN16, SWIZZLE(X, Y, ZERO, ONE) },
	[XSDK_FORMAT_R16G16B16A16F] = { 32, 0, 3, ENDIAN_8IN16, SWIZZLE(X, Y, Z, W) },
	[XSDK_FORMAT_DXT1] = { 18, 2, 3, ENDIAN_8IN16, SWIZZLE(X, Y, Z, W) },
	[XSDK_FORMAT_DXT3] = { 19, 2, 4, ENDIAN_8IN16, SWIZZLE(X, Y, Z, W) },
	[XSDK_FORMAT_DXT5] = { 20, 2, 4, ENDIAN_8IN16, SWIZZLE(X, Y, Z, W) },
	[XSDK_FORMAT_R8G8B8A8] = { 6, 0, 2, ENDIAN_NONE, SWIZZLE(X, Y, Z, W) },
	[XSDK_FORMAT_B8G8R8A8] = { 6, 0, 2, ENDIAN_NONE, SWIZZLE(Z, Y, X, W) },
	// k_32_FLOAT (xenia:src/xenia/gpu/xenos.h:512).
	[XSDK_FORMAT_R32F] = { 36, 0, 2, ENDIAN_8IN32, SWIZZLE(X, ZERO, ZERO, ONE) },
	// k_24_8, which Xenia samples as its depth (xenos.h:498; vulkan/vulkan_texture_cache.cc:209-212).
	[XSDK_FORMAT_D24S8] = { 22, 0, 2, ENDIAN_8IN32, SWIZZLE(X, ZERO, ZERO, ONE) },
	// k_DXN and k_DXT5A, which Xenia reads as Vulkan's BC5 and BC4 (xenos.h:525, 535;
	// vulkan/vulkan_texture_cache.cc:333-337, 384-388).
	[XSDK_FORMAT_DXN] = { 49, 2, 4, ENDIAN_8IN16, SWIZZLE(X, Y, ZERO, ONE) },
	[XSDK_FORMAT_DXT5A] = { 59, 2, 3, ENDIAN_8IN16, SWIZZLE(X, ZERO, ZERO, ONE) },
	// k_16, k_16_16 and k_16_16_16_16, read from 0 to 1 (xenos.h:500-502; vulkan/vulkan_texture_cache.cc:217-234).
	[XSDK_FORMAT_R16] = { 24, 0, 1, ENDIAN_8IN16, SWIZZLE(X, ZERO, ZERO, ONE) },
	[XSDK_FORMAT_R16G16] = { 25, 0, 2, ENDIAN_8IN16, SWIZZLE(X, Y, ZERO, ONE) },
	[XSDK_FORMAT_R16G16B16A16] = { 26, 0, 3, ENDIAN_8IN16, SWIZZLE(X, Y, Z, W) },
	// k_10_11_11 and k_11_11_10, fixed point, red lowest (xenos.h:492-493; shaders/pixel_formats.xesli:450-484).
	[XSDK_FORMAT_B10G11R11] = { 16, 0, 2, ENDIAN_8IN32, SWIZZLE(X, Y, Z, ONE) },
	[XSDK_FORMAT_B11G11R10] = { 17, 0, 2, ENDIAN_8IN32, SWIZZLE(X, Y, Z, ONE) },
};

static NTSTATUS reject(const char *why)
{
	xsdk_log_write("texture: %s", why);
	return STATUS_INVALID_PARAMETER;
}

static uint32_t round_up(uint32_t value, uint32_t alignment)
{
	return (value + alignment - 1) / alignment * alignment;
}

// Down to 1x1 on the long side, as Xenia counts them (xenia:src/xenia/gpu/texture_util.cc:68-74).
static uint32_t level_count(uint32_t width, uint32_t height)
{
	const uint32_t longest = width > height ? width : height;
	return 32 - (uint32_t)__builtin_clz(longest);
}

static uint32_t level_size(uint32_t size, uint32_t level)
{
	return size >> level ? size >> level : 1;
}

static TextureLayout layout_of(const XsdkTexture *texture)
{
	const FormatInfo *const info = &formats[texture->format];
	return (TextureLayout){ .width = texture->width,
		.height = texture->height,
		.levels = texture->levels,
		.block_log2 = info->block_log2,
		.block_bytes_log2 = info->block_bytes_log2,
		.base_pitch_blocks = texture->pitch >> info->block_log2,
		.mip_offset_bytes = texture->mip_offset_bytes,
		.faces = texture->dimension == XSDK_TEXTURE_CUBE ? XSDK_CUBE_FACES : 1,
		.packed = (texture->fetch[5] & PACKED_MIPS) != 0 };
}

// Whole tiles of blocks; linear rows also start every 256 bytes.
static uint32_t base_pitch_blocks(const FormatInfo *info, uint32_t width, bool tiled)
{
	const uint32_t blocks = round_up(xsdk_texture_blocks(width, info->block_log2), TILE_BLOCKS);
	if (tiled)
		return blocks;
	return round_up(blocks << info->block_bytes_log2, LINEAR_ROW_ALIGNMENT_BYTES) >> info->block_bytes_log2;
}

// The fetch constant's sizes, each less one: a cube's stack depth is 5 (xenia:src/xenia/gpu/texture_util.cc:50-52).
static uint32_t fetch_size(uint32_t dimension, uint32_t width, uint32_t height, uint32_t depth)
{
	if (dimension == XSDK_TEXTURE_3D)
		return (depth - 1) << DEPTH_3D_SHIFT | (height - 1) << HEIGHT_3D_SHIFT | (width - 1);
	return (depth - 1) << STACK_DEPTH_SHIFT | (height - 1) << HEIGHT_SHIFT | (width - 1);
}

// Xe_CreateTexture and TEXTURE_FETCH for the format's levels, the base then the mips, a page apart. A cube's levels
// each hold its six faces in turn, a page apart, and a 3D texture's slices share its tiles
// (xenia:src/xenia/gpu/texture_util.cc:337-353, 438-444).
static NTSTATUS init_texture(XsdkTexture *texture, uint32_t dimension, uint32_t format, uint32_t width, uint32_t height,
	uint32_t depth, uint32_t levels, bool tiled)
{
	if (format >= XSDK_FORMATS)
		return reject("format not one of XSDK_FORMAT_*");
	const FormatInfo *const info = &formats[format];
	const uint32_t pitch_blocks = base_pitch_blocks(info, width, tiled);
	const uint32_t rows = round_up(xsdk_texture_blocks(height, info->block_log2), TILE_BLOCKS);
	const uint32_t slices = dimension == XSDK_TEXTURE_3D ? round_up(depth, TILE_SLICES) : 1;
	const uint32_t faces = dimension == XSDK_TEXTURE_CUBE ? XSDK_CUBE_FACES : 1;
	const uint64_t face_pages =
		(((uint64_t)pitch_blocks * rows * slices << info->block_bytes_log2) + PAGE_BYTES - 1) / PAGE_BYTES;
	if (face_pages * faces > MAX_TEXTURE_PAGES)
		return reject("texture past 2 GB");
	const uint32_t mip_offset_bytes = (uint32_t)face_pages * PAGE_BYTES * faces;
	const TextureLayout layout = { .width = width,
		.height = height,
		.levels = levels,
		.block_log2 = info->block_log2,
		.block_bytes_log2 = info->block_bytes_log2,
		.base_pitch_blocks = pitch_blocks,
		.mip_offset_bytes = mip_offset_bytes,
		.faces = faces,
		.packed = true };
	const uint32_t size_bytes = mip_offset_bytes + xsdk_texture_mip_bytes(&layout);
	const uint32_t pitch = pitch_blocks << info->block_log2;
	*texture = (XsdkTexture){
		.size_bytes = size_bytes,
		.format = format,
		.width = width,
		.height = height,
		.levels = levels,
		.dimension = dimension,
		.depth = depth,
		.pitch = pitch,
		.tiled = tiled,
		.mip_offset_bytes = mip_offset_bytes,
		.fetch = {
			FETCH_TYPE_TEXTURE | (pitch >> PITCH_UNIT_LOG2) << PITCH_SHIFT | (uint32_t)tiled << TILED_SHIFT,
			info->endian << ENDIAN_SHIFT | info->format,
			fetch_size(dimension, width, height, depth),
			info->swizzle << SWIZZLE_SHIFT,
			(levels - 1) << MIP_MAX_LEVEL_SHIFT,
			PACKED_MIPS | dimension << DIMENSION_SHIFT,
		},
	};
	return STATUS_SUCCESS;
}

NTSTATUS xsdk_texture_init(
	XsdkTexture *texture, uint32_t format, uint32_t width, uint32_t height, uint32_t levels, bool tiled)
{
	if (!width || !height || width > XSDK_TEXTURE_MAX_SIZE || height > XSDK_TEXTURE_MAX_SIZE)
		return reject("texture size not from 1 to 8192");
	if (!levels || levels > level_count(width, height))
		return reject("levels not from 1 to a 1x1 level");
	if (!tiled && levels > 1) {
		xsdk_log_write("texture: linear textures have one level");
		return STATUS_NOT_IMPLEMENTED;
	}
	return init_texture(texture, XSDK_TEXTURE_2D, format, width, height, 1, levels, tiled);
}

NTSTATUS xsdk_texture_init_cube(XsdkTexture *texture, uint32_t format, uint32_t size, uint32_t levels)
{
	if (!size || size > XSDK_TEXTURE_MAX_SIZE)
		return reject("cube size not from 1 to 8192");
	if (!levels || levels > level_count(size, size))
		return reject("levels not from 1 to a 1x1 level");
	return init_texture(texture, XSDK_TEXTURE_CUBE, format, size, size, XSDK_CUBE_FACES, levels, true);
}

NTSTATUS xsdk_texture_init_3d(XsdkTexture *texture, uint32_t format, uint32_t width, uint32_t height, uint32_t depth)
{
	if (!width || !height || width > XSDK_TEXTURE_3D_MAX_SIZE || height > XSDK_TEXTURE_3D_MAX_SIZE)
		return reject("3D texture size not from 1 to 2048");
	if (!depth || depth > XSDK_TEXTURE_3D_MAX_DEPTH)
		return reject("3D texture depth not from 1 to 1024");
	return init_texture(texture, XSDK_TEXTURE_3D, format, width, height, depth, 1, true);
}

void xsdk_texture_attach(XsdkTexture *texture, volatile uint32_t *texels)
{
	const uint32_t address = xsdk_gpu_address(texels);
	assert(address % FETCH_ADDRESS_ALIGNMENT == 0);
	// Mips in the base's tail point back at the base, so Xenia reads them where the console does.
	const bool mips_apart = texture->size_bytes > texture->mip_offset_bytes;
	const uint32_t mip_address = texture->levels == 1 ? 0 : mips_apart ? address + texture->mip_offset_bytes : address;
	texture->texels = texels;
	texture->address = address;
	texture->fetch[1] |= address;
	texture->fetch[5] |= mip_address;
}

NTSTATUS xsdk_texture_create(
	XsdkTexture *texture, uint32_t format, uint32_t width, uint32_t height, uint32_t levels, bool tiled)
{
	const NTSTATUS status = xsdk_texture_init(texture, format, width, height, levels, tiled);
	if (!NT_SUCCESS(status))
		return status;
	volatile uint32_t *const texels = xsdk_gpu_alloc(texture->size_bytes);
	if (!texels)
		return STATUS_NO_MEMORY;
	xsdk_texture_attach(texture, texels);
	return STATUS_SUCCESS;
}

// A block's byte offset in its stored image; z, a 3D texture's slice.
static uint32_t block_offset(
	const XsdkTexture *texture, const TextureLevelPlace *place, uint32_t x, uint32_t y, uint32_t z)
{
	const uint32_t bytes_log2 = formats[texture->format].block_bytes_log2;
	if (texture->dimension == XSDK_TEXTURE_3D)
		return xsdk_tiled_3d(x, y, z, place->pitch_blocks, place->slice_rows, bytes_log2);
	if (texture->tiled)
		return xsdk_tiled_2d(x, y, place->pitch_blocks, bytes_log2);
	return (y * place->pitch_blocks + x) << bytes_log2;
}

// Bytes within one 32-bit word, merged with what the word holds unless they fill it: reading the word back from
// write-combined memory goes all the way to memory.
static void put_bytes(volatile uint32_t *image, uint32_t offset, const uint8_t *bytes, uint32_t count)
{
	volatile uint32_t *const word = image + offset / WORD_BYTES;
	uint32_t value = count == WORD_BYTES ? 0 : *word;
	memcpy((uint8_t *)&value + offset % WORD_BYTES, bytes, count);
	*word = value;
}

// Whole words from word-aligned bytes to a word-aligned offset, each one store.
static void put_words(volatile uint32_t *image, uint32_t offset, const uint8_t *bytes, uint32_t count)
{
	volatile uint32_t *word = image + offset / WORD_BYTES;
	for (uint32_t i = 0; i < count; i += WORD_BYTES) {
		uint32_t value;
		memcpy(&value, bytes + i, WORD_BYTES);
		*word++ = value;
	}
}

// One block, a word or part of one at a time: blocks of 4 bytes or more fill whole words, smaller ones share a word
// with their neighbours.
static void put_block(volatile uint32_t *image, uint32_t offset, const uint8_t *bytes, uint32_t block_bytes)
{
	for (uint32_t byte = 0; byte < block_bytes; byte += WORD_BYTES)
		put_bytes(image, offset + byte, bytes + byte, block_bytes < WORD_BYTES ? block_bytes : WORD_BYTES);
}

// Whole words from a word-aligned offset to word-aligned bytes, each one store, as the bytes may be write-combined
// memory too.
static void get_words(volatile const uint32_t *image, uint32_t offset, uint8_t *bytes, uint32_t count)
{
	volatile const uint32_t *const words = image + offset / WORD_BYTES;
	volatile uint32_t *const out = (volatile uint32_t *)(uintptr_t)bytes;
	for (uint32_t i = 0; i < count / WORD_BYTES; i++)
		out[i] = words[i];
}

// Bytes from within one 32-bit word, one store each, as they needn't be word-aligned.
static void get_bytes(volatile const uint32_t *image, uint32_t offset, uint8_t *bytes, uint32_t count)
{
	const uint32_t value = image[offset / WORD_BYTES];
	volatile uint8_t *const out = bytes;
	for (uint32_t i = 0; i < count; i++)
		out[i] = ((const uint8_t *)&value)[offset % WORD_BYTES + i];
}

static void get_block(volatile const uint32_t *image, uint32_t offset, uint8_t *bytes, uint32_t block_bytes)
{
	for (uint32_t byte = 0; byte < block_bytes; byte += WORD_BYTES)
		get_bytes(image, offset + byte, bytes + byte, block_bytes < WORD_BYTES ? block_bytes : WORD_BYTES);
}

// A run of whole words, or one block, between the image and bytes: copied out to the bytes, or in from them.
static void move_run(volatile uint32_t *image, uint32_t offset, uint8_t *bytes, uint32_t count, bool words, bool out)
{
	if (words && out)
		get_words(image, offset, bytes, count);
	else if (words)
		put_words(image, offset, bytes, count);
	else if (out)
		get_block(image, offset, bytes, count);
	else
		put_block(image, offset, bytes, count);
}

// How many blocks in a row go as one run from a block whose x is a multiple of it: in a linear row, the whole row cut
// to whole words.
static uint32_t run_blocks(const XsdkTexture *texture, const FormatInfo *info, uint32_t columns)
{
	if (!texture->tiled) {
		const uint32_t per_word = info->block_bytes_log2 >= 2 ? 1 : WORD_BYTES >> info->block_bytes_log2;
		const uint32_t whole = columns / per_word * per_word;
		return whole ? whole : 1;
	}
	const uint32_t blocks = TILED_RUN_BYTES >> info->block_bytes_log2;
	return blocks == 0 ? 1 : blocks > TILED_RUN_BLOCKS_MAX ? TILED_RUN_BLOCKS_MAX : blocks;
}

static uint32_t level_rows(const XsdkTexture *texture, uint32_t level)
{
	return xsdk_texture_blocks(level_size(texture->height, level), formats[texture->format].block_log2);
}

static inline void prefetch(const uint8_t *address)
{
	__asm__ volatile("dcbt 0, %0" : : "r"(address));
}

static inline uint32_t load_word(const uint8_t *bytes)
{
	uint32_t value;
	memcpy(&value, bytes, WORD_BYTES);
	return value;
}

// 16 bytes from anywhere: the two aligned quads they span, put together. Each holds one of the bytes, so neither
// reaches past them.
static inline Quad load_quad(const uint8_t *bytes, Quad shift)
{
	return vec_perm(vec_ld(0, bytes), vec_ld(QUAD_BYTES - 1, bytes), shift);
}

// One tile on along a row: one more in the offset's tile bits, carried over the bits between them.
static inline uint32_t next_tile(uint32_t offset, uint32_t tile_bits)
{
	return (offset & ~tile_bits) | (((offset | ~tile_bits) + 1) & tile_bits);
}

// A tile's row of bytes: each pipe's 8 as two words at the tile's offset with its pipe bits flipped. The loads go
// first, so they overlap.
static inline void put_tile_bytes(volatile uint32_t *image, uint32_t offset, const uint8_t *bytes)
{
	uint32_t words[PIPES * 2];
#pragma GCC unroll 8
	for (uint32_t i = 0; i < PIPES * 2; i++)
		words[i] = load_word(bytes + i * WORD_BYTES);
#pragma GCC unroll 4
	for (uint32_t pipe = 0; pipe < PIPES; pipe++) {
		volatile uint32_t *const group = (volatile uint32_t *)((uintptr_t)image + (offset ^ pipe << PIPE_SHIFT));
		group[0] = words[pipe * 2];
		group[1] = words[pipe * 2 + 1];
	}
}

// A tile's row of larger blocks, each pipe's group of 8 in 16-byte runs from the tile's offset with its pipe bits
// flipped, as VMX stores, which land in write-combined memory as the runs start on 16 bytes (docs/HARDWARE.md,
// "Copies into write-combined and cached memory"). Each 4 runs' loads go first, so they overlap.
static inline __attribute__((always_inline)) void put_tile_quads(
	volatile uint32_t *image, uint32_t offset, const uint8_t *bytes, Quad shift, uint32_t bytes_log2)
{
	uint8_t *const image_bytes = (uint8_t *)(uintptr_t)image;
	const uint32_t group_quads = (GROUP_BLOCKS << bytes_log2) / QUAD_BYTES;
	const uint32_t tile_quads = PIPES * group_quads;
	const uint32_t chunk = tile_quads < CHUNK_QUADS ? tile_quads : CHUNK_QUADS;
#pragma GCC unroll 8
	for (uint32_t first = 0; first < tile_quads; first += chunk) {
		Quad quads[CHUNK_QUADS];
#pragma GCC unroll 4
		for (uint32_t i = 0; i < chunk; i++)
			quads[i] = load_quad(bytes + (first + i) * QUAD_BYTES, shift);
#pragma GCC unroll 4
		for (uint32_t i = 0; i < chunk; i++) {
			const uint32_t pipe = (first + i) / group_quads;
			const uint32_t run = (first + i) % group_quads;
			const uint32_t to =
				(offset ^ pipe << PIPE_SHIFT) + (run & 1) * RUN_PAIR_BYTES + (run >> 1) * RUN_PAIRS_BYTES;
			vec_st(quads[i], (int)to, image_bytes);
		}
	}
}

// A row's whole tiles from word-aligned bytes, the offset the first's. Inlined for each block size, so the offsets
// within a tile are constants.
static inline __attribute__((always_inline)) void put_tiles_sized(volatile uint32_t *image, uint32_t offset,
	uint32_t tiles, const uint8_t *bytes, uint32_t tile_bits, uint32_t bytes_log2)
{
	assert(((uintptr_t)image + offset) % (bytes_log2 ? QUAD_BYTES : 2 * WORD_BYTES) == 0);
	const Quad shift = vec_lvsl(0, bytes);
	const uint32_t tile_bytes = TILE_BLOCKS << bytes_log2;
	for (uint32_t tile = 0; tile < tiles; tile++) {
		for (uint32_t line = 0; line < tile_bytes; line += LINE_BYTES)
			prefetch(bytes + line + PREFETCH_BYTES);
		if (bytes_log2 == 0)
			put_tile_bytes(image, offset, bytes);
		else
			put_tile_quads(image, offset, bytes, shift, bytes_log2);
		offset = next_tile(offset, tile_bits);
		bytes += tile_bytes;
	}
}

// Out of line, so copy_rows saves no vector registers for downloads and unaligned rows.
static __attribute__((noinline)) void put_tiles(volatile uint32_t *image, uint32_t offset, uint32_t tiles,
	const uint8_t *bytes, uint32_t tile_bits, uint32_t bytes_log2)
{
	switch (bytes_log2) {
	case 0:
		put_tiles_sized(image, offset, tiles, bytes, tile_bits, 0);
		return;
	case 1:
		put_tiles_sized(image, offset, tiles, bytes, tile_bits, 1);
		return;
	case 2:
		put_tiles_sized(image, offset, tiles, bytes, tile_bits, 2);
		return;
	case 3:
		put_tiles_sized(image, offset, tiles, bytes, tile_bits, 3);
		return;
	default:
		put_tiles_sized(image, offset, tiles, bytes, tile_bits, 4);
		return;
	}
}

// Rows of a level's blocks in a face or slice, from first_row, copied in from data or out to it, row_bytes apart.
static void copy_rows(const XsdkTexture *texture, uint32_t level, uint32_t slice, uint32_t first_row,
	uint32_t row_count, uint8_t *data, uint32_t row_bytes, bool out)
{
	assert(level < texture->levels && slice < texture->depth && first_row + row_count <= level_rows(texture, level));
	const FormatInfo *const info = &formats[texture->format];
	const TextureLayout layout = layout_of(texture);
	TextureLevelPlace place;
	xsdk_texture_place(&layout, level, &place);
	const uint32_t face = texture->dimension == XSDK_TEXTURE_CUBE ? slice : 0;
	volatile uint32_t *const image = texture->texels + (place.offset_bytes + face * place.face_bytes) / WORD_BYTES;
	const uint32_t block_bytes = 1u << info->block_bytes_log2;
	const uint32_t columns = xsdk_texture_blocks(level_size(texture->width, level), info->block_log2);
	// A run goes as whole words, read from or written to the rows as words, so they must be word-aligned; unaligned
	// rows go a block at a time.
	const bool aligned = ((uintptr_t)data | row_bytes) % WORD_BYTES == 0;
	const uint32_t run = aligned ? run_blocks(texture, info, columns) : 1;
	const uint32_t run_bytes = run * block_bytes;
	// Uploads from aligned rows put whole tiles at once, from tiles_x; the blocks around them go in runs.
	const uint32_t to_tile = (TILE_BLOCKS - place.x % TILE_BLOCKS) % TILE_BLOCKS;
	const uint32_t tiles_x = texture->tiled && aligned && !out && to_tile < columns ? to_tile : columns;
	const uint32_t tiles = (columns - tiles_x) / TILE_BLOCKS;
	const uint32_t tile_bits =
		tiles ? xsdk_tiled_tile_bits(texture->dimension == XSDK_TEXTURE_3D, info->block_bytes_log2) : 0;
	for (uint32_t y = 0; y < row_count; y++) {
		uint8_t *const row = data + y * row_bytes;
		uint32_t x = 0;
		while (x < columns) {
			if (x == tiles_x && tiles) {
				const uint32_t first = block_offset(texture, &place, place.x + x, place.y + first_row + y, slice);
				put_tiles(image, first, tiles, row + x * block_bytes, tile_bits, info->block_bytes_log2);
				x += tiles * TILE_BLOCKS;
				continue;
			}
			const uint32_t offset = block_offset(texture, &place, place.x + x, place.y + first_row + y, slice);
			// A whole run, starting where the layout's runs start, of whole words: at a packed level's edges and
			// across a linear row's last bytes, blocks go one at a time.
			const bool whole = (place.x + x) % run == 0 && x + run <= columns && run_bytes % WORD_BYTES == 0 &&
				offset % WORD_BYTES == 0;
			move_run(image, offset, row + x * block_bytes, whole ? run_bytes : block_bytes, whole, out);
			x += whole ? run : 1;
		}
	}
}

void xsdk_texture_upload(XsdkTexture *texture, uint32_t level, const void *data, uint32_t row_bytes)
{
	xsdk_texture_upload_rows(texture, level, 0, level_rows(texture, level), data, row_bytes);
}

void xsdk_texture_upload_rows(
	XsdkTexture *texture, uint32_t level, uint32_t first_row, uint32_t row_count, const void *data, uint32_t row_bytes)
{
	xsdk_texture_upload_slice_rows(texture, level, 0, first_row, row_count, data, row_bytes);
}

void xsdk_texture_download_rows(
	const XsdkTexture *texture, uint32_t level, uint32_t first_row, uint32_t row_count, void *data, uint32_t row_bytes)
{
	xsdk_texture_download_slice_rows(texture, level, 0, first_row, row_count, data, row_bytes);
}

void xsdk_texture_upload_slice_rows(XsdkTexture *texture, uint32_t level, uint32_t slice, uint32_t first_row,
	uint32_t row_count, const void *data, uint32_t row_bytes)
{
	copy_rows(texture, level, slice, first_row, row_count, (uint8_t *)(uintptr_t)data, row_bytes, false);
	__asm__ volatile("sync" ::: "memory");
}

void xsdk_texture_download_slice_rows(const XsdkTexture *texture, uint32_t level, uint32_t slice, uint32_t first_row,
	uint32_t row_count, void *data, uint32_t row_bytes)
{
	copy_rows(texture, level, slice, first_row, row_count, data, row_bytes, true);
}

// Where the GPU takes an XSDK_CHANNEL_* from, among the swizzle sources, given the format's own swizzle.
static uint32_t channel_source(uint32_t own, uint32_t channel)
{
	if (channel == XSDK_CHANNEL_ZERO)
		return ZERO;
	if (channel == XSDK_CHANNEL_ONE)
		return ONE;
	return own >> channel * SWIZZLE_BITS & 7;
}

void xsdk_texture_swizzle(XsdkTexture *texture, const uint32_t channels[4])
{
	const uint32_t own = formats[texture->format].swizzle;
	uint32_t swizzle = 0;
	for (uint32_t i = 0; i < 4; i++) {
		assert(channels[i] <= XSDK_CHANNEL_ONE);
		swizzle |= channel_source(own, channels[i]) << i * SWIZZLE_BITS;
	}
	texture->fetch[3] = (texture->fetch[3] & ~((uint32_t)SWIZZLE_MASK << SWIZZLE_SHIFT)) | swizzle << SWIZZLE_SHIFT;
}

void xsdk_texture_base_at_corner(XsdkTexture *texture)
{
	assert(texture->levels == 1 && texture->dimension == XSDK_TEXTURE_2D && texture->tiled);
	if (xsdk_texture_packed_level(texture->width, texture->height) == 0)
		texture->fetch[5] &= ~(uint32_t)PACKED_MIPS;
}

bool xsdk_texture_base_in_tail(const XsdkTexture *texture)
{
	return (texture->fetch[5] & PACKED_MIPS) && xsdk_texture_packed_level(texture->width, texture->height) == 0;
}

// Xenos's TextureSign for each XSDK_SIGN_*.
static const uint8_t texture_signs[] = {
	[XSDK_SIGN_UNSIGNED] = 0,
	[XSDK_SIGN_SIGNED] = TEXTURE_SIGN_SIGNED,
	[XSDK_SIGN_GAMMA] = TEXTURE_SIGN_GAMMA,
};

// The signedness applies to the data's components, before the swizzle (xenia:src/xenia/gpu/xenos.h:1195-1196), so each
// channel's goes to the component the format reads it from.
void xsdk_texture_signs(XsdkTexture *texture, const uint32_t signs[4])
{
	const uint32_t own = formats[texture->format].swizzle;
	uint32_t fields = 0;
	for (uint32_t i = 0; i < 4; i++) {
		assert(signs[i] <= XSDK_SIGN_GAMMA);
		const uint32_t component = own >> i * SWIZZLE_BITS & 7;
		if (component <= W)
			fields |= (uint32_t)texture_signs[signs[i]] << component * SIGN_BITS;
	}
	texture->fetch[0] = (texture->fetch[0] & ~((uint32_t)SIGN_MASK << SIGN_SHIFT)) | fields << SIGN_SHIFT;
}

void xsdk_texture_free(XsdkTexture *texture)
{
	xsdk_gpu_free(texture->texels);
	*texture = (XsdkTexture){ .texels = NULL };
}

// AnisoFilter: off, then at most 1, 2, 4, 8 and 16 to 1 (xenia:src/xenia/gpu/xenos.h:140-148).
static uint32_t aniso_filter(uint32_t max_anisotropy)
{
	return max_anisotropy ? 32 - (uint32_t)__builtin_clz(max_anisotropy) : 0;
}

void xsdk_texture_sampler_state(XsdkSamplerState *state, const XsdkSampler *sampler)
{
	assert(sampler->mag_filter <= XSDK_FILTER_LINEAR && sampler->min_filter <= XSDK_FILTER_LINEAR);
	assert(sampler->mip_filter <= XSDK_FILTER_LINEAR);
	assert(
		sampler->address_u <= XSDK_ADDRESS_MIRROR_ONCE_BORDER && sampler->address_v <= XSDK_ADDRESS_MIRROR_ONCE_BORDER);
	assert(sampler->address_w <= XSDK_ADDRESS_MIRROR_ONCE_BORDER && sampler->border <= XSDK_BORDER_WHITE);
	assert(sampler->lod_bias >= -16.0f && sampler->lod_bias < 16.0f);
	assert(sampler->max_anisotropy <= XSDK_MAX_ANISOTROPY);
	assert(sampler->min_level <= MIP_LEVEL_MASK && sampler->level_count <= MIP_LEVEL_MASK + 1);
	const float steps = sampler->lod_bias * LOD_BIAS_STEPS;
	// The sampler's last level, which xsdk_texture_levels takes the lower of with the texture's.
	const uint32_t last = sampler->level_count ? sampler->level_count - 1 : MIP_LEVEL_MASK;
	const int32_t bias = (int32_t)(steps < 0.0f ? steps - 0.5f : steps + 0.5f);
	const uint32_t clamps =
		sampler->address_u << CLAMP_X_SHIFT | sampler->address_v << CLAMP_Y_SHIFT | sampler->address_w << CLAMP_Z_SHIFT;
	const uint32_t filters = sampler->mag_filter << MAG_FILTER_SHIFT | sampler->min_filter << MIN_FILTER_SHIFT |
		sampler->mip_filter << MIP_FILTER_SHIFT | aniso_filter(sampler->max_anisotropy) << ANISO_FILTER_SHIFT;
	// Between a 3D texture's slices as within them; libxenon sets both linear for its 2D textures (xe.c:1203-1204).
	const uint32_t volume_filters =
		sampler->mag_filter << VOL_MAG_FILTER_SHIFT | sampler->min_filter << VOL_MIN_FILTER_SHIFT;
	const uint32_t levels = ((uint32_t)bias & LOD_BIAS_MASK) << LOD_BIAS_SHIFT |
		sampler->min_level << MIP_MIN_LEVEL_SHIFT | last << MIP_MAX_LEVEL_SHIFT;
	*state = (XsdkSamplerState){ .fetch = { clamps, 0, 0, filters, volume_filters | levels,
									 sampler->border << BORDER_COLOR_SHIFT } };
}

// The fetch constant's dword of levels and bias: the sampler's bias and lowest level, the lower of the texture's last
// level and the sampler's, and the lowest no higher than that.
uint32_t xsdk_texture_levels(uint32_t texture, uint32_t sampler)
{
	const uint32_t texture_last = texture >> MIP_MAX_LEVEL_SHIFT & MIP_LEVEL_MASK;
	const uint32_t sampler_last = sampler >> MIP_MAX_LEVEL_SHIFT & MIP_LEVEL_MASK;
	const uint32_t last = texture_last < sampler_last ? texture_last : sampler_last;
	const uint32_t first = sampler >> MIP_MIN_LEVEL_SHIFT & MIP_LEVEL_MASK;
	const uint32_t fields = MIP_LEVEL_MASK << MIP_MIN_LEVEL_SHIFT | MIP_LEVEL_MASK << MIP_MAX_LEVEL_SHIFT;
	return ((texture | sampler) & ~fields) | (first < last ? first : last) << MIP_MIN_LEVEL_SHIFT |
		last << MIP_MAX_LEVEL_SHIFT;
}
