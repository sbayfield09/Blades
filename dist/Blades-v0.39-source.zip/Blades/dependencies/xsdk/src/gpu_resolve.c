// The resolve below comes from libxenon:drivers/xenos/xe.c, rewritten with Xenia's register names.
// libxenon carries this notice:
//
// Copyright (c) 2009, free60.org
// USB Stack Copyright (c) 2000,2001,2002,2003,2005, Broadcom Corporation
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY free60.org ''AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL free60.org BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE

#include "xsdk/gpu.h"

#include <assert.h>
#include <stdint.h>
#include <string.h>

#include "gpu_private.h"

enum {
	RESOLVE_MAX_DWORDS = 168,
	// A pass over the top 8 rows after a depth clear put every draw right where smaller ones didn't (docs/HARDWARE.md,
	// "The pass after a depth clear, milestone 49").
	HIZ_PASS_ROWS = 8,
	// The size libxenon invalidates for its vertex pool: 12000 bytes and a page (xe.c:33, 1850, 1871).
	RECTANGLE_INVALIDATE_BYTES = 12000 + 0x1000,
	INVALIDATE_VERTEX_SHADER = 1 << 8,
	COHER_RESOLVE_ACTIONS = 0x03000100,
	CACHE_FLUSH = 6,
	// A three-vertex rectangle list, auto-indexed (xenia:src/xenia/gpu/registers.h:311).
	RECTANGLE_LIST_AUTO_INDEX_3 = 8 | 2 << 6 | 3 << 16,
	CLIP_DISABLE = 1 << 16,
	VTX_WINDOW_OFFSET_ENABLE = 1 << 16,
	VTE_XY_Z_ALREADY_TRANSFORMED = 0x300,
	// PA_CL_VTE_CNTL's vport_z_scale_ena and vport_z_offset_ena (xenia:src/xenia/gpu/registers.h:573-574).
	VTE_Z_SCALE_OFFSET = 3 << 4,
	// Depth only, which Xenia takes to skip the pixel shader (xenia:src/xenia/gpu/xenos.h:889-907).
	EDRAM_MODE_DEPTH_ONLY = 5,
	EDRAM_MODE_COPY = 6,
	// RB_DEPTHCONTROL's z_enable, compare never, no write (xenia:src/xenia/gpu/registers.h:799-805).
	DEPTH_TEST_NEVER = 1 << 1,
	// Copy colour into k_8_8_8_8, then clear colour or depth (xe.c:1104-1108).
	COPY_CONTROL_CONVERT = 1 << 20,
	COPY_SAMPLE_SELECT_SHIFT = 4,
	// RB_COPY_CONTROL's source: colour target 0, or depth (xenia:src/xenia/gpu/registers.h:856).
	COPY_SOURCE_COLOR_0 = 0,
	COPY_SOURCE_DEPTH = 4,
	COPY_DEST_INFO_8888 = 6 << 7,
	// RB_COPY_CONTROL's clears (xenia:src/xenia/gpu/registers.h:860-861).
	COPY_CONTROL_COLOR_CLEAR = 1 << 8,
	COPY_CONTROL_DEPTH_CLEAR = 1 << 9,
	// Swaps red and blue (xenia:src/xenia/gpu/shaders/resolve.xesli:768-795).
	COPY_DEST_SWAP = 1 << 24,
	COPY_DEST_INFO_8888_SWAP = COPY_DEST_INFO_8888 | COPY_DEST_SWAP,
	// libxenon's ARGB surfaces also swap each dword's bytes, its BGRA front buffer not (xe.c:968, 1104-1108; xe.h:181).
	COPY_DEST_ENDIAN_8IN32 = 2,
	// Each 16-bit unit's bytes, for the CPU's order of the half floats (xenia:src/xenia/gpu/xenos.h:200-207).
	COPY_DEST_ENDIAN_8IN16 = 1,
	// RB_COPY_DEST_INFO's ColorFormat (xenia:src/xenia/gpu/registers.h:870-883; xenos.h:543-569), and its number
	// format, float for the float formats (xenos.h:216-223), as R6xx's colour buffers take them
	// (radeonhd:src/r600_reg_auto_r6xx.h:1453-1462).
	COPY_DEST_FORMAT_SHIFT = 7,
	COPY_DEST_NUMBER_FLOAT = 7 << 13,
	COPY_DEST_2_10_10_10 = 7 << COPY_DEST_FORMAT_SHIFT | COPY_DEST_ENDIAN_8IN32,
	COPY_DEST_16_16_FLOAT = 31 << COPY_DEST_FORMAT_SHIFT | COPY_DEST_NUMBER_FLOAT | COPY_DEST_ENDIAN_8IN16,
	COPY_DEST_16_16_16_16_FLOAT = 32 << COPY_DEST_FORMAT_SHIFT | COPY_DEST_NUMBER_FLOAT | COPY_DEST_ENDIAN_8IN16,
	COPY_DEST_32_FLOAT = 36 << COPY_DEST_FORMAT_SHIFT | COPY_DEST_NUMBER_FLOAT | COPY_DEST_ENDIAN_8IN32,
	// The depth above the stencil, as an eDRAM sample holds them
	// (xenia:src/xenia/gpu/dxbc_shader_translator_om.cc:978).
	DEPTH_CLEAR_FAR = 0xFFFFFF00,
	DEPTH_CLEAR_SHIFT = 8,
	// The hierarchical buffer holds depth in 2048ths: the top 11 bits of RB_DEPTH_CLEAR's (docs/HARDWARE.md).
	HIZ_CLEAR_SHIFT = 21,
	DEPTH_24_MAX = 0xFFFFFF,
	DEPTH_STENCIL_ALWAYS_WRITE = 0x8777,
	PROGRAM_CNTL_RESOLVE = 2 | 1 << 16,
	VERTEX_FETCH_TYPE = 3,
	VERTEX_FETCH_SIZE_6_8IN32 = 1 << 28 | 6 << 2 | 2,
	// libxenon loads its 12-dword shader as 15, with three zeros after it.
	SHADER_PADDING_DWORDS = 3,
	// Xenia sizes a resolve's destination by its tiled layout (xenia:src/xenia/gpu/draw_util.cc:1055-1062).
	TILE_ROWS = 32,
	// The clear's channels as a target holds them: unorm steps, and 16-bit fixed point's 32767 steps to 32
	// (xenia:src/xenia/gpu/shaders/pixel_formats.xesli:118-121, 368-372).
	UNORM_8 = 255,
	UNORM_10 = 1023,
	UNORM_2 = 3,
	FIXED_16_STEPS = 32767,
	FIXED_16_RANGE = 32,
	// The largest half float and 7e3 float (xenia:src/xenia/gpu/render_target_cache.cc:281-285; xenos.h:303).
	HALF_MAX_BITS = 0x7BFF,
	FLOAT_7E3_MAX_BITS = 0x3FF,
	WINDOW_Y_SHIFT = 16,
};

// The pixels of the target a resolve copies and clears, into the same texels (xenia:src/xenia/gpu/xenos.h:941-942).
typedef struct {
	uint32_t x;
	uint32_t y;
	uint32_t width;
	uint32_t height;
} Area;

// Generated by tools/gen_resolve_vs.py.
static const uint32_t resolve_vertex_shader[] = {
	0x10011002,
	0x00001200,
	0xC4000000,
	0x00000000,
	0x1003C200,
	0x22000000,
	0x00080000,
	0x00253B48,
	0x00000002,
	0xC80F803E,
	0x00000000,
	0xC2000000,
};

static uint32_t depth_clear = DEPTH_CLEAR_FAR;
static uint32_t clears = COPY_CONTROL_COLOR_CLEAR | COPY_CONTROL_DEPTH_CLEAR;

// RB_COLOR_CLEAR wants the packed colour, red low (xenia:src/xenia/gpu/shaders/pixel_formats.xesli:113-116).
static uint32_t packed_8888(uint32_t argb)
{
	return (argb & 0xFF00FF00) | (argb >> 16 & 0xFF) | (argb & 0xFF) << 16;
}

static uint32_t float_bits(float value)
{
	uint32_t bits;
	memcpy(&bits, &value, sizeof bits);
	return bits;
}

static uint32_t unorm(float value, uint32_t steps)
{
	const float clamped = value > 0.0f ? (value < 1.0f ? value : 1.0f) : 0.0f;
	return (uint32_t)(clamped * (float)steps + 0.5f);
}

// A signed 16-bit unit of 32767 steps to 32, rounded to the nearest.
static uint32_t fixed_16(float value)
{
	const float steps = value * (float)FIXED_16_STEPS / FIXED_16_RANGE;
	const float limit = FIXED_16_STEPS;
	const float clamped = steps >= -limit ? (steps <= limit ? steps : limit) : -limit;
	return (uint32_t)(int32_t)(clamped + (clamped < 0.0f ? -0.5f : 0.5f)) & 0xFFFF;
}

// An IEEE half, rounded to the nearest, past the largest the largest. Below 2^-14 it has no implicit bit, so the
// mantissa shifts down by the shortfall.
static uint32_t half_bits(float value)
{
	const uint32_t bits = float_bits(value);
	const uint32_t sign = bits >> 16 & 0x8000;
	const uint32_t magnitude = bits & 0x7FFFFFFF;
	if (magnitude >= 0x477FF000)
		return sign | HALF_MAX_BITS;
	if (magnitude >= 0x38800000)
		return sign | (magnitude - 0x38000000 + 0x1000) >> 13;
	const uint32_t shift = 126 - (magnitude >> 23);
	const uint32_t mantissa = (magnitude & 0x7FFFFF) | 0x800000;
	return sign | (shift > 24 ? 0 : (mantissa + (1u << (shift - 1))) >> shift);
}

// 7e3: three bits of exponent above seven of mantissa, a float's exponent less 124, and under 0.25 no implicit bit
// (xenia:src/xenia/gpu/shaders/pixel_formats.xesli:324-345, the reverse).
static uint32_t float_7e3_bits(float value)
{
	if (!(value > 0.0f))
		return 0;
	if (value >= 31.875f)
		return FLOAT_7E3_MAX_BITS;
	if (value < 0.25f)
		return (uint32_t)(value * 512.0f + 0.5f);
	return (float_bits(value) - (124u << 23) + (1u << 15)) >> 16;
}

// RB_COLOR_CLEAR and RB_COLOR_CLEAR_LO as the target's samples hold the clear, red in the low bits
// (xenia:src/xenia/gpu/shaders/pixel_formats.xesli:113-121); a 64-bit sample's red and green from RB_COLOR_CLEAR_LO
// and its blue and alpha from RB_COLOR_CLEAR on the console, the other way round from Xenia
// (xenia:src/xenia/gpu/draw_util.h:565-567; docs/HARDWARE.md, "Float, 10-bit and 64-bit targets and four at once").
static void clear_words(uint32_t format, const float rgba[4], uint32_t words[2])
{
	switch (format) {
	case XSDK_TARGET_2_10_10_10:
		words[0] = unorm(rgba[0], UNORM_10) | unorm(rgba[1], UNORM_10) << 10 | unorm(rgba[2], UNORM_10) << 20 |
			unorm(rgba[3], UNORM_2) << 30;
		words[1] = words[0];
		break;
	case XSDK_TARGET_2_10_10_10_FLOAT:
		words[0] = float_7e3_bits(rgba[0]) | float_7e3_bits(rgba[1]) << 10 | float_7e3_bits(rgba[2]) << 20 |
			unorm(rgba[3], UNORM_2) << 30;
		words[1] = words[0];
		break;
	case XSDK_TARGET_16_16_16_16:
		words[0] = fixed_16(rgba[2]) | fixed_16(rgba[3]) << 16;
		words[1] = fixed_16(rgba[0]) | fixed_16(rgba[1]) << 16;
		break;
	case XSDK_TARGET_16_16_FLOAT:
		words[0] = half_bits(rgba[0]) | half_bits(rgba[1]) << 16;
		words[1] = words[0];
		break;
	case XSDK_TARGET_16_16_16_16_FLOAT:
		words[0] = half_bits(rgba[2]) | half_bits(rgba[3]) << 16;
		words[1] = half_bits(rgba[0]) | half_bits(rgba[1]) << 16;
		break;
	case XSDK_TARGET_32_FLOAT:
		words[0] = float_bits(rgba[0]);
		words[1] = words[0];
		break;
	default:
		words[0] = unorm(rgba[0], UNORM_8) | unorm(rgba[1], UNORM_8) << 8 | unorm(rgba[2], UNORM_8) << 16 |
			unorm(rgba[3], UNORM_8) << 24;
		words[1] = words[0];
		break;
	}
}

static void put_shader(GpuPackets *packets)
{
	const uint32_t dword_count = sizeof resolve_vertex_shader / 4 + SHADER_PADDING_DWORDS;
	gpu_put_type3(packets, PM4_IM_LOAD_IMMEDIATE, 2 + dword_count);
	gpu_put(packets, SHADER_TYPE_VERTEX);
	gpu_put(packets, dword_count);
	for (uint32_t i = 0; i < dword_count; i++)
		gpu_put(packets, i < sizeof resolve_vertex_shader / 4 ? resolve_vertex_shader[i] : 0);
}

// Vertex fetch constant 0 at a rectangle's three vertices.
static void put_rectangle_fetch(GpuPackets *packets, uint32_t vertices)
{
	const uint32_t fetch[] = { vertices | VERTEX_FETCH_TYPE, VERTEX_FETCH_SIZE_6_8IN32, 0, 0, 0, 0 };
	const uint32_t flush_fetch[] = { 0, 0, 0 };
	gpu_put_registers(packets, SHADER_CONSTANT_FETCH_00_0, fetch, 6);
	gpu_put_registers(packets, SHADER_CONSTANT_FLUSH_FETCH_0, flush_fetch, 3);
}

#ifdef XSDK_HIZ_PASS_PROBE
// Milestone 49's probe (tests/probe_hiz_pass.c) of cheaper ways to put the buffer right: the pass, if on, over the
// rectangle if it has a width, or the event in its place if not 0. Built with 0, the pass is left out.
static bool probe_on = XSDK_HIZ_PASS_PROBE;
static uint32_t probe_event;
static uint32_t probe_rect[4];

void xsdk_probe_hiz_pass(bool on, uint32_t event, const uint32_t rect[4])
{
	probe_on = on;
	probe_event = event;
	memcpy(probe_rect, rect, sizeof probe_rect);
}

// The probe's event, or its rectangle for the pass; whether the pass follows.
static bool put_probe_case(GpuPackets *packets)
{
	if (probe_on && probe_event) {
		gpu_put_type3(packets, PM4_EVENT_WRITE, 1);
		gpu_put(packets, probe_event);
		gpu_put_register(packets, WAIT_UNTIL, WAIT_3D_IDLE_CLEAN);
	}
	if (!probe_on || probe_event)
		return false;
	if (probe_rect[2])
		put_rectangle_fetch(packets, xsdk_gpu_rectangle(probe_rect[0], probe_rect[1], probe_rect[2], probe_rect[3]));
	return true;
}
#endif

// After a clear, a draw's first block may test the buffer's old values until a draw over the top rows tests them
// (docs/HARDWARE.md, "The pass after a depth clear, milestone 49").
static void put_hiz_test(GpuPackets *packets, uint32_t hiz_clear, uint32_t vertices)
{
	put_rectangle_fetch(packets, vertices);
#ifdef XSDK_HIZ_PASS_PROBE
	if (!put_probe_case(packets))
		return;
#endif
	// Rejected whole it costs less: at z 0 testing greater-than over a clear above 0, at the rectangle's z of 1 over 0.
	const uint32_t z_zero[] = { 0, 0 };
	const bool at_zero = hiz_clear != 0;
	// In eDRAM's no-operation mode this hung the GPU (docs/HARDWARE.md).
	gpu_put_register(packets, RB_MODECONTROL, EDRAM_MODE_DEPTH_ONLY);
	gpu_put_register(packets, RB_DEPTHCONTROL, DEPTH_TEST_NEVER);
	gpu_put_register(packets, RB_HIZCONTROL, HIZ_ENABLE | (at_zero ? HIZ_GREATER : 0));
	if (at_zero) {
		gpu_put_register(packets, PA_CL_VTE_CNTL, VTE_XY_Z_ALREADY_TRANSFORMED | VTE_Z_SCALE_OFFSET);
		gpu_put_registers(packets, PA_CL_VPORT_ZSCALE, z_zero, 2);
	}
	gpu_put_type3(packets, PM4_DRAW_INDX_2, 1);
	gpu_put(packets, RECTANGLE_LIST_AUTO_INDEX_3);
	gpu_put_register(packets, WAIT_UNTIL, WAIT_3D_IDLE_CLEAN);
}

// The window scissor at the area, as a resolve copies only what it lets through (xenia:src/xenia/gpu/xenos.h:969-976).
static void put_window(GpuPackets *packets, const Area *area)
{
	const uint32_t right = area->x + area->width;
	const uint32_t bottom = area->y + area->height;
	const uint32_t window[] = { 0, area->x | area->y << WINDOW_Y_SHIFT, right | bottom << WINDOW_Y_SHIFT };
	gpu_put_registers(packets, PA_SC_WINDOW_OFFSET, window, 3);
}

// Xe_ResolveInto, less its scratch write, with the layout Xe_SetRenderTarget gives the target (xe.c:998-1165), its
// rectangle and scissor at the area.
static void resolve(uint32_t source, uint32_t target, uint32_t address, const Area *area, uint32_t width,
	uint32_t height, uint32_t pitch, uint32_t dest_info, uint32_t dest_bytes, const uint32_t clear[2])
{
	assert(width % 32 == 0);
	const uint32_t vertices = xsdk_gpu_rectangle(area->x, area->y, area->width, area->height);
	const uint32_t viewport[] = { 0x44000000, 0x44000000, 0xC3B40000, 0x43B40000, 0x3F800000, 0 };
	// A depth resolve can't clear colour (xenia:src/xenia/gpu/xenos.h:925-931).
	const uint32_t copy_clears = source == COPY_SOURCE_DEPTH ? clears & COPY_CONTROL_DEPTH_CLEAR : clears;
	const uint32_t select = xsdk_gpu_copy_sample_select(source == COPY_SOURCE_DEPTH);
	const uint32_t copy[] = { COPY_CONTROL_CONVERT | select << COPY_SAMPLE_SELECT_SHIFT | copy_clears | source, address,
		pitch | height << 16, dest_info };
	const uint32_t program[] = { PROGRAM_CNTL_RESOLVE, 0 };
	const uint32_t indices[] = { 0xFFFF, 0, 0 };
	const uint32_t clip[] = { CLIP_DISABLE, VTX_WINDOW_OFFSET_ENABLE, VTE_XY_Z_ALREADY_TRANSFORMED };
	const uint32_t depth_clears[] = { depth_clear >> HIZ_CLEAR_SHIFT, depth_clear };
	const bool clears_depth = copy_clears & COPY_CONTROL_DEPTH_CLEAR;
	// The hierarchical buffer bounds the surface's depth only after a clear of all of it, and only where it fits.
	const bool whole = !area->x && !area->y && area->width == width && area->height == height;
	const bool clears_hiz = clears_depth && whole && xsdk_gpu_hiz_fits(width, height);
	// Written before the resolve's invalidate runs, which takes the rectangles' whole page (src/gpu_setup.c).
	const uint32_t pass = clears_hiz ? xsdk_gpu_rectangle(0, 0, width, HIZ_PASS_ROWS) : 0;
	uint32_t dwords[RESOLVE_MAX_DWORDS];
	GpuPackets packets = { .dwords = dwords, .count = 0, .capacity = RESOLVE_MAX_DWORDS };
	put_window(&packets, area);
	xsdk_gpu_put_coherency(&packets, COHER_VERTEX_CACHE, vertices, RECTANGLE_INVALIDATE_BYTES);
	xsdk_gpu_put_surface(&packets, width, height, target);
	gpu_put_register(&packets, RB_COLOR_MASK, 0xF);
	gpu_put_registers(&packets, PA_CL_VPORT_XSCALE, viewport, 6);
	gpu_put_registers(&packets, RB_COPY_CONTROL, copy, 4);
	gpu_put_registers(&packets, RB_HIZ_CLEAR, depth_clears, 2);
	gpu_put_register(&packets, RB_COLOR_CLEAR, clear[0]);
	gpu_put_register(&packets, RB_COLOR_CLEAR_LO, clear[1]);
	gpu_put_register(&packets, RB_MODECONTROL, EDRAM_MODE_COPY);
	gpu_put_register(&packets, RB_MODECONTROL, EDRAM_MODE_COPY);
	gpu_put_register(&packets, RB_DEPTHCONTROL, DEPTH_STENCIL_ALWAYS_WRITE);
	// Alpha to mask off, as the step 4 probe's resolves ran (tests/probe_msaa.c, draw_alphas).
	gpu_put_register(&packets, RB_COLORCONTROL, COLOR_CONTROL);
	gpu_put_register(&packets, WAIT_UNTIL, WAIT_3D_IDLE_CLEAN);
	gpu_put_type3(&packets, PM4_INVALIDATE_STATE, 1);
	gpu_put(&packets, INVALIDATE_VERTEX_SHADER);
	put_shader(&packets);
	gpu_put_registers(&packets, SQ_PROGRAM_CNTL, program, 2);
	xsdk_gpu_forget_shaders();
	// Writing the buffer clears it to RB_HIZ_CLEAR with depth; testing it would reject the copy (docs/HARDWARE.md).
	gpu_put_register(&packets, RB_HIZCONTROL, clears_hiz ? HIZ_WRITE_ENABLE : 0);
	gpu_put_registers(&packets, VGT_MAX_VTX_INDX, indices, 3);
	gpu_put_registers(&packets, PA_CL_CLIP_CNTL, clip, 3);
	gpu_put_register(&packets, COHER_DEST_BASE_7, 0);
	put_rectangle_fetch(&packets, vertices);
	gpu_put_type3(&packets, PM4_DRAW_INDX_2, 1);
	gpu_put(&packets, RECTANGLE_LIST_AUTO_INDEX_3);
	gpu_put_type3(&packets, PM4_EVENT_WRITE, 1);
	gpu_put(&packets, CACHE_FLUSH);
	gpu_put_register(&packets, COHER_DEST_BASE_1, 0);
	xsdk_gpu_put_coherency(&packets, COHER_RESOLVE_ACTIONS, address, dest_bytes);
	gpu_put_register(&packets, RB_COPY_CONTROL, 0);
	gpu_put_register(&packets, RB_COPY_DEST_INFO, 0);
	// Xe_Sync's wait for idle (xe.c:1223-1226, 1278-1282).
	gpu_put_register(&packets, WAIT_UNTIL, WAIT_3D_IDLE_CLEAN);
	if (clears_hiz)
		put_hiz_test(&packets, depth_clears[0], pass);
	xsdk_gpu_write(&packets);
	xsdk_gpu_undo_target();
	if (clears_hiz)
		xsdk_gpu_hiz_cleared(width, height, depth_clear);
	else if (clears_depth)
		xsdk_gpu_hiz_drop();
}

static Area whole_area(uint32_t width, uint32_t height)
{
	return (Area){ .x = 0, .y = 0, .width = width, .height = height };
}

uint32_t xsdk_gpu_resolve_bytes(uint32_t width, uint32_t height)
{
	return width * ((height + TILE_ROWS - 1) & ~(TILE_ROWS - 1)) * 4;
}

void xsdk_gpu_set_depth_clear(float depth, uint8_t stencil)
{
	assert(depth >= 0.0f && depth <= 1.0f);
	// In double: in float, 1.0 * 0xFFFFFF + 0.5 rounds up to 0x1000000, and the shift loses it to 0.
	depth_clear = (uint32_t)(depth * (double)DEPTH_24_MAX + 0.5) << DEPTH_CLEAR_SHIFT | stencil;
}

void xsdk_gpu_resolve(uint32_t address, uint32_t width, uint32_t height, uint32_t clear_argb)
{
	const Area area = whole_area(width, height);
	const uint32_t clear[2] = { packed_8888(clear_argb), packed_8888(clear_argb) };
	resolve(COPY_SOURCE_COLOR_0, 0, address, &area, width, height, width, COPY_DEST_INFO_8888_SWAP,
		xsdk_gpu_resolve_bytes(width, height), clear);
}

void xsdk_gpu_set_resolve_clears(bool color, bool depth_stencil)
{
	clears = (color ? COPY_CONTROL_COLOR_CLEAR : 0) | (depth_stencil ? COPY_CONTROL_DEPTH_CLEAR : 0);
}

// eDRAM packs red low, so the byte-order formats copy as they are, or with red and blue swapped.
static uint32_t texture_dest_info(uint32_t format)
{
	switch (format) {
	case XSDK_FORMAT_A8R8G8B8:
		return COPY_DEST_INFO_8888_SWAP | COPY_DEST_ENDIAN_8IN32;
	case XSDK_FORMAT_B8G8R8A8:
		return COPY_DEST_INFO_8888_SWAP;
	default:
		assert(format == XSDK_FORMAT_R8G8B8A8);
		return COPY_DEST_INFO_8888;
	}
}

void xsdk_gpu_resolve_texture(const XsdkTexture *texture, uint32_t clear_argb)
{
	xsdk_gpu_resolve_texture_rect(texture, 0, 0, texture->width, texture->height, clear_argb);
}

// On the grid a resolve copies by, or reaching the edge, past which it writes only the texture's padding.
static bool on_grid(uint32_t first, uint32_t size, uint32_t edge)
{
	const uint32_t end = first + size;
	return size && end <= edge && first % XSDK_RESOLVE_ALIGNMENT == 0 &&
		(end % XSDK_RESOLVE_ALIGNMENT == 0 || end == edge);
}

void xsdk_gpu_resolve_texture_rect(
	const XsdkTexture *texture, uint32_t x, uint32_t y, uint32_t width, uint32_t height, uint32_t clear_argb)
{
	// Xenia lays out a resolve's destination only as tiled (xenia:src/xenia/gpu/draw_util.cc:1035-1061).
	assert(texture->tiled);
	// A resolve writes from the corner, so the base can't sit inside the packed tail.
	assert(!xsdk_texture_base_in_tail(texture));
	assert(xsdk_gpu_color_target_format(0) == XSDK_TARGET_8_8_8_8);
	assert(on_grid(x, width, texture->width) && on_grid(y, height, texture->height));
	// The pitch is whole tiles of 32 texels, as a resolve's width must be; a rectangle at the edge reaches it.
	const uint32_t right = x + width == texture->width ? texture->pitch : x + width;
	const Area area = { .x = x, .y = y, .width = right - x, .height = height };
	const uint32_t clear[2] = { packed_8888(clear_argb), packed_8888(clear_argb) };
	resolve(COPY_SOURCE_COLOR_0, 0, texture->address, &area, texture->pitch, texture->height, texture->pitch,
		texture_dest_info(texture->format), texture->size_bytes, clear);
}

// The texture format each target format resolves into, converted on the way as Xenia models it: unpacked to floats,
// then packed as the destination's format (xenia:src/xenia/gpu/shaders/resolve.xesli:249-412;
// pixel_formats.xesli:196-281).
static uint32_t target_dest_info(uint32_t target_format, uint32_t texture_format)
{
	switch (target_format) {
	case XSDK_TARGET_8_8_8_8:
		return texture_dest_info(texture_format);
	case XSDK_TARGET_2_10_10_10:
		assert(texture_format == XSDK_FORMAT_A2B10G10R10);
		return COPY_DEST_2_10_10_10;
	case XSDK_TARGET_16_16_FLOAT:
		assert(texture_format == XSDK_FORMAT_R16G16F);
		return COPY_DEST_16_16_FLOAT;
	case XSDK_TARGET_32_FLOAT:
		assert(texture_format == XSDK_FORMAT_R32F);
		return COPY_DEST_32_FLOAT;
	default:
		assert(texture_format == XSDK_FORMAT_R16G16B16A16F);
		return COPY_DEST_16_16_16_16_FLOAT;
	}
}

void xsdk_gpu_resolve_target(uint32_t target, const XsdkTexture *texture, const float clear_rgba[4])
{
	assert(texture->tiled);
	assert(!xsdk_texture_base_in_tail(texture));
	const uint32_t format = xsdk_gpu_color_target_format(target);
	uint32_t clear[2];
	clear_words(format, clear_rgba, clear);
	const Area area = whole_area(texture->pitch, texture->height);
	resolve(COPY_SOURCE_COLOR_0, target, texture->address, &area, texture->pitch, texture->height, texture->pitch,
		target_dest_info(format, texture->format), texture->size_bytes, clear);
}

// Direct3D 9 copies depth as k_8_8_8_8 (xenia:src/xenia/gpu/draw_util.cc:968-972): the eDRAM sample's word, depth
// above stencil, swapped into the CPU's order as XSDK_FORMAT_D24S8 reads it.
enum { DEPTH_DEST_INFO = COPY_DEST_INFO_8888 | COPY_DEST_ENDIAN_8IN32 };

void xsdk_gpu_resolve_depth_texture(const XsdkTexture *texture)
{
	assert(texture->tiled && texture->format == XSDK_FORMAT_D24S8);
	assert(!xsdk_texture_base_in_tail(texture));
	const Area area = whole_area(texture->pitch, texture->height);
	const uint32_t clear[2] = { 0, 0 };
	resolve(COPY_SOURCE_DEPTH, 0, texture->address, &area, texture->pitch, texture->height, texture->pitch,
		DEPTH_DEST_INFO, texture->size_bytes, clear);
}

uint32_t xsdk_gpu_depth_clear(void)
{
	return depth_clear;
}

// The band's rows of a tiled texture start top * pitch texels in, as a tiled texture's rows go in steps of 32
// (docs/HARDWARE.md, "Tiling's registers and packets, milestone 44 step 1"); the copy is the band's surface whole.
void xsdk_gpu_resolve_band(uint32_t target, const XsdkTexture *texture, const float clear_rgba[4], uint32_t top,
	uint32_t rows, bool clear_color, bool clear_depth)
{
	assert(texture->tiled && top % XSDK_TILE_ROWS == 0 && top + rows <= texture->height);
	const bool depth = target == XSDK_TILE_DEPTH;
	assert(!depth || texture->format == XSDK_FORMAT_D24S8);
	uint32_t clear[2] = { 0, 0 };
	if (!depth)
		clear_words(xsdk_gpu_color_target_format(target), clear_rgba, clear);
	const uint32_t dest_info =
		depth ? DEPTH_DEST_INFO : target_dest_info(xsdk_gpu_color_target_format(target), texture->format);
	const uint32_t texel_log2 = texture->format == XSDK_FORMAT_R16G16B16A16F ? 3 : 2;
	const uint32_t moved = xsdk_tiled_2d(0, top, texture->pitch, texel_log2);
	const Area area = whole_area(texture->pitch, rows);
	const uint32_t kept = clears;
	clears = (clear_color ? COPY_CONTROL_COLOR_CLEAR : 0) | (clear_depth ? COPY_CONTROL_DEPTH_CLEAR : 0);
	resolve(depth ? COPY_SOURCE_DEPTH : COPY_SOURCE_COLOR_0, depth ? 0 : target, texture->address + moved, &area,
		texture->pitch, rows, texture->pitch, dest_info,
		xsdk_gpu_resolve_bytes(texture->pitch, rows) << (texel_log2 - 2), clear);
	clears = kept;
}
