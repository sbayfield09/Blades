#include "path_private.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/time.h>
#include <unistd.h>
#include <utime.h>

#include "file_private.h"
#include "time_private.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"

// POSIX paths, with '/' and relative to the current directory, become kernel paths such as "game:\dir\file".

static pthread_mutex_t current_directory_lock = PTHREAD_MUTEX_INITIALIZER;
// game: is the folder the title was launched from (docs/HARDWARE.md).
static char current_directory[XSDK_PATH_BYTES] = "game:\\";

static bool is_separator(char c)
{
	return c == '/' || c == '\\';
}

typedef struct {
	const char *name;
	const char *device;
} DriveName;

// The drives xsdk names, each its device's root, which opens as a folder only with its closing backslash
// (docs/HARDWARE.md, "Drives, time zones and Xbox Home, milestone 54"). The kernel knows the rest, such as game:.
static const DriveName drive_names[] = {
	{ "hdd", "\\Device\\Harddisk0\\Partition1\\" },
	{ "usb", "\\Device\\Mass0\\" },
	{ "usb0", "\\Device\\Mass0\\" },
	{ "usb1", "\\Device\\Mass1\\" },
	{ "usb2", "\\Device\\Mass2\\" },
	{ "mu", "\\Device\\Mu0\\" },
	{ "mu0", "\\Device\\Mu0\\" },
	{ "mu1", "\\Device\\Mu1\\" },
	{ "dvd", "\\Device\\Cdrom0\\" },
};

enum { DRIVE_NAMES = sizeof(drive_names) / sizeof(drive_names[0]) };

// The device root a drive's name stands for, any case, as the kernel's drives take any; NULL for the kernel's own.
static const char *drive_device(const char *name, size_t name_bytes)
{
	for (size_t i = 0; i < DRIVE_NAMES; i++) {
		if (strlen(drive_names[i].name) == name_bytes && strncasecmp(name, drive_names[i].name, name_bytes) == 0)
			return drive_names[i].device;
	}
	return NULL;
}

// The bytes up to and including the root's closing separator: a named device's root, "game:\" or "\".
static size_t root_bytes(const char *resolved)
{
	for (size_t i = 0; i < DRIVE_NAMES; i++) {
		const size_t device_bytes = strlen(drive_names[i].device);
		if (strncasecmp(resolved, drive_names[i].device, device_bytes) == 0)
			return device_bytes;
	}
	return (size_t)(strchr(resolved, '\\') - resolved) + 1;
}

// Starts resolved at a drive: "game:" becomes "game:\", and "usb:" its device's root.
static bool start_at_drive(char resolved[XSDK_PATH_BYTES], const char *drive, size_t drive_bytes)
{
	const char *const device = drive_device(drive, drive_bytes - 1);
	if (device) {
		strcpy(resolved, device);
		return true;
	}
	if (drive_bytes + 2 > XSDK_PATH_BYTES)
		return false;
	memcpy(resolved, drive, drive_bytes);
	strcpy(resolved + drive_bytes, "\\");
	return true;
}

// Starts resolved at the path's own root, or at base for a relative path, and returns the rest of the path.
static const char *start_path(const char *path, const char *base, char resolved[XSDK_PATH_BYTES])
{
	const char *first_end = path;
	while (*first_end && !is_separator(*first_end))
		first_end++;
	const char *colon = memchr(path, ':', (size_t)(first_end - path));
	if (colon)
		return start_at_drive(resolved, path, (size_t)(colon - path) + 1) ? colon + 1 : NULL;
	if (is_separator(path[0])) {
		strcpy(resolved, "\\");
		return path;
	}
	strcpy(resolved, base);
	return path;
}

// Appends the path's names to resolved, dropping "." and stepping back for "..".
static int append_names(char resolved[XSDK_PATH_BYTES], const char *path)
{
	size_t root = root_bytes(resolved);
	size_t length = strlen(resolved);
	while (*path) {
		const char *end = path;
		while (*end && !is_separator(*end))
			end++;
		const size_t name_bytes = (size_t)(end - path);
		if (name_bytes > 0 && path[name_bytes - 1] == ':') {
			// A drive starts over, as in "game:\/game:\file", std::filesystem's absolute() of "game:\file".
			if (!start_at_drive(resolved, path, name_bytes))
				return ENAMETOOLONG;
			root = root_bytes(resolved);
			length = root;
		} else if (name_bytes == 2 && path[0] == '.' && path[1] == '.') {
			while (length > root && resolved[length - 1] != '\\')
				length--;
			if (length > root)
				length--;
			resolved[length] = '\0';
		} else if (name_bytes > 0 && !(name_bytes == 1 && path[0] == '.')) {
			const size_t separator_bytes = length > root ? 1 : 0;
			if (length + separator_bytes + name_bytes >= XSDK_PATH_BYTES)
				return ENAMETOOLONG;
			if (separator_bytes)
				resolved[length++] = '\\';
			memcpy(resolved + length, path, name_bytes);
			length += name_bytes;
			resolved[length] = '\0';
		}
		path = *end ? end + 1 : end;
	}
	return 0;
}

int xsdk_path_resolve(int dir_fd, const char *path, char resolved[XSDK_PATH_BYTES])
{
	if (!path[0])
		return ENOENT;
	char base[XSDK_PATH_BYTES];
	if (dir_fd == AT_FDCWD) {
		(void)pthread_mutex_lock(&current_directory_lock);
		memcpy(base, current_directory, sizeof(base));
		(void)pthread_mutex_unlock(&current_directory_lock);
	} else {
		const int error = xsdk_file_directory_path(dir_fd, base);
		if (error)
			return error;
	}
	const char *rest = start_path(path, base, resolved);
	if (!rest)
		return ENAMETOOLONG;
	return append_names(resolved, rest);
}

void xsdk_path_attributes(const char *resolved, ANSI_STRING *name, OBJECT_ATTRIBUTES *attributes)
{
	const size_t length = strlen(resolved);
	*name = (ANSI_STRING){ .length = (uint16_t)length, .maximum_length = (uint16_t)(length + 1), .pointer = resolved };
	// Drive-letter paths look the drive up among the DOS devices (xenia:src/xenia/kernel/xboxkrnl/xboxkrnl_io.cc:129).
	*attributes = (OBJECT_ATTRIBUTES){ .root_directory = resolved[0] == '\\' ? 0 : OB_DOS_DEVICES, .name = name };
}

static int fail_with_status(const char *call, const char *resolved, NTSTATUS status)
{
	xsdk_log_write("%s(%s) failed: 0x%08X", call, resolved, (unsigned)status);
	errno = xsdk_file_errno(status);
	return -1;
}

static int resolve_or_fail(int dir_fd, const char *path, char resolved[XSDK_PATH_BYTES])
{
	const int error = xsdk_path_resolve(dir_fd, path, resolved);
	if (error) {
		errno = error;
		return -1;
	}
	return 0;
}

static int query_resolved(const char *resolved, FILE_NETWORK_OPEN_INFORMATION *information)
{
	ANSI_STRING name;
	OBJECT_ATTRIBUTES attributes;
	xsdk_path_attributes(resolved, &name, &attributes);
	const NTSTATUS status = NtQueryFullAttributesFile(&attributes, information);
	if (!NT_SUCCESS(status)) {
		errno = xsdk_file_errno(status);
		// A missing file is the usual answer to a stat, not an error.
		if (errno != ENOENT)
			xsdk_log_write("stat: NtQueryFullAttributesFile(%s) failed: 0x%08X", resolved, (unsigned)status);
		return -1;
	}
	return 0;
}

static int stat_resolved(const char *resolved, struct stat *info)
{
	FILE_NETWORK_OPEN_INFORMATION information;
	if (query_resolved(resolved, &information) != 0)
		return -1;
	xsdk_file_stat(&information, resolved, info);
	return 0;
}

static NTSTATUS open_resolved(
	const char *resolved, uint32_t access, uint32_t disposition, uint32_t options, HANDLE *handle)
{
	ANSI_STRING name;
	OBJECT_ATTRIBUTES attributes;
	xsdk_path_attributes(resolved, &name, &attributes);
	IO_STATUS_BLOCK io_status;
	return NtCreateFile(handle, access | SYNCHRONIZE, &attributes, &io_status, NULL, FILE_ATTRIBUTE_NORMAL, 0,
		disposition, options | FILE_SYNCHRONOUS_IO_NONALERT);
}

int stat(const char *path, struct stat *info)
{
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0)
		return -1;
	return stat_resolved(resolved, info);
}

int chdir(const char *path)
{
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0)
		return -1;
	struct stat info;
	if (stat_resolved(resolved, &info) != 0)
		return -1;
	if (!S_ISDIR(info.st_mode)) {
		errno = ENOTDIR;
		return -1;
	}
	(void)pthread_mutex_lock(&current_directory_lock);
	memcpy(current_directory, resolved, sizeof(current_directory));
	(void)pthread_mutex_unlock(&current_directory_lock);
	return 0;
}

// A kernel path as getcwd and realpath give it, with '/' between the names.
static void copy_with_slashes(char *out, const char *resolved, size_t length)
{
	for (size_t i = 0; i <= length; i++)
		out[i] = resolved[i] == '\\' ? '/' : resolved[i];
}

// With no buffer, allocates one, as glibc does; libstdc++ asks for that first.
char *getcwd(char *buffer, size_t size_bytes)
{
	char path[XSDK_PATH_BYTES];
	(void)pthread_mutex_lock(&current_directory_lock);
	memcpy(path, current_directory, sizeof(path));
	(void)pthread_mutex_unlock(&current_directory_lock);

	const size_t length = strlen(path);
	if (!buffer && size_bytes == 0)
		size_bytes = length + 1;
	if (size_bytes <= length) {
		errno = size_bytes == 0 ? EINVAL : ERANGE;
		return NULL;
	}
	char *const result = buffer ? buffer : malloc(size_bytes);
	if (!result) {
		errno = ENOMEM;
		return NULL;
	}
	copy_with_slashes(result, path, length);
	return result;
}

// With no links, the path resolved, "." and ".." taken out, is the real one once it's there. A buffer given holds
// PATH_MAX, 1024 bytes in newlib's <sys/syslimits.h>, more than any kernel path.
char *realpath(const char *path, char *buffer)
{
	if (!path) {
		errno = EINVAL;
		return NULL;
	}
	char resolved[XSDK_PATH_BYTES];
	struct stat info;
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0 || stat_resolved(resolved, &info) != 0)
		return NULL;
	const size_t length = strlen(resolved);
	char *const result = buffer ? buffer : malloc(length + 1);
	if (!result) {
		errno = ENOMEM;
		return NULL;
	}
	copy_with_slashes(result, resolved, length);
	return result;
}

// Permissions can't be stored (xsdk_file_stat), so mode is unused.
int mkdir(const char *path, mode_t mode)
{
	(void)mode;
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0)
		return -1;
	HANDLE handle;
	const NTSTATUS status = open_resolved(resolved, GENERIC_READ, FILE_CREATE, FILE_DIRECTORY_FILE, &handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("mkdir: NtCreateFile", resolved, status);
	const NTSTATUS close_status = NtClose(handle);
	if (!NT_SUCCESS(close_status))
		return fail_with_status("mkdir: NtClose", resolved, close_status);
	return 0;
}

// newlib's remove() calls unlink() for directories too, so without AT_REMOVEDIR either kind goes.
int unlinkat(int dir_fd, const char *path, int flags)
{
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(dir_fd, path, resolved) != 0)
		return -1;
	const uint32_t options = flags & AT_REMOVEDIR ? FILE_DIRECTORY_FILE : 0;
	HANDLE handle;
	NTSTATUS status = open_resolved(resolved, DELETE, FILE_OPEN, options, &handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("unlink: NtCreateFile", resolved, status);
	// Deleted at the last close; Xenia ignores this (xenia:src/xenia/kernel/xboxkrnl/xboxkrnl_io_info.cc:203-210).
	const FILE_DISPOSITION_INFORMATION disposition = { .delete_file = 1 };
	IO_STATUS_BLOCK io_status;
	status =
		NtSetInformationFile(handle, &io_status, &disposition, sizeof(disposition), FILE_DISPOSITION_INFORMATION_CLASS);
	const NTSTATUS close_status = NtClose(handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("unlink: NtSetInformationFile", resolved, status);
	if (!NT_SUCCESS(close_status))
		return fail_with_status("unlink: NtClose", resolved, close_status);
	return 0;
}

int unlink(const char *path)
{
	return unlinkat(AT_FDCWD, path, 0);
}

int rmdir(const char *path)
{
	return unlinkat(AT_FDCWD, path, AT_REMOVEDIR);
}

// Permissions are stat's (xsdk_file_stat): anything may be read, written unless read-only, and only a folder searched.
int access(const char *path, int mode)
{
	if (mode & ~(R_OK | W_OK | X_OK)) {
		errno = EINVAL;
		return -1;
	}
	struct stat info;
	if (stat(path, &info) != 0)
		return -1;
	const mode_t asked = (mode & R_OK ? S_IRUSR : 0) | (mode & W_OK ? S_IWUSR : 0) | (mode & X_OK ? S_IXUSR : 0);
	if ((info.st_mode & asked) != asked) {
		errno = EACCES;
		return -1;
	}
	return 0;
}

_Static_assert(sizeof(FILE_BASIC_INFORMATION) == 40, "the basic class takes 40 bytes");

static int set_basic_resolved(const char *call, const char *resolved, const FILE_BASIC_INFORMATION *information)
{
	HANDLE handle;
	NTSTATUS status = open_resolved(resolved, FILE_WRITE_ATTRIBUTES, FILE_OPEN, 0, &handle);
	if (NT_SUCCESS(status)) {
		status = xsdk_file_set_basic(handle, information);
		const NTSTATUS close_status = NtClose(handle);
		status = NT_SUCCESS(status) ? close_status : status;
	}
	return NT_SUCCESS(status) ? 0 : fail_with_status(call, resolved, status);
}

// Sets the access and modification times, both to now for NULL.
static int set_times(const char *path, const struct timespec times[2])
{
	uint64_t access_time;
	uint64_t write_time;
	if (times) {
		access_time = xsdk_time_to_nt(&times[0]);
		write_time = xsdk_time_to_nt(&times[1]);
	} else {
		KeQuerySystemTime(&access_time);
		write_time = access_time;
	}
	if (!access_time || !write_time) {
		errno = EINVAL;
		return -1;
	}
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0)
		return -1;
	const FILE_BASIC_INFORMATION information = { .last_access_time = access_time, .last_write_time = write_time };
	return set_basic_resolved("utime", resolved, &information);
}

int utime(const char *path, const struct utimbuf *times)
{
	if (!times)
		return set_times(path, NULL);
	const struct timespec converted[2] = { { .tv_sec = times->actime }, { .tv_sec = times->modtime } };
	return set_times(path, converted);
}

// A tv_usec out of range stays out of range, for set_times to refuse.
static struct timespec from_timeval(const struct timeval *time)
{
	const bool in_range = time->tv_usec >= 0 && time->tv_usec < 1000000;
	return (struct timespec){ .tv_sec = time->tv_sec, .tv_nsec = in_range ? time->tv_usec * 1000 : -1 };
}

int utimes(const char *path, const struct timeval times[2])
{
	if (!times)
		return set_times(path, NULL);
	const struct timespec converted[2] = { from_timeval(&times[0]), from_timeval(&times[1]) };
	return set_times(path, converted);
}

_Static_assert(sizeof(FILE_RENAME_INFORMATION) == 16, "the rename class takes 16 bytes");

// Replaces what's at the new name, as POSIX's does; std::filesystem::rename comes here too. Linked ahead of newlib's,
// which falls back to link and unlink.
int rename(const char *old_path, const char *new_path)
{
	char from[XSDK_PATH_BYTES];
	char to[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, old_path, from) != 0 || resolve_or_fail(AT_FDCWD, new_path, to) != 0)
		return -1;
	HANDLE handle;
	NTSTATUS status = open_resolved(from, DELETE, FILE_OPEN, 0, &handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("rename: NtCreateFile", from, status);
	const uint16_t length = (uint16_t)strlen(to);
	const FILE_RENAME_INFORMATION information = { .replace_if_exists = 1,
		.name = { .length = length, .maximum_length = (uint16_t)(length + 1), .pointer = to } };
	IO_STATUS_BLOCK io_status;
	status = NtSetInformationFile(handle, &io_status, &information, sizeof(information), FILE_RENAME_INFORMATION_CLASS);
	const NTSTATUS close_status = NtClose(handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("rename: NtSetInformationFile", from, status);
	if (!NT_SUCCESS(close_status))
		return fail_with_status("rename: NtClose", from, close_status);
	return 0;
}

int truncate(const char *path, off_t length_bytes)
{
	if (length_bytes < 0) {
		errno = EINVAL;
		return -1;
	}
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0)
		return -1;
	HANDLE handle;
	NTSTATUS status = open_resolved(resolved, GENERIC_WRITE, FILE_OPEN, FILE_NON_DIRECTORY_FILE, &handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("truncate: NtCreateFile", resolved, status);
	status = xsdk_file_set_size(handle, (uint64_t)length_bytes);
	const NTSTATUS close_status = NtClose(handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("truncate: setting the size", resolved, status);
	if (!NT_SUCCESS(close_status))
		return fail_with_status("truncate: NtClose", resolved, close_status);
	return 0;
}

// A file or folder of the volume, opened shared, as a folder may be open elsewhere.
int statvfs(const char *path, struct statvfs *info)
{
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(AT_FDCWD, path, resolved) != 0)
		return -1;
	ANSI_STRING name;
	OBJECT_ATTRIBUTES attributes;
	xsdk_path_attributes(resolved, &name, &attributes);
	IO_STATUS_BLOCK io_status;
	HANDLE handle;
	NTSTATUS status = NtCreateFile(&handle, GENERIC_READ | SYNCHRONIZE, &attributes, &io_status, NULL,
		FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT);
	if (!NT_SUCCESS(status))
		return fail_with_status("statvfs: NtCreateFile", resolved, status);
	status = xsdk_file_statvfs(handle, info);
	const NTSTATUS close_status = NtClose(handle);
	if (!NT_SUCCESS(status))
		return fail_with_status("statvfs: NtQueryVolumeInformationFile", resolved, status);
	if (!NT_SUCCESS(close_status))
		return fail_with_status("statvfs: NtClose", resolved, close_status);
	return 0;
}

// The owner's write bit sets or clears the read-only attribute (xsdk_file_mode_attributes), read back for EPERM where
// the file system doesn't keep it (xsdk_file_mode_kept); the other bits have nowhere to go. There are no links for
// flags to choose between.
int fchmodat(int dir_fd, const char *path, mode_t mode, int flags)
{
	(void)flags;
	char resolved[XSDK_PATH_BYTES];
	if (resolve_or_fail(dir_fd, path, resolved) != 0)
		return -1;
	FILE_NETWORK_OPEN_INFORMATION information;
	if (query_resolved(resolved, &information) != 0)
		return -1;
	const FILE_BASIC_INFORMATION basic = { .attributes = xsdk_file_mode_attributes(information.attributes, mode) };
	if (set_basic_resolved("chmod", resolved, &basic) != 0 || query_resolved(resolved, &information) != 0)
		return -1;
	return xsdk_file_mode_kept(information.attributes, mode);
}

int chmod(const char *path, mode_t mode)
{
	return fchmodat(AT_FDCWD, path, mode, 0);
}

// The kernel's file calls have no links of either kind.
int link(const char *existing, const char *path)
{
	(void)existing;
	(void)path;
	errno = ENOSYS;
	return -1;
}

int symlink(const char *target, const char *path)
{
	(void)target;
	(void)path;
	errno = ENOSYS;
	return -1;
}

// No file is a symbolic link.
ssize_t readlink(const char *path, char *buffer, size_t size_bytes)
{
	(void)buffer;
	(void)size_bytes;
	struct stat info;
	if (stat(path, &info) != 0)
		return -1;
	errno = EINVAL;
	return -1;
}

long pathconf(const char *path, int name)
{
	(void)path;
	if (name == _PC_PATH_MAX)
		return XSDK_PATH_BYTES;
	errno = EINVAL;
	return -1;
}
