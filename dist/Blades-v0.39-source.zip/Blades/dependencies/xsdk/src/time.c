// newlib declares CLOCK_MONOTONIC_RAW only to GNU code.
#define _GNU_SOURCE

#include "time_private.h"

#include <errno.h>
#include <stdint.h>
#include <sys/time.h>
#include <time.h>

#include "xsdk/kernel.h"

// POSIX clocks: CLOCK_REALTIME from the kernel's system time, which steps a millisecond at a time on the console;
// CLOCK_MONOTONIC and CLOCK_MONOTONIC_RAW from the CPU's time base, which nothing adjusts.

// 100 ns intervals from 1601, where NT time starts, to 1970.
static const int64_t NT_UNIX_EPOCH = 116444736000000000LL;

enum {
	NT_TICKS_PER_SECOND = 10000000,
	NANOSECONDS_PER_SECOND = 1000000000,
	NANOSECONDS_PER_NT_TICK = 100,
	// The CPU's 3192 MHz over 64 (libxenon:libxenon/drivers/ppc/timebase.h:6). KeQueryPerformanceFrequency reports
	// 50 MHz (results/2026-10-10-probe-vblank/xsdk.log:3), which reads the console's 60 Hz vblank 0.25% short
	// (docs/HARDWARE.md, "The time base runs at 49.875 MHz"). Xenia runs it at 50 MHz
	// (xenia:src/xenia/emulator.cc:151).
	TIME_BASE_HZ = 49875000,
	// The system time's step on the console (docs/HARDWARE.md, "SDL's drivers and the fixed clocks on the console").
	REALTIME_STEP_NS = 1000000,
	// A time base tick is 20.05 ns; clock_getres gives whole nanoseconds, so 21.
	TIME_BASE_TICK_NS = (NANOSECONDS_PER_SECOND + TIME_BASE_HZ - 1) / TIME_BASE_HZ,
};

static uint64_t time_base(void)
{
	uint32_t upper;
	uint32_t lower;
	uint32_t check;
	// The upper half can tick between the two reads in 32-bit mode.
	do {
		__asm__ volatile("mftbu %0" : "=r"(upper));
		__asm__ volatile("mftb %0" : "=r"(lower));
		__asm__ volatile("mftbu %0" : "=r"(check));
	} while (upper != check);
	return (uint64_t)upper << 32 | lower;
}

struct timespec xsdk_time_from_nt(uint64_t nt_time)
{
	const int64_t since_1970 = (int64_t)nt_time - NT_UNIX_EPOCH;
	struct timespec time = {
		.tv_sec = since_1970 / NT_TICKS_PER_SECOND,
		.tv_nsec = (long)(since_1970 % NT_TICKS_PER_SECOND) * NANOSECONDS_PER_NT_TICK,
	};
	// Division rounds toward zero; times before 1970 still need a positive tv_nsec.
	if (time.tv_nsec < 0) {
		time.tv_sec--;
		time.tv_nsec += NANOSECONDS_PER_SECOND;
	}
	return time;
}

uint64_t xsdk_time_to_nt(const struct timespec *time)
{
	if (time->tv_nsec < 0 || time->tv_nsec >= NANOSECONDS_PER_SECOND)
		return 0;
	// NT time can't go before 1601, nor past what 63 bits count.
	if (time->tv_sec <= -NT_UNIX_EPOCH / NT_TICKS_PER_SECOND ||
		time->tv_sec >= (INT64_MAX - NT_UNIX_EPOCH) / NT_TICKS_PER_SECOND)
		return 0;
	return (uint64_t)(NT_UNIX_EPOCH + time->tv_sec * NT_TICKS_PER_SECOND + time->tv_nsec / NANOSECONDS_PER_NT_TICK);
}

int clock_gettime(clockid_t clock, struct timespec *time)
{
	if (clock == CLOCK_REALTIME) {
		uint64_t now;
		KeQuerySystemTime(&now);
		*time = xsdk_time_from_nt(now);
		return 0;
	}
	if (clock == CLOCK_MONOTONIC || clock == CLOCK_MONOTONIC_RAW) {
		const uint64_t ticks = time_base();
		time->tv_sec = (time_t)(ticks / TIME_BASE_HZ);
		time->tv_nsec = (long)(ticks % TIME_BASE_HZ * NANOSECONDS_PER_SECOND / TIME_BASE_HZ);
		return 0;
	}
	errno = EINVAL;
	return -1;
}

int clock_getres(clockid_t clock, struct timespec *resolution)
{
	long step_ns;
	if (clock == CLOCK_REALTIME) {
		step_ns = REALTIME_STEP_NS;
	} else if (clock == CLOCK_MONOTONIC || clock == CLOCK_MONOTONIC_RAW) {
		step_ns = TIME_BASE_TICK_NS;
	} else {
		errno = EINVAL;
		return -1;
	}
	if (resolution)
		*resolution = (struct timespec){ .tv_nsec = step_ns };
	return 0;
}

int gettimeofday(struct timeval *time, void *zone)
{
	(void)zone;
	struct timespec now;
	(void)clock_gettime(CLOCK_REALTIME, &now);
	time->tv_sec = now.tv_sec;
	time->tv_usec = now.tv_nsec / 1000;
	return 0;
}

static int64_t monotonic_ns(void)
{
	struct timespec now;
	(void)clock_gettime(CLOCK_MONOTONIC, &now);
	return (int64_t)now.tv_sec * NANOSECONDS_PER_SECOND + now.tv_nsec;
}

int nanosleep(const struct timespec *request, struct timespec *remaining)
{
	if (request->tv_nsec < 0 || request->tv_nsec >= NANOSECONDS_PER_SECOND || request->tv_sec < 0) {
		errno = EINVAL;
		return -1;
	}
	// The kernel's relative wait ends on its clock tick, up to a tick before the time asked for (docs/HARDWARE.md,
	// "The time base runs at 49.875 MHz"), so wait again for what's left until CLOCK_MONOTONIC passes the deadline.
	const int64_t start = monotonic_ns();
	// A sleep past what the clock can count is as good as forever.
	const int64_t deadline = request->tv_sec < (INT64_MAX - start) / NANOSECONDS_PER_SECOND
		? start + (int64_t)request->tv_sec * NANOSECONDS_PER_SECOND + request->tv_nsec
		: INT64_MAX;
	for (int64_t left = deadline - start; left > 0; left = deadline - monotonic_ns()) {
		// A negative interval is relative.
		const int64_t interval = -((left + NANOSECONDS_PER_NT_TICK - 1) / NANOSECONDS_PER_NT_TICK);
		(void)KeDelayExecutionThread(USER_MODE, 0, &interval);
	}
	if (remaining) {
		remaining->tv_sec = 0;
		remaining->tv_nsec = 0;
	}
	return 0;
}

unsigned int sleep(unsigned int seconds)
{
	const struct timespec request = { .tv_sec = seconds };
	struct timespec remaining = { 0 };
	(void)nanosleep(&request, &remaining);
	return (unsigned int)remaining.tv_sec;
}
