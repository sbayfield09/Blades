#include "tests.h"

#include <stdint.h>
#include <string.h>
#include <strings.h>

#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/splash.h"

enum { SPLASH_MS = 2000 };

// int32_t and uint32_t are int and unsigned int, as the console's own compiler and desktop compilers have them, so
// code written for those builds unchanged (rs6000/xsdk.h in tools/toolchain/gcc-xsdk.patch).
_Static_assert(__builtin_types_compatible_p(int32_t, int) && __builtin_types_compatible_p(uint32_t, unsigned int),
	"int32_t and uint32_t are int and unsigned int");

static int passed_count;
static int failed_count;

void check(const char *name, bool passed)
{
	xsdk_log_write("%s: %s", passed ? "PASS" : "FAIL", name);
	if (passed)
		passed_count++;
	else
		failed_count++;
}

int main(int argc, char **argv)
{
	xsdk_log_write("xsdk test title");
	check("splash: the vulkan4xenon logo shown", NT_SUCCESS(xsdk_splash_show(SPLASH_MS)));
	// The command line holds only the .xex's name, in quotes: xsdk_test's on the console, default.xex in Xenia.
	const size_t name_length = argv[0] ? strlen(argv[0]) : 0;
	check("start: main gets argc 1, argv[0] the .xex's name without its quotes, and a null argv[1]",
		argc == 1 && name_length > 4 && !strchr(argv[0], '"') && strcasecmp(argv[0] + name_length - 4, ".xex") == 0 &&
			!argv[1]);
	test_image();
	test_memory();
	test_threads();
	test_placement();
	test_pthread();
	test_objects();
	test_thread_control();
	test_semaphore();
	test_pages();
	test_clocks();
	test_kernel_entry();
	test_interrupts();
	test_files();
	test_xam();
	test_system();
	test_copy();
	test_xsc();
	test_net();
	test_cpp_objects();
	test_cpp_threads();
	test_cpp_atomics();
	test_cpp_exceptions();
	test_cpp_unwind();
	test_fp_align();
	test_cpp_chrono();
	test_cpp_filesystem();
	test_cpp_format();
	test_input();
	test_audio();
	test_gpu();
	test_present();
	test_triangle();
	test_texture();
	test_render();
	test_resolve_rect();
	test_visibility();
	test_pacing();
	test_scale();
	test_constants();
	test_indexed();
	test_depth();
	test_hiz();
	test_raster();
	test_depth_clamp();
	test_sampling();
	test_cube_volume();
	test_anisotropy();
	test_formats();
	test_upload();
	test_multisample();
	test_targets();
	test_tiles();
	test_vertex();
	test_instancing();
	test_indexed_reads();
	test_hlsl();
	test_text();
	test_replay();
	test_microcode();
	test_registers();
	xsdk_log_write("tests: %d passed, %d failed", passed_count, failed_count);
	return failed_count;
}
