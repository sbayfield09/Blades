#ifndef XSDK_TESTS_H
#define XSDK_TESTS_H

#include <stdbool.h>
#include <stdint.h>

#include "xsdk/present.h"

#ifdef __cplusplus
extern "C" {
#endif

void check(const char *name, bool passed);
// The present's stats once its frames have all flipped, or after a second: a test reads them then, before what it
// checks after its run, as each vblank meanwhile finds no frame queued and counts as missed (test_pacing.c).
void test_present_stats_at_last_flip(uint32_t frames, XsdkPresentStats *stats);

enum {
	// How long a test leaves its last frame on screen. Each check takes a second at most, so a run is quick; a build
	// made for a capture lengthens this.
	TEST_SHOW_MS = 500,
};

void test_image(void);
// The memory the kernel leaves a title (milestone 21).
void test_memory(void);
void test_threads(void);
// Threads placed on the six hardware threads (milestone 26).
void test_placement(void);
void test_pthread(void);
void test_objects(void);
void test_thread_control(void);
void test_semaphore(void);
void test_pages(void);
void test_clocks(void);
void test_kernel_entry(void);
// 64-bit values held across the clock interrupt.
void test_interrupts(void);

// The registers the console's code keeps across a call, r14-r31 whole, f14-f31 and v14-v31, as kernel_entry_check.S
// sets and reads them; bit 14 + i of each mask in EntryChanged stands for register 14 + i.
enum {
	ENTRY_REGISTERS = 18,
	ENTRY_FIRST_KEPT = 14,
};

typedef struct {
	uint64_t gpr[ENTRY_REGISTERS];
	uint64_t fpr[ENTRY_REGISTERS];
	uint32_t vr[ENTRY_REGISTERS][4];
} EntryRegs;

typedef struct {
	uint32_t gpr_low;
	uint32_t gpr_high;
	uint32_t fpr;
	uint32_t vr;
} EntryChanged;

// Sets them to sentinels, calls fn(arg) as the kernel calls a title's code, and stores what they hold after in *out.
void test_entry_regs_call(void (*fn)(void *), void *arg, EntryRegs *out);
// Stores them as they are into *out, 16-byte aligned, and changes none of them.
void test_entry_snapshot(EntryRegs *out);
// Which of them differ from the sentinels test_entry_regs_call set.
EntryChanged test_entry_changed(const EntryRegs *regs);
void test_files(void);
// Saves, the signed-in user and XAM's asynchronous calls, with nobody signed in (milestone 51).
void test_xam(void);
// The console's time zone, language and country (milestone 54).
void test_system(void);
// The SDK's memcpy and memmove (milestone 20).
void test_copy(void);
// xost's compiler, shaders compiled from SPIR-V (docs/scope/shader-compiling.md, step 2).
void test_xsc(void);
// Sockets, against tools/net_echo.py on the PC (docs/scope/networking.md).
void test_net(void);
void test_input(void);
void test_audio(void);

// C++23 runtime (milestone 3).
void test_cpp_objects(void);
void test_cpp_threads(void);
void test_cpp_atomics(void);
void test_cpp_exceptions(void);
// Registers a caller keeps, through a C++ exception and through longjmp (milestone 22).
void test_cpp_unwind(void);
// Floats and doubles at every byte offset, which the console faults on in float registers (milestone 23).
void test_fp_align(void);
void test_cpp_chrono(void);
void test_cpp_filesystem(void);
void test_cpp_format(void);

// The command processor (milestone 4).
void test_gpu(void);

// A cleared screen (milestone 5).
void test_present(void);

// A triangle (milestone 6).
void test_triangle(void);

// A textured quad (milestone 7).
void test_texture(void);

// Render to texture (milestone 8).
void test_render(void);

// Resolving part of a target, for vulkan4xenon milestone 27.
void test_resolve_rect(void);

// Visibility queries, for vulkan4xenon milestone 28.
void test_visibility(void);

// Frame pacing (milestone 9), each mode briefly; tests/pacing.c runs one for 10 minutes.
void test_pacing(void);

// 1280x720 on the display's scaler, held on screen for a capture.
void test_scale(void);

// Shader constants (milestone 11).
void test_constants(void);

// Indexed draws and topologies (milestone 12).
void test_indexed(void);

// Depth and stencil (milestone 13).
void test_depth(void);

// Hierarchical depth (milestone 30).
void test_hiz(void);

// Raster and blend state (milestone 14).
void test_raster(void);

// Depth clamp (milestone 61).
void test_depth_clamp(void);

// Sampling and mipmaps (milestone 15).
void test_sampling(void);

// Cube and 3D textures (vulkan4xenon milestone 23).
void test_cube_volume(void);

// Anisotropic filtering (milestone 33).
void test_anisotropy(void);

// Texture formats (milestone 16).
void test_formats(void);

// Tiled uploads, exact and timed (vulkan4xenon milestone 29 step 6).
void test_upload(void);

// Multisampled targets (milestone 32).
void test_multisample(void);

// Render target formats (vulkan4xenon milestone 25).
void test_targets(void);

// Tiled passes at one sample (milestone 44).
void test_tiles(void);

// Vertex input (milestone 17).
void test_vertex(void);

// Instanced draws (milestone 47).
void test_instancing(void);

// Constants read at run-time indices through xost's optimiser (milestone 48 step 6).
void test_indexed_reads(void);

// D3D9's semantics through glslang's HLSL (milestone 50 step 4).
void test_hlsl(void);

// Text on screen (milestone 57).
void test_text(void);

// Recorded command buffers (milestone 18).
void test_replay(void);

// Shaders' microcode in shared pages (milestone 25).
void test_microcode(void);

// Shaders past 16 registers (milestone 24). Last, as without xsdk's register split it hangs the GPU.
void test_registers(void);

#ifdef __cplusplus
}
#endif

#endif
