Original Blades test fixtures, generated with FFmpeg testsrc/sine sources.
MIT/CC0: these samples may be used, modified and redistributed without restriction.
sample.wmv: 12 seconds, WMV2/WMA2, 640x360, stereo.
sample.mp4: 12 seconds, H264 Constrained Baseline/AAC, 640x360, stereo.
These are synthetic test media, not uploaded dashboard reference footage.
