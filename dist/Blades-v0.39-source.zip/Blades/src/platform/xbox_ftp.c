#include "xbox_ftp.h"
#include <arpa/inet.h>
#include "xsdk/net.h"
#include "xsdk/thread.h"
static bool address(void *context,char ip[16]){(void)context;struct in_addr addr;if(xsdk_net_address(&addr))return false;return inet_ntop(AF_INET,&addr,ip,16)!=NULL;}
static void start(void *context){(void)context;(void)xsdk_thread_move(5);(void)xsdk_thread_set_priority(XSDK_CURRENT_THREAD,-2,NULL);}
FtpServer *xbox_ftp_open(void){
    static const FtpDrive drives[]={
        {"HDD","hdd:/"},{"USB0","usb0:/"},{"USB1","usb1:/"},{"USB2","usb2:/"},
        {"MU0","mu0:/"},{"MU1","mu1:/"},{"InternalMemory","bladesmu:/"}};
    FtpOptions options={.drives=drives,.count=sizeof drives/sizeof drives[0],.port=21,
        .config="game:/Config/ftp-settings.txt",.address=address,.worker_start=start};
    return ftp_open(&options);
}
