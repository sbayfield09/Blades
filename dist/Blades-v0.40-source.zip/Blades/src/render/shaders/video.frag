#version 450
layout(location=0) in vec2 v_uv;
layout(location=1) in vec4 v_color;
layout(location=0) out vec4 o_color;
layout(set=0,binding=0) uniform sampler2D u_texture;
// R8 atlas: full-size Y; half-size U/V side by side below Y.
// xy: atlas dimensions, z: BT709, w: full range.
layout(push_constant) uniform Params {vec4 p;} constants;
void main() {
    vec2 half_texel=0.5/constants.p.xy;
    float yy=texture(u_texture,clamp(vec2(v_uv.x,v_uv.y*(2.0/3.0)),half_texel,vec2(1.0,2.0/3.0)-half_texel)).r;
    vec2 uv=vec2(v_uv.x*0.5,2.0/3.0+v_uv.y/3.0);
    float u=texture(u_texture,clamp(uv,vec2(0.0,2.0/3.0)+half_texel,vec2(0.5,1.0)-half_texel)).r-128.0/255.0;
    float v=texture(u_texture,clamp(uv+vec2(0.5,0.0),vec2(0.5,2.0/3.0)+half_texel,vec2(1.0,1.0)-half_texel)).r-128.0/255.0;
    float full=constants.p.w;
    float y=(yy-(1.0-full)*(16.0/255.0))*mix(255.0/219.0,1.0,full);
    float scale=mix(255.0/224.0,1.0,full);
    float kr=mix(0.299,0.2126,constants.p.z),kb=mix(0.114,0.0722,constants.p.z),kg=1.0-kr-kb;
    vec3 rgb=vec3(y+2.0*(1.0-kr)*v*scale,
        y-2.0*(kb*(1.0-kb)*u+kr*(1.0-kr)*v)*scale/kg,
        y+2.0*(1.0-kb)*u*scale);
    o_color=vec4(clamp(rgb,0.0,1.0),1.0)*v_color;
}
