# Embedded video decoder

FFmpeg2.8.22, pinned upstream source:
https://github.com/FFmpeg/FFmpeg/tree/n2.8.22

Archive SHA256:
9f2ed903682524fbfb6999f2bb106f02219df1393fece58cae9da1a1ef780358

The independent Simple360Player test established that software video playback
is practical on this console. Blades0.40 uses FFmpeg directly in its own xsdk
executable; it does not link the GPL Simple360Player UI, XDK binaries, hooks or
adapter. New playback/queue/audio/controls code is original Blades MIT source.

The configuration disables GPL/nonfree components, encoding, network protocols
and hardware accelerators. Xbox builds enable standard PowerPC/AltiVec; VSX,
POWER8, PPC4xx, ldbrx and unaligned fast paths stay disabled. Host validation
libraries retain portable scalar code. The
result is LGPL2.1-or-later. Sources and original licence texts are preserved in
the tarball. xsdk.patch places decoder workers on hardware threads2,4,0 and uses
xsdk's existing monotonic clock for FFmpeg's non-cryptographic fallback seed,
avoiding a missing newlib times syscall. It also bypasses the G5 dcbzl probe/clear path on xsdk. It changes no decoder algorithms.

Build with tools/build-video-ffmpeg.py --target xbox|host --build <directory>.
Pass the printed install prefix to CMake as BLADES_FFMPEG_PREFIX. The release
source/relink bundle includes the complete application source, decoder source,
patches, build scripts and notices, allowing modification/relinking of FFmpeg.
Runtime assets retain their separate font/artwork notices. Do not remove the
LGPL source/relink link from the distributed notice.
