#!/usr/bin/env python3
"""Verify the shipping Xbox decoder configuration and instruction restriction."""
import argparse,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('build',type=Path);p.add_argument('--objdump',required=True);a=p.parse_args()
config=(a.build/'objects/config.h').read_text()
for required in ['ARCH_PPC 0','HAVE_ALTIVEC 0','CONFIG_GPL 0','CONFIG_NONFREE 0']:
 assert '#define '+required in config,required
flags=(a.build/'objects/config.mak').read_text()
for required in ['-mno-altivec','-fno-tree-vectorize','-fno-tree-slp-vectorize']:assert required in flags,required
instruction=re.compile(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+){4}(\S+)')
count=0
for name in ['avcodec','avformat','avutil','swscale','swresample']:
 proc=subprocess.Popen([a.objdump,'-d',str(a.build/'install/lib'/('lib'+name+'.a'))],stdout=subprocess.PIPE,text=True)
 for line in proc.stdout:
  match=instruction.match(line)
  if match:
   op=match[1];count+=1
   assert not (op.startswith('v') or op.startswith(('lvx','lvsl','lvsr','lve','stvx','stve')) or op in {'mfvscr','mtvscr'}),line
 assert proc.wait()==0
print(f'PASS: compatible C decoder configuration; no VMX vector operations in five FFmpeg archives ({count} instructions checked). SDK copy code is separate.')
