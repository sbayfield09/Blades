# Embedded decoder — Blades0.41

Pinned FFmpeg2.8.22 source: https://github.com/FFmpeg/FFmpeg/tree/n2.8.22
Archive SHA256:9f2ed903682524fbfb6999f2bb106f02219df1393fece58cae9da1a1ef780358

The Xbox compatibility build disables FFmpeg assembly/AltiVec and compiler
vectorization after the0.40 audio-only/crash report. The exact fault is unknown;
a classic PPC arithmetic harness did not establish Xenon compatibility. SDK
memory-copy routines are separate and unchanged. CPU decoding is retained;
three independent linear GPU planes handle colour conversion/scaling.

GPL/nonfree, encoding and network components are disabled; FFmpeg remains LGPL2.1+.
The original MIT frontend links no Simple360Player GPL UI or XDK executable.
xsdk.patch places four workers on hardware threads2–5, supplies the monotonic
fallback seed and excludes the G5 dcbzl probe on xsdk. No decoder algorithm changes.
Sources/licences are preserved in the archive; tools/build-video-ffmpeg.py builds
it offline. tools/verify-video-decoder.py verifies configuration/instructions.

The release source/relink ZIP contains complete application/decoder sources,
patches, pinned SDK and build scripts. See BUILDING.txt. Preserve the download
link in the runtime LGPL notice. Fonts/artwork retain their own notices.
