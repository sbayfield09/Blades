Blades artwork pack for version 0.5.0 or newer

Extract this ZIP into Hdd1:\Blades\ so the artwork file is located at:
Hdd1:\Blades\Assets\blades.xzp

Keep the version 0.5.0 default.xex in Hdd1:\Blades\. No conversion is needed.
This pack includes the five blade skins, menu icons and shared 5766 images.
Menu typography, backgrounds, sounds and some layout details remain approximate.
Desktop resource and dashboard transition checks passed; this pack still needs
physical-console testing.

Artwork credit: original project by zivvoz / DashX360, inspired by Microsoft's
Xbox 360 Dashboard interfaces. Xbox/Microsoft own their respective assets and
trademarks. Artwork ownership is unchanged by this conversion.

Source: https://github.com/ZivvoZ/dashx360
Commit: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared resources: retail dashboard 2.0.5766.0 shrdres.xzp from the archive
linked by the user, commit 0938397d60975630db108fded069bc04d52740b1.
