Blades 0.7.0 premade artwork pack

Use the matching version 0.7.0 default.xex. Put it in Hdd1:\Blades\ and
extract this ZIP there, creating Hdd1:\Blades\Assets\blades.xzp.
No conversion is required.

Contains five blade states, menu icons, 5766 shared images and BSK2 shell
bounds. Frame/tray colours match the reused DashX360 background palette.
The moving background is implemented in the XEX; no background video is needed.
Desktop checks passed. Physical-console performance still needs testing.

Credit: original project by zivvoz / DashX360, inspired by Microsoft's Xbox
360 Dashboard interfaces. Background motion/lighting adapted from the supplied
BladeAmbientTexture.cs implementation. Xbox/Microsoft and other rights holders
retain ownership of their respective material. See the XEX's licences folder
for DASHX360-NOTICE.txt.

Source: https://github.com/ZivvoZ/dashx360
Revision: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared images: user-supplied retail 5766 archive, revision
0938397d60975630db108fded069bc04d52740b1.
