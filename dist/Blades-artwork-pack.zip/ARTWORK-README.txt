Blades 0.6.0 premade artwork pack

Use the matching version 0.6.0 default.xex with this pack. Replace both the
XEX and artwork file when updating from 0.5.0.

Put default.xex in Hdd1:\Blades\ and extract this ZIP into that directory.
The artwork file should be Hdd1:\Blades\Assets\blades.xzp.
No PC conversion is required.

Includes five blade states, menu icons, 5766 shared images and BSK2 root and
expanded surface bounds. Version 0.6.0 preserves settings-icon proportions,
corrects card/menu/tray/footer alignment and transparency, and extends submenu
colour through the active tab and beneath curved sides, header and footer.
The XEX and pack pass desktop checks; physical-console testing is still needed.
Menu font, background and service/demo content remain approximate.

Credit: original project by zivvoz / DashX360, inspired by Microsoft's Xbox
360 Dashboard interfaces. Xbox/Microsoft own their respective artwork and
trademarks. Artwork ownership is unchanged by this conversion.

Source: https://github.com/ZivvoZ/dashx360
Commit: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared source: retail 5766 shrdres.xzp from the archive supplied by the user,
commit 0938397d60975630db108fded069bc04d52740b1.
