Blades 0.21.0 premade artwork, font and sound pack

Use the matching 0.21.0 default.xex. Extract this ZIP into the Blades folder
so Assets/blades.xzp is alongside the executable. No conversion is needed.
The 234-entry artwork payload is unchanged from versions 0.18 and 0.19.
The existing blades, startup, animated background, Convection atlas, button
prompts, whooshes and disc indicator are retained.

Games -> Played Games -> Scan Folders configures library locations. After
choosing a folder and category, select depth 0-32 or Unlimited (default 3).
Select a saved path to change its depth. Scans show the current folder/file
and counts; X stops after the current read returns. Empty scans explicitly
finish even when no games/apps/homebrew are found. ID-less XEX apps are
supported; displayed title labels omit question marks and unsupported glyphs.
Files and launch paths are unchanged. See the executable's install notes.

This pack's 234-entry payload is unchanged. The new XEX still needs console
testing. The fresh walkthrough is desktop GPU playback with simulated storage
and launch preparation, not actual console I/O or a real title launch.

Original project and indicator: zivvoz / DashX360, inspired by Microsoft's
Xbox 360 Dashboard. Artwork, font glyphs and audio retain ownership with
Microsoft and their respective rights holders. See the included notices.

Artwork/indicator source: https://github.com/ZivvoZ/dashx360
Revision: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared images: user-supplied retail 5766 archive, revision
0938397d60975630db108fded069bc04d52740b1.
Font recovery tool: https://github.com/taglocklar/360dashboards
Revision: ad85c697bde95022cf3c9425bb0b51e7c4a9f1e9
