Blades 0.20.0 premade artwork, font and sound pack

Use the matching 0.20.0 default.xex. Extract this ZIP into the Blades folder
so Assets/blades.xzp is alongside the executable. No conversion is needed.
The 234-entry artwork payload is unchanged from versions 0.18 and 0.19.
The existing blades, startup, animated background, Convection atlas, button
prompts, whooshes and disc indicator are retained.

Games -> Played Games -> Scan Folders configures Games, Apps and Homebrew
locations. Use A to enter a folder and X to select the current folder, then
choose a category. All descendant folders are scanned with no configured
depth limit. A manually launches a library title; scanning never autoplays.
The executable supplies library scanning and native launch support. The new
storage/mount/handoff path still needs testing on your Xbox 360. The release
walkthrough is labelled desktop GPU playback with simulated library storage.

Original project and indicator: zivvoz / DashX360, inspired by Microsoft's
Xbox 360 Dashboard. Artwork, font glyphs and audio retain ownership with
Microsoft and their respective rights holders. See the included notices.

Artwork/indicator source: https://github.com/ZivvoZ/dashx360
Revision: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared images: user-supplied retail 5766 archive, revision
0938397d60975630db108fded069bc04d52740b1.
Font recovery tool: https://github.com/taglocklar/360dashboards
Revision: ad85c697bde95022cf3c9425bb0b51e7c4a9f1e9
