Blades 0.19.0 premade artwork, font and sound pack

Use the matching 0.19.0 default.xex. Extract this ZIP into the Blades folder
so Assets/blades.xzp is alongside the executable. Replace both when updating.
No conversion is needed.

234 entries. All 218 previous blade/startup/font/button/sound payloads are
unchanged. Sixteen small transparent disc-reading frames adapt the console
silhouette and orbiting dots from the supplied DashX360 loading indicator.
The existing Convection glyph atlas, stereo whooshes and startup remain.

A operates the disc row; Y ejects loaded/reading discs. Inserted games wait
for manual selection of Play. The executable supplies physical drive support;
this pack supplies its artwork. New DVD hardware behavior needs console testing.
The release video is desktop GPU playback with simulated disc hardware.

Original project and indicator: zivvoz / DashX360, inspired by Microsoft's
Xbox 360 Dashboard. Artwork, font glyphs and audio retain ownership with
Microsoft and their respective rights holders. See the included notices.

Artwork/indicator source: https://github.com/ZivvoZ/dashx360
Revision: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared images: user-supplied retail 5766 archive, revision
0938397d60975630db108fded069bc04d52740b1.
Font recovery tool: https://github.com/taglocklar/360dashboards
Revision: ad85c697bde95022cf3c9425bb0b51e7c4a9f1e9

Version 0.19 fixes pending detection, title-ID returns and empty-tray status in the executable. The complete 234-entry artwork payload is unchanged from 0.18.
