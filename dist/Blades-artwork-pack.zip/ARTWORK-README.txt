Blades 0.13.0 premade artwork, Convection glyph and transition sound pack

Use the matching 0.13.0 default.xex. Put it in Hdd1:\Blades\ and extract this
ZIP there so Hdd1:\Blades\Assets\blades.xzp is present. No conversion is needed.
Replace both the executable and pack when updating.

This release uses glyphs recovered from the supplied Convection / Xbox TC font
resources. It does not replace console system fonts or modify flash.
All 271 glyph-page hashes and all 95 ASCII outline/metric records were checked.
The pack has 213 entries, including font coverage, fractional advances, a
font notice and eight revised ABXY prompt sprites. The letters are smaller,
heavier and individually centred; disabled prompts use softer opacity. It contains no raw TrueType font or Xbox font containers.
The previous blade artwork, shell geometry and animated background are retained.
Six original stereo transition recordings from the supplied DashX360 repository
provide blade-switch and submenu open/close whooshes. See AUDIO-NOTICE.txt.
Desktop tests passed; the new build still needs physical-console testing.

Credit: original project by zivvoz / DashX360, inspired by Microsoft's Xbox
360 Dashboard interfaces. Font glyphs and other Microsoft material retain
ownership with Microsoft and their respective rights holders. See FONT-NOTICE.txt.

Artwork source: https://github.com/ZivvoZ/dashx360
Revision: 0c8adb2cef4ad7dff2bf889351efa1f1c244aef2
Shared images: user-supplied retail 5766 archive, revision
0938397d60975630db108fded069bc04d52740b1.
Font recovery tool: https://github.com/taglocklar/360dashboards
Revision: ad85c697bde95022cf3c9425bb0b51e7c4a9f1e9

Version 0.11 corrects blade/submenu cap and rail animation against the supplied
reference recording. This 213-entry resource payload is unchanged from 0.10.
Use the new XEX for the corrected transition motion.

Version 0.12 softens the selected-menu shadow and rounds its right corner,
with a fading right edge and dividers that follow the moving highlight.
The 213-entry resource payload is unchanged. Use the new XEX for this effect.

Version 0.13 corrects the selected menu shadow's fade toward its lower-left
corner. The 213-entry resource payload is unchanged; use the new XEX.
