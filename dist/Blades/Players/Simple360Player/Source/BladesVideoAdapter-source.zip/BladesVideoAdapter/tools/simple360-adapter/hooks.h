#ifndef BLADES_PLAYER_HOOKS_H
#define BLADES_PLAYER_HOOKS_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
enum { PLAYER_HOOKS=2 };
typedef struct {uint32_t offset,original[4],replacement[4];} PlayerHook;
bool player_hook_plan(const uint8_t *image,size_t bytes,uint32_t base,uint32_t handler,PlayerHook out[PLAYER_HOOKS]);
#endif
