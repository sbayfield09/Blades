#!/usr/bin/env python3
"""Build the original freestanding Peer Pressure title DLL; no XDK or modified player binary required."""
import argparse
import importlib.util
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'native-player-probe'))
from build_lex import finish_dll

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sdk',required=True,type=Path)
    p.add_argument('--toolchain',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    source=Path(__file__).resolve().parent
    elf=a.output/'BladesVideoAdapter.elf'
    subprocess.run([str(a.toolchain/'bin/powerpc-xsdk-elf-gcc'),'-mcpu=cell','-fno-pic','-msdata=none',
        '-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-unwind-tables','-fno-asynchronous-unwind-tables',
        '-O2','-Wall','-Wextra','-Werror','-I'+str(a.sdk/'include'),'-I'+str(source.parent.parent/'include'),'-nostdlib','-static',
        '-T',str(source/'helper.ld'),str(source/'helper.c'),str(source/'hooks.c'),str(source.parent.parent/'src/core/video_handoff.c'),
        str(a.sdk/'build/libxsdk.a'),'-lgcc','-o',str(elf)],check=True)
    spec=importlib.util.spec_from_file_location('xsdk_helper_writer',a.sdk/'tools/elf2xex.py')
    w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
    w.IMAGE_BASE=0x9b200000;w.PAGE_BYTES=4096;w.MODULE_TITLE=9;w.PE_EXECUTABLE_IMAGE|=0x2000
    entry,sections=w.read_elf(elf.read_bytes());image,runs=w.build_image(sections)
    libraries=w.read_imports(sections,image)
    assert set(libraries)=={'xboxkrnl.exe'},'helper must import kernel APIs only'
    w.patch_import_records(image,libraries)
    args=SimpleNamespace(stack_size=65536,version=0x100,title_id=0x424c5650)
    w.pe_headers(image,runs,entry,args.stack_size)
    result=finish_dll(w,image,runs,entry,libraries,b'',args)
    xex=a.output/'BladesVideoAdapter.xex';xex.write_bytes(result)
    print('Original Peer Pressure title DLL:',len(result),'bytes; 4KB pages; no CRT, threads or system module')
if __name__=='__main__':main()
