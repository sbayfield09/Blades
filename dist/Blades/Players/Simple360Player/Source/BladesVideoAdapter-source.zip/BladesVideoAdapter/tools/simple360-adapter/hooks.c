#include "hooks.h"
static uint32_t be(const uint8_t *p) {return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static uint32_t crc(const uint8_t *p,size_t n) {
    uint32_t v=~0u;
    for(size_t i=0;i<n;i++){v^=p[i];for(unsigned b=0;b<8;b++)v=(v>>1)^(0xedb88320u&-(v&1));}
    return ~v;
}
bool player_hook_plan(const uint8_t *image,size_t bytes,uint32_t base,uint32_t handler,PlayerHook out[PLAYER_HOOKS]) {
    /* Pinned unmodified Simple360Player0.2, title4D580361. These are application
       methods, not imports, XAM functions or kernel code. Full method CRCs
       guard the entry-point redirects, and no trampoline executes partial
       overwritten prologues. Both methods become return-to-Blades handlers. */
    static const struct {uint32_t offset,bytes,crc;} methods[PLAYER_HOOKS]={
        {0x158378,0x338,0x3708ca0d}, /* PlayerApp::UpdateBrowser */
        {0x153c90,0x808,0xcf6a4dac} /* PlayerApp::RenderBrowser */
    };
    if(!image||!out||base!=0x82000000||!handler||(handler&3))return false;
    for(unsigned i=0;i<PLAYER_HOOKS;i++) {
        const uint32_t at=methods[i].offset,n=methods[i].bytes;
        if(at>bytes||n>bytes-at||crc(image+at,n)!=methods[i].crc)return false;
    }
    for(unsigned i=0;i<PLAYER_HOOKS;i++) {
        out[i].offset=methods[i].offset;
        for(unsigned j=0;j<4;j++)out[i].original[j]=be(image+out[i].offset+4*j);
        out[i].replacement[0]=0x3d600000|(handler>>16);
        out[i].replacement[1]=0x616b0000|(handler&65535);
        out[i].replacement[2]=0x7d6903a6;out[i].replacement[3]=0x4e800420;
    }
    return true;
}
