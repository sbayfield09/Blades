/* Original title-scoped Peer Pressure adapter for Simple360Player0.2.
 * No CRT, heap, worker threads, system DLL or XAM/kernel code patches. */
#include "hooks.h"
#include "video_handoff.h"
#include "xsdk/kernel.h"
#include <stdint.h>
typedef uint32_t (*GetSize)(uint32_t*);
typedef uint32_t (*GetData)(void*,uint32_t);
typedef uint32_t (*SetData)(const void*,uint32_t);
typedef void (*Launch)(const char*,uint32_t);
typedef void *(*HeaderField)(const void*,uint32_t);
static VideoHandoff handoff;
static SetData set_data;
static Launch launch_title;
static uint8_t *player_image;
static PlayerHook plans[PLAYER_HOOKS];
static bool attached,leaving;
static char log_path[1024],ini_path[1024],player_name[260];
static size_t length(const char *s,size_t cap){size_t n=0;while(s&&n<cap&&s[n])n++;return n;}
static ANSI_STRING ansi(const char *s){size_t n=length(s,65534);return (ANSI_STRING){(uint16_t)n,(uint16_t)(n+1),s};}
static bool append(char *out,size_t cap,size_t n,const char *s){size_t m=length(s,cap);if(n+m>=cap)return false;for(size_t i=0;i<=m;i++)out[n+i]=s[i];return true;}
static void log_status(const char *message,uint32_t status,bool reset) {
    if(!log_path[0])return;
    char text[180];size_t n=0;while(message[n]&&n<160){text[n]=message[n];n++;}
    text[n++]=' ';const char hex[]="0123456789ABCDEF";
    for(unsigned i=0;i<8;i++)text[n++]=hex[(status>>(28-4*i))&15];
    text[n++]='\r';text[n++]='\n';
    ANSI_STRING name=ansi(log_path);OBJECT_ATTRIBUTES attr={0,&name,0x40};IO_STATUS_BLOCK io={0};HANDLE file=0;
    NTSTATUS s=NtCreateFile(&file,(reset?GENERIC_WRITE:4u)|SYNCHRONIZE,&attr,&io,0,FILE_ATTRIBUTE_NORMAL,
        FILE_SHARE_READ|FILE_SHARE_WRITE,reset?FILE_OVERWRITE_IF:FILE_OPEN_IF,FILE_SYNCHRONOUS_IO_NONALERT|FILE_NON_DIRECTORY_FILE);
    if(NT_SUCCESS(s)&&file){const uint64_t end=UINT64_MAX;(void)NtWriteFile(file,0,0,0,&io,text,(uint32_t)n,&end);(void)NtFlushBuffersFile(file,&io);(void)NtClose(file);}
}
static void clear_autoplay(void) {
    if(!ini_path[0])return;
    ANSI_STRING name=ansi(ini_path);OBJECT_ATTRIBUTES attr={0,&name,0x40};IO_STATUS_BLOCK io={0};HANDLE file=0;
    NTSTATUS s=NtCreateFile(&file,0x10000u|SYNCHRONIZE,&attr,&io,0,0,FILE_SHARE_READ|FILE_SHARE_WRITE|4u,
        FILE_OPEN,FILE_SYNCHRONOUS_IO_NONALERT|FILE_NON_DIRECTORY_FILE);
    if(NT_SUCCESS(s)&&file){const uint8_t remove=1;(void)NtSetInformationFile(file,&io,&remove,1,13);(void)NtClose(file);}
}
static void flush_code(void *address) {
    uintptr_t first=(uintptr_t)address&~(uintptr_t)127,last=((uintptr_t)address+15)&~(uintptr_t)127;
    __asm__ volatile("dcbst 0,%0\n dcbst 0,%1\n sync\n icbi 0,%0\n icbi 0,%1\n sync\n isync"::"r"(first),"r"(last):"memory");
}
static bool link_folder(const char *link_text,const char *folder) {
    ANSI_STRING link=ansi(link_text),target=ansi(folder);(void)ObDeleteSymbolicLink(&link);
    NTSTATUS s=ObCreateSymbolicLink(&link,&target);log_status("Create title-local path alias",(uint32_t)s,false);return NT_SUCCESS(s);
}
static void return_to_blades(void) {
    if(!leaving) {
        leaving=true;clear_autoplay();
        char folder[260],path[280];size_t n=length(handoff.blades_xex,sizeof handoff.blades_xex),last=n;
        while(last&&handoff.blades_xex[last-1]!='\\')last--;
        if(last) {
            for(size_t i=0;i<last-1;i++)folder[i]=handoff.blades_xex[i];
            folder[last-1]=0;
            if(link_folder("\\??\\bladesreturn:",folder)&&append(path,sizeof path,0,"bladesreturn:\\")&&
               append(path,sizeof path,length(path,sizeof path),handoff.blades_xex+last)) {
                video_handoff_return(&handoff);
                uint32_t result=set_data(&handoff,sizeof handoff);log_status("Return launch data",result,false);
                log_status("Returning to Blades; no player browser",0,false);
                launch_title(path,0);
            }
        }
        log_status("Return call came back; waiting for title switch",0,false);
    }
    /* Match xsdk's exit contract. Do not draw or enter the third-party browser
       while XAM changes titles. The Guide and upstream watchdog remain live. */
    for(;;){const int64_t pause=-1000000;(void)KeDelayExecutionThread(1,0,&pause);}
}
static bool own_paths(void) {
    const char *s=ExLoadedImageName;size_t n=length(s,1024),last=n;
    if(!s||n==1024)return false;
    while(last&&s[last-1]!='\\')last--;
    if(!last||n-last>=sizeof player_name)return false;
    for(size_t i=0;i<last;i++)log_path[i]=ini_path[i]=s[i];
    if(!append(log_path,sizeof log_path,last,"blades-video.log")||!append(ini_path,sizeof ini_path,last,"player.ini"))return false;
    return append(player_name,sizeof player_name,0,s+last);
}
static bool resolve(HANDLE module,uint32_t ordinal,void **out){*out=0;return NT_SUCCESS(XexGetProcedureAddress(module,ordinal,out))&&*out;}
static bool attach(void) {
    if(!own_paths())return false;
    log_status("Blades video adapter0.1: Peer Pressure title DLL",0,true);
    HANDLE xam=0,kernel=0,player=0;void *p=0;
    if(XexGetModuleHandle("xam.xex",&xam)||XexGetModuleHandle("xboxkrnl.exe",&kernel)||
       XexGetModuleHandle(player_name,&player)||!xam||!kernel||!player)return false;
    if(!resolve(kernel,0x12b,&p))return false;
    HeaderField field=(HeaderField)p;
    const void *header=*(void**)((uintptr_t)player+0x58);
    const uint32_t *execution=field(header,0x40006);
    if(!execution||execution[3]!=0x4d580361||execution[1]!=0)return false;
    if(!resolve(xam,0x1a7,&p))return false;
    GetSize get_size=(GetSize)p;
    if(!resolve(xam,0x1a8,&p))return false;
    GetData get_data=(GetData)p;
    if(!resolve(xam,0x1a6,&p))return false;
    set_data=(SetData)p;
    if(!resolve(xam,0x1a4,&p))return false;
    launch_title=(Launch)p;
    uint32_t bytes=0;
    if(get_size(&bytes)||bytes!=sizeof handoff||get_data(&handoff,sizeof handoff)||!video_handoff_valid(&handoff,sizeof handoff,false)) {
        clear_autoplay();log_status("No valid Blades handoff; autoplay cleared",0x80070057,false);return false;
    }
    player_image=*(uint8_t**)((uintptr_t)player+0x1c);uint32_t size=*(uint32_t*)((uintptr_t)player+0x38);
    if(!player_hook_plan(player_image,size,(uint32_t)(uintptr_t)player_image,(uint32_t)(uintptr_t)return_to_blades,plans)) {
        clear_autoplay();log_status("Unknown or modified player methods; no redirect",0x80070032,false);return false;
    }
    if(!link_folder("\\??\\bladesvideo:",handoff.folder)){clear_autoplay();return false;}
    for(unsigned i=0;i<PLAYER_HOOKS;i++) {
        volatile uint32_t *at=(volatile uint32_t*)(player_image+plans[i].offset);
        for(unsigned j=0;j<4;j++)at[j]=plans[i].replacement[j];
        flush_code((void*)at);
    }
    attached=true;log_status("Selected-file alias ready; browser exits redirected",0,false);return true;
}
int helper_entry(HANDLE module,uint32_t reason,void *reserved) {
    (void)module;(void)reserved;
    if(reason==1){if(!attach())log_status("Adapter inactive; check package and launch data",0x80070032,false);}
    else if(reason==0&&attached) {
        HANDLE player=0;
        if(!XexGetModuleHandle(player_name,&player)&&player&&*(uint8_t**)((uintptr_t)player+0x1c)==player_image)
            for(unsigned i=0;i<PLAYER_HOOKS;i++) {
                volatile uint32_t *at=(volatile uint32_t*)(player_image+plans[i].offset);bool ours=true;
                for(unsigned j=0;j<4;j++)ours&=at[j]==plans[i].replacement[j];
                if(ours){for(unsigned j=0;j<4;j++)at[j]=plans[i].original[j];flush_code((void*)at);}
            }
        attached=false;
    }
    return 1;
}
