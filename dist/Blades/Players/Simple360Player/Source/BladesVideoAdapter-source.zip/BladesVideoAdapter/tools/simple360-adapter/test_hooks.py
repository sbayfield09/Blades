#!/usr/bin/env python3
"""Test guarded application hooks against the unmodified upstream decoded image."""
import argparse,ctypes,struct
from pathlib import Path
class Hook(ctypes.Structure):
    _fields_=[('offset',ctypes.c_uint32),('original',ctypes.c_uint32*4),('replacement',ctypes.c_uint32*4)]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('core',type=Path);p.add_argument('image',type=Path);a=p.parse_args()
f=ctypes.CDLL(str(a.core.resolve())).player_hook_plan
f.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32,ctypes.POINTER(Hook)];f.restype=ctypes.c_bool
image=a.image.read_bytes()
def plan(data,base=0x82000000):
    buf=ctypes.create_string_buffer(data);hooks=(Hook*2)();return f(buf,len(data),base,0x9b202000,hooks),hooks
ok,hooks=plan(image);assert ok
assert [h.offset for h in hooks]==[0x158378,0x153c90]
patched=bytearray(image)
for h in hooks:
    assert struct.pack('>4I',*h.original)==image[h.offset:h.offset+16]
    assert tuple(h.replacement)==(0x3d609b20,0x616b2000,0x7d6903a6,0x4e800420)
    patched[h.offset:h.offset+16]=struct.pack('>4I',*h.replacement)
assert sum(a!=b for a,b in zip(image,patched))<=32
for h in hooks:patched[h.offset:h.offset+16]=struct.pack('>4I',*h.original)
assert patched==image
for offset in [0x158378,0x1586ac,0x153c90,0x154490]:
    changed=bytearray(image);changed[offset]^=1;assert not plan(bytes(changed))[0]
assert not plan(image[:0x158380])[0] and not plan(image,0x83000000)[0]
print('PASS: exact upstream UpdateBrowser/RenderBrowser methods accepted; full-method mutation/truncation/base mismatch rejected; only two16-byte application entries change and restore exactly; XAM/kernel untouched')
