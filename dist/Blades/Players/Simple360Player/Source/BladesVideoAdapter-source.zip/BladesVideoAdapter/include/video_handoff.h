#ifndef BLADES_VIDEO_HANDOFF_H
#define BLADES_VIDEO_HANDOFF_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
/* Byte-defined wire format fits XAM's 1020-byte launch-data limit. No pointers,
   DOS drive aliases, saved credentials or ABI-dependent integers cross titles. */
typedef struct {
    uint8_t magic[8],version[4],bytes[4];
    char blades_xex[260],folder[480],filename[260];
} VideoHandoff;
_Static_assert(sizeof(VideoHandoff)==1016,"video handoff exceeds launch data");
bool video_handoff_make(VideoHandoff *,const char *selected,const char *blades);
bool video_handoff_valid(const VideoHandoff *,size_t bytes,bool returning);
void video_handoff_return(VideoHandoff *);
bool video_handoff_selected(const VideoHandoff *,char *out,size_t bytes);
bool video_handoff_autoplay(const VideoHandoff *,char *out,size_t bytes);
/* UTF-8/ANSI bytes are carried unchanged. Reject delimiters/control characters
   and traversal before writing the player's line-oriented autoplay file. */
bool video_handoff_physical(const char *,size_t limit);
bool video_handoff_native(const char *path,char *out,size_t bytes);
#endif
