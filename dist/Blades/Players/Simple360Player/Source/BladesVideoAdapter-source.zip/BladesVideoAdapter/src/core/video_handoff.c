#include "video_handoff.h"
static size_t length(const char *s,size_t cap) {size_t n=0;if(!s)return cap;while(n<cap&&s[n])n++;return n;}
static bool equal(const void *av,const void *bv,size_t n) {const uint8_t *a=av,*b=bv;for(size_t i=0;i<n;i++)if(a[i]!=b[i])return false;return true;}
static bool copy(char *out,size_t cap,const char *s,size_t n) {if(n>=cap)return false;for(size_t i=0;i<n;i++)out[i]=s[i];out[n]=0;return true;}
static bool filename(const char *s,size_t cap) {
    size_t n=length(s,cap);if(!n||n==cap)return false;
    if((n==1&&s[0]=='.')||(n==2&&s[0]=='.'&&s[1]=='.'))return false;
    for(size_t i=0;i<n;i++) {
        unsigned char c=(unsigned char)s[i];
        if(c<32||c==127||c=='/'||c=='\\'||c==':'||c=='"'||c=='?'||c=='*'||c=='<'||c=='>'||c=='|')return false;
    }
    return true;
}
/* A bounded path segment need not be terminated at its separator. */
bool video_handoff_physical(const char *s,size_t cap) {
    size_t n=length(s,cap);if(n==cap||n<9||!equal(s,"\\Device\\",8))return false;
    size_t start=8;
    for(size_t i=8;i<=n;i++) {
        unsigned char c=(unsigned char)s[i];
        if(i<n&&c!='\\'&&(c<32||c==127||c=='/'||c==':'||c=='"'||c=='?'||c=='*'||c=='<'||c=='>'||c=='|'))return false;
        if(i==n||c=='\\') {
            size_t count=i-start;
            if(!count||(count==1&&s[start]=='.')||(count==2&&s[start]=='.'&&s[start+1]=='.'))return false;
            start=i+1;
        }
    }
    return true;
}
static bool xex(const char *s,size_t cap) {
    size_t n=length(s,cap);return n>=4&&n<cap&&s[n-4]=='.'&&
        (s[n-3]=='x'||s[n-3]=='X')&&(s[n-2]=='e'||s[n-2]=='E')&&(s[n-1]=='x'||s[n-1]=='X');
}
bool video_handoff_valid(const VideoHandoff *v,size_t bytes,bool returning) {
    static const uint8_t version[4]={0,0,0,1},size[4]={0,0,3,248};
    return v&&bytes==sizeof *v&&equal(v->magic,returning?"BLDVRET1":"BLDVPLY1",8)&&
        equal(v->version,version,4)&&equal(v->bytes,size,4)&&video_handoff_physical(v->blades_xex,sizeof v->blades_xex)&&
        xex(v->blades_xex,sizeof v->blades_xex)&&video_handoff_physical(v->folder,sizeof v->folder)&&filename(v->filename,sizeof v->filename);
}
bool video_handoff_make(VideoHandoff *v,const char *selected,const char *blades) {
    if(!v||!video_handoff_physical(selected,1024)||!video_handoff_physical(blades,sizeof v->blades_xex)||!xex(blades,sizeof v->blades_xex))return false;
    size_t n=length(selected,1024),last=n;while(last&&selected[last-1]!='\\')last--;
    for(size_t i=0;i<sizeof *v;i++)((uint8_t*)v)[i]=0;
    if(!last||!copy(v->folder,sizeof v->folder,selected,last-1)||!copy(v->filename,sizeof v->filename,selected+last,n-last)||
       !copy(v->blades_xex,sizeof v->blades_xex,blades,length(blades,sizeof v->blades_xex)))return false;
    for(unsigned i=0;i<8;i++)v->magic[i]=(uint8_t)"BLDVPLY1"[i];
    v->version[3]=1;v->bytes[2]=3;v->bytes[3]=248;
    return video_handoff_valid(v,sizeof *v,false);
}
void video_handoff_return(VideoHandoff *v) {for(unsigned i=0;i<8;i++)v->magic[i]=(uint8_t)"BLDVRET1"[i];}
bool video_handoff_selected(const VideoHandoff *v,char *out,size_t cap) {
    if(!v||!out||(!video_handoff_valid(v,sizeof *v,false)&&!video_handoff_valid(v,sizeof *v,true)))return false;
    size_t a=length(v->folder,sizeof v->folder),b=length(v->filename,sizeof v->filename);
    if(a+b+2>cap)return false;
    copy(out,cap,v->folder,a);out[a]='\\';return copy(out+a+1,cap-a-1,v->filename,b);
}
bool video_handoff_autoplay(const VideoHandoff *v,char *out,size_t cap) {
    static const char prefix[]="autoplay=bladesvideo:\\";
    if(!v||!out||!video_handoff_valid(v,sizeof *v,false))return false;
    size_t a=sizeof prefix-1,b=length(v->filename,sizeof v->filename);
    if(a+b+2>cap)return false;
    copy(out,cap,prefix,a);copy(out+a,cap-a,v->filename,b);out[a+b]='\n';out[a+b+1]=0;return true;
}
static bool prefix(const char *s,const char *p) {
    for(size_t i=0;p[i];i++) {
        unsigned char a=(unsigned char)s[i],b=(unsigned char)p[i];
        if(a>='A'&&a<='Z')a+='a'-'A';
        if(b>='A'&&b<='Z')b+='a'-'A';
        if(!a||a!=b)return false;
    }
    return true;
}
bool video_handoff_native(const char *path,char *out,size_t cap) {
    static const struct {const char *drive,*target;} drives[]={
        {"hdd:","\\Device\\Harddisk0\\Partition1"},{"usb0:","\\Device\\Mass0"},
        {"usb1:","\\Device\\Mass1"},{"usb2:","\\Device\\Mass2"},
        {"mu0:","\\Device\\Mu0"},{"mu1:","\\Device\\Mu1"},{"bladesmu:","\\Device\\BuiltInMuSfc"}};
    if(!path||!out||!cap)return false;
    const char *tail=path,*head="";
    if(!prefix(path,"/Device/")&&!prefix(path,"\\Device\\")) {
        bool found=false;
        for(unsigned i=0;i<sizeof drives/sizeof *drives;i++)if(prefix(path,drives[i].drive)) {
            size_t n=length(drives[i].drive,32);
            if(path[n]!='/'&&path[n]!='\\')return false;
            head=drives[i].target;tail=path+n;found=true;break;
        }
        if(!found)return false;
    }
    size_t a=length(head,cap),b=length(tail,cap);
    if(a+b>=cap||!copy(out,cap,head,a)||!copy(out+a,cap-a,tail,b))return false;
    for(size_t i=0;i<a+b;i++)if(out[i]=='/')out[i]='\\';
    return video_handoff_physical(out,cap);
}
